# -*- coding: utf-8 -*-
{
    'name': "Reportes Bolivia / Kyohei Ltda.",

    'summary': """
    Al instalar este módulo obtendrá los informes financieros de Bolivia
    """,

    'description': """
Utilice los reportes financieros Out Of The Box
================================================================================

Después de instalar el módulo obtendrá los siguientes reportes financieros:
    * Estado de resultados
    * Balance general
    """,
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Localization',
    'version': '13.0.0.1',
    'depends': ['l10n_bo_kyohei', 'account_accountant'],
    'license': 'OPL-1',
    'auto_install': True,
    'data': [
        'data/financial_report_data.xml',
        'data/account.financial.html.report.line.csv',
    ],
}

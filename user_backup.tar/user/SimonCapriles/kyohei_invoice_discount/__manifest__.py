# -*- coding: utf-8 -*-
{
    'name': "Descuentos / Kyohei Ltda.",

    'summary': """
        El módulo incorpora descuentos por monto fijo y globales a las facturas
        """,

    'description': """
Obtenga la posibilidad de detallar descuentos por monto fijo o globales en las facturas
======================================================================================================

Con la instalación del módulo usted obtendrá:
    * La alternativa de escoger entre un descuento porcentual o fijo
    * La posibilidad de detallar un descuento global de la factura
    
    """,
    'demo': [
        'demo/demo.xml',
    ],
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Invoicing Management',
    'version': '13.0.0.1',
    'depends': ['account'],
    'price': 100,
    'currency': 'USD',
    'license': 'OPL-1',
    'installable': True,
    'application': True,
    'pre_init_hook': 'pre_init_check',
    'data': [
        'security/security.xml',
        'settings/settings_view.xml',
        'views/account_move_view.xml',
    ],

}

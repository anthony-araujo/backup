# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class ResCompany(models.Model):
    _inherit = "res.company"

    invoice_discount_account = fields.Many2one(
        string="Cuenta de descuento en facturas",
        comodel_name='account.account',
        help="Cuenta contable para descuentos globales en facturas.")
    bill_discount_account = fields.Many2one(
        string="Cuenta de decuento en recibos",
        comodel_name='account.account',
        help="Cuenta contable para descuentos globales en recibos.")

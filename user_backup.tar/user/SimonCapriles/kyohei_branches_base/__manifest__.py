# -*- coding: utf-8 -*-
{
    'name': "Sucursales / Kyohei Ltda.",
    'summary': """
        El módulo incorpora las bases necesarias para la gestión de Sucursales
        """,
    'description': """
Gestione sus Sucursales sin la creación de nuevas Compañías
=============================================================
    
Con la instalación del módulo usted obtendrá:
    * La incorporación de Sucursales en el menú "Ajustes"
    
    """,
    'author': "Kyohei Ltda.",
    'website': "http://www.kyohei.com.bo",
    'category': 'Operations',
    'version': '13.0.0.1',
    'depends': ['base'],
    'license': 'OPL-1',
    'installable': True,
    'application': True,
    'data': [
        'security/ir.model.access.csv',
        'views/user_view.xml',
        'views/company_branch_view.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}

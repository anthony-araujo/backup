# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiBranch(models.Model):
    _name = 'res.company.branch'
    _description = 'Sucursal'

    name = fields.Char(string='Sucursal')
    company_id = fields.Many2one('res.company', string='Casa matriz', required=True)
    street = fields.Char(string='Calle')
    street2 = fields.Char(string='Calle2')
    city = fields.Char(string='Ciudad')
    state_id = fields.Many2one('res.country.state', string='Departamento')
    country_id = fields.Many2one(related='state_id.country_id', string='País')
    phone = fields.Char(string='Teléfono')
    email = fields.Char(string='Email')
    user_ids = fields.Many2many(
        'res.users',
        'branch_user_rel',
        'user_ids',
        'branch_ids',
        string='Usuarios',
    )

    @api.model
    def create(self, values):
        self.env['ir.rule'].clear_caches()
        return super(KyoheiBranch, self).create(values)

    def write(self, values):
        self.env['ir.rule'].clear_caches()
        if 'user_ids' in values:
            user_list = []
            user_list_string = ''
            for user in self.env['res.users'].search([['branch_id', '=', self.id]]):
                if user.id not in values['user_ids'][0][2]:
                    user_list.append('- %s' % user.name)
            if user_list:
                n = 1
                for record in user_list:
                    if n < len(user_list):
                        user_list_string = user_list_string + record + '\n'
                    else:
                        user_list_string = user_list_string + record
                raise exceptions.ValidationError('''Esta es la sucursal principal de los siguientes usuarios:
    %s
    Y no puede eliminarlos desde aquí. Tiene que hacerlo desde el perfil del usuario.''' % user_list_string)
        return super(KyoheiBranch, self).write(values)

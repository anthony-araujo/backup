# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiBranchUser(models.Model):
    _inherit = 'res.users'

    branch_id = fields.Many2one(
        'res.company.branch',
        string='Sucursal predeterminada',
        domain="[('company_id', 'in', company_ids)]"
    )
    branch_ids = fields.Many2many(
        'res.company.branch',
        'branch_user_rel',
        'branch_ids',
        'user_ids',
        string='Sucursales permitidas',
        domain="[('company_id', 'in', company_ids)]"
    )

    @api.constrains('branch_id', 'branch_ids')
    def check_allowed_branches(self):
        for record in self:
            if record.branch_id and record.branch_id not in record.branch_ids:
                raise exceptions.ValidationError(
                    'La Sucursal seleccionada no está entre las Sucursales permitidas para este usuario'
                )

    @api.model
    def create(self, values):
        self.env['ir.rule'].clear_caches()
        return super(KyoheiBranchUser, self).create(values)

    def write(self, values):
        self.env['ir.rule'].clear_caches()
        return super(KyoheiBranchUser, self).write(values)

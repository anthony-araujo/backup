# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiCompanyBranch(models.Model):
    _inherit = 'res.company'

    branch_ids = fields.One2many('res.company.branch', 'company_id')

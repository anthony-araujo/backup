# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiComputerizedExpenseLcvLine(models.Model):
    _inherit = 'lcv.line'

    expense_id = fields.Many2one('account.expense', string='Gasto')

    def open_document(self):
        record = super().open_document()
        if self.expense_id:
            return {
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'account.expense',
                'res_id': self.expense_id.id,
                'target': 'current',
                'context': {}
            }
        return record

    def correct_line(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Corregir Línea de Compra o Venta',
            'res_model': 'lcv.correct.wizard',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': self.env.ref('kyohei_computerized_expense.correct_lcv_line_wizard_form').id,
            'target': 'new',
            'context': {
                'default_lcv_line_id': self.id,
                'default_date': self.date,
                'default_billing_name': self.billing_name,
                'default_billing_number': self.billing_number,
                'default_invoice_number': self.invoice_number,
                'default_authorization_number': self.authorization_number,
                'default_control_code': self.control_code,
                'default_purchase_type': self.purchase_type,
                'default_sin_state': self.sin_state
            }
        }

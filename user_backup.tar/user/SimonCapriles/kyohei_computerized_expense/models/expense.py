# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError


class KyoheiComputerizedExpense(models.Model):
    _inherit = 'account.expense'
    _sql_constraints = [(
        'name_uniq',
        'unique(authorization_number, sin_number)',
        'Ya existe una factura con este número y autorización, revise los datos que está registrando.'
    )]

    expense_type = fields.Selection(
        [('invoice', 'Factura'),
         ('receipt', 'Recibo')],
        string='Tipo',
        default='invoice',
        required=True
    )
    # Computerized data
    partner_id = fields.Many2one(
        'res.partner',
        string='Proveedor',
        states={'approved': [('readonly', True)]},
        copy=False
    )
    partner_billing_name = fields.Char(string='Razón social', copy=False)
    partner_billing_number = fields.Char(string='NIT', copy=False)
    control_code = fields.Char(
        string='Código de control',
        states={'approved': [('readonly', True)]},
        copy=False
    )
    authorization_number = fields.Char(
        string='N° autorización',
        states={'approved': [('readonly', True)]},
        copy=False
    )
    sin_number = fields.Char(
        string='N° factura',
        states={'approved': [('readonly', True)]},
        copy=False
    )
    sin_state = fields.Selection(
        [
            ('V', 'Válida'),
            ('A', 'Anulada'),
            ('E', 'Extraviada'),
            ('N', 'No Aplica'),
            ('C', 'Contingencia'),
            ('L', 'Libre consignación')
        ],
        string='Estado SIN',
        default='V',
        states={'approved': [('readonly', True)]},
        copy=False
    )
    purchase_type = fields.Selection(
        [
            ('1', 'Mercado interno'),
            ('2', 'Mercado interno No gravadas'),
            ('3', 'Sujetas a proporcionalidad'),
            ('4', 'Destino exportaciones'),
            ('5', 'Interno y exportaciones')
        ],
        string='Tipo de compra',
        default='1',
        states={'approved': [('readonly', True)]},
        copy=False,
    )
    lcv_line_id = fields.Many2one('lcv.line', string='Línea de compras', copy=False)
    # Tax related data
    credit_tax_group_id = fields.Many2one(
        'account.tax.group',
        string='Impuestos de Crédito fiscal',
        related='company_id.credit_debit_tax_group_id'
    )
    true_total_amount = fields.Float(
        string='Total impuestos',
        copy=False,
        compute='_compute_bolivian_tax_amounts',
        store=True
    )
    subtotal_amount = fields.Float(
        string='Subtotal',
        copy=False,
        compute='_compute_bolivian_tax_amounts',
        store=True
    )
    credit_debit_base_amount = fields.Float(
        string='Importe base crédito fiscal',
        copy=False,
        compute='_compute_bolivian_tax_amounts',
        store=True
    )
    credit_debit_amount = fields.Float(
        string='crédito fiscal',
        copy=False,
        compute='_compute_bolivian_tax_amounts',
        store=True
    )
    invoice_qr = fields.Char(
        string='QR',
        readonly=True,
        states={'draft': [('readonly', False)]}
    )

    @api.onchange('invoice_qr')
    def _fill_from_qr(self):
        if self.invoice_qr:
            content_list = self.invoice_qr.split('|')
            if len(content_list) != 12:
                raise ValidationError('El contenido del QR no corresponde a facturas')
            else:
                try:
                    company_id = self.env['res.company'].search(['&', ['vat', '=', content_list[7]], ['branch_code', '=', False]])[0].id
                except IndexError:
                    raise ValidationError('''No tiene compañías con el NIT del QR.
Revise que el NIT de las compañías se encuentra configurado o la factura no corresponde a su compañía.''')
                try:
                    partner_id = self.env['res.partner'].search([['vat', '=', content_list[0]]])[0].id
                except IndexError:
                    self.env['res.partner'].create({
                        'name': 'FALTA NOMBRE PROVEEDOR',
                        'document_type': '5',
                        'vat': content_list[0]
                    })
                    partner_id = self.env['res.partner'].search([['vat', '=', content_list[0]]])[0].id
                self.write({
                    'company_id': company_id,
                    'partner_id': partner_id,
                    'purchase_type': '1',
                    'partner_billing_number': content_list[0],
                    'sin_number': content_list[1],
                    'authorization_number': content_list[2],
                    'date': self.date,
                    'control_code': content_list[6],
                })

    @api.onchange('expense_type')
    def _onchange_expense_type(self):
        if self.expense_type == 'receipt':
            self.tax_ids = False
            self.purchase_type = False
            self.invoice_qr = False
            self.partner_id = False
            self.partner_billing_number = False
            self.partner_billing_name = False
            self.sin_number = False
            self.authorization_number = False
            self.exempt_amount = False
            self.control_code = False

    @api.depends('unit_price', 'quantity', 'tax_ids', 'currency_id', 'discount_type', 'discount',
                 'specific_fee_amount', 'special_hydrocarbon_amount', 'game_participation_amount', 'rates_amount',
                 'no_credit_tax_amount', 'exempt_amount', 'zero_rate_amount', 'gift_card_amount'
                 )
    def _compute_bolivian_tax_amounts(self):
        for record in self:
            discount_amount = 0
            if record.discount_type == 'fixed':
                discount_amount = record.discount
            elif record.discount_type == 'percent':
                discount_amount = (record.discount / 100) * record.unit_price * record.quantity
            true_total = record.unit_price * record.quantity + (
                    record.specific_fee_amount +
                    record.special_hydrocarbon_amount +
                    record.game_participation_amount +
                    record.rates_amount +
                    record.no_credit_tax_amount +
                    record.exempt_amount +
                    record.zero_rate_amount +
                    record.gift_card_amount
            )
            subtotal_amount = true_total - (
                    record.specific_fee_amount +
                    record.special_hydrocarbon_amount +
                    record.game_participation_amount +
                    record.rates_amount +
                    record.no_credit_tax_amount +
                    record.exempt_amount +
                    record.zero_rate_amount
            )
            credit_debit_base_amount = subtotal_amount - discount_amount - record.gift_card_amount
            record.true_total_amount = true_total
            record.subtotal_amount = subtotal_amount
            record.credit_debit_base_amount = credit_debit_base_amount
            record.credit_debit_amount = round(credit_debit_base_amount * 0.13, self.currency_id.decimal_places)

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        if self.partner_id:
            self.partner_billing_name = self.partner_id.billing_name
            self.partner_billing_number = self.partner_id.vat

    def scan_expense_qr_code(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Gasto desde QR',
            'res_model': 'purchase.from.qr.wizard',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': self.env.ref('kyohei_computerized_billing.purchase_from_qr_wizard_form').id,
            'target': 'new',
            'context': {
                'default_expense_id': self.id,
                'default_document_type': 'expense',
            }
        }

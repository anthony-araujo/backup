# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiComputerizedExpenseReport(models.Model):
    _inherit = 'account.expense.report'

    credit_tax_group_id = fields.Many2one(
        'account.tax.group',
        string='Impuestos de Crédito fiscal',
        related='company_id.credit_debit_tax_group_id'
    )

    def action_approve_report(self):
        record = super().action_approve_report()
        for expense in self.expense_line_ids:
            if expense.expense_type == 'invoice':
                if not expense.partner_id:
                    raise exceptions.ValidationError('Falta el "Proveedor" en el gasto %s' % expense.name)
                elif not expense.partner_billing_name:
                    raise exceptions.ValidationError('Falta la "Razón social" del proveedor en el gasto %s' % expense.name)
                elif not expense.partner_billing_number:
                    raise exceptions.ValidationError('Falta el "NIT" del proveedor en el gasto %s.' % expense.name)
                elif not expense.control_code:
                    raise exceptions.ValidationError('Falta el "Código de control" en el gasto %s.' % expense.name)
                elif not expense.tax_ids:
                    raise exceptions.ValidationError('Falta definir el "Impuesto" en el gasto %s.' % expense.name)
                elif not expense.credit_tax_group_id:
                    raise exceptions.ValidationError('Los impuestos no son válidos en el gasto %s.' % expense.name)
                elif not expense.authorization_number:
                    raise exceptions.ValidationError('Falta el "Número de autorización" en el gasto %s.' % expense.name)
                elif expense.sin_number == 0:
                    raise exceptions.ValidationError('El "Número de factura" del gasto %s no puede ser 0.' % expense.name)
                elif expense.unit_price == 0:
                    raise exceptions.ValidationError('El "Precio unitario" del gasto %s no puede ser 0.' % expense.name)
                elif expense.quantity == 0:
                    raise exceptions.ValidationError('La "Cantidad" del gasto %s no puede ser 0.' % expense.name)
                elif expense.credit_tax_group_id:
                    for tax in expense.tax_ids:
                        if tax.tax_group_id != expense.credit_tax_group_id:
                            raise exceptions.ValidationError('El impuesto del gasto ' + expense.name + 'no es válido.')
            else:
                for tax in expense.tax_ids:
                    if tax.tax_group_id == expense.credit_tax_group_id:
                        raise exceptions.ValidationError('''El gasto "%s" tiene un impuesto asociado al Crédito fiscal y debería ser una factura.
El tipo del gasto debería ser "Factura", corrija los datos antes de aprobar el informe.''' % expense.name)
        return record

    def action_report_move_create(self):
        for move in self.expense_line_ids:
            move._compute_bolivian_tax_amounts()
        record = super().action_report_move_create()
        # Determine credit tax amount
        report_move = record.get(self.id)
        report_move_credit_amount = 0
        for move_line in report_move.line_ids:
            if move_line.tax_line_id and move_line.tax_line_id.tax_group_id == self.credit_tax_group_id:
                report_move_credit_amount += move_line.debit - move_line.credit
        report_declared_credit_amount = 0
        for expense in self.expense_line_ids:
            if expense.expense_type == 'invoice':
                for tax in expense.tax_ids:
                    if tax.tax_group_id != expense.credit_tax_group_id:
                        raise exceptions.ValidationError('El gasto %s contiene impuestos que no corresponden a facturas' % expense.name)
                # Sum declared credit tax amount
                report_declared_credit_amount += expense.credit_debit_amount
                # LCV line
                lcv_line_record = self.env['lcv.line']
                lcv_line_record.sudo().create({
                    'company_id': expense.company_id.id,
                    'expense_id': expense.id,
                    'line_type': 'purchase',
                    'sin_state': expense.sin_state,
                    'date': expense.date,
                    'billing_number': expense.partner_billing_number,
                    'billing_name': expense.partner_billing_name,
                    'invoice_number': expense.sin_number,
                    'policy_number': '0',
                    'authorization_number': expense.authorization_number,
                    'total_amount': expense.true_total_amount,
                    'specific_fee_amount': expense.specific_fee_amount,
                    'special_hydrocarbon_amount': expense.special_hydrocarbon_amount,
                    'game_participation_amount': expense.game_participation_amount,
                    'rates_amount': expense.rates_amount,
                    'no_credit_tax_amount': expense.no_credit_tax_amount,
                    'exempt_amount': expense.exempt_amount,
                    'zero_rate_amount': expense.zero_rate_amount,
                    'subtotal_amount': expense.subtotal_amount,
                    'discount_amount': expense.discount_amount,
                    'gift_card_amount': expense.gift_card_amount,
                    'credit_debit_base_amount': expense.credit_debit_base_amount,
                    'credit_debit_amount': expense.credit_debit_amount,
                    'control_code': expense.control_code,
                    'purchase_type': expense.purchase_type,
                    'lcv_specification': '1',
                    'branch_code': expense.company_id.branch_code,
                    'invoice_id': expense.expense_report_id.account_move_id.id
                })
                lcv_line_registry = lcv_line_record.search([['expense_id', '=', expense.id]])[0]
                expense.write({'lcv_line_id': lcv_line_registry})
        # Compare move's credit amount with overall expense's credit amount
        if report_declared_credit_amount != report_move_credit_amount:
            credit_debit_difference = report_declared_credit_amount - report_move_credit_amount
            if abs(credit_debit_difference) <= 0.05:
                credit_debit_amount = report_declared_credit_amount - credit_debit_difference
                if abs(credit_debit_amount - report_move_credit_amount) != 0:
                    raise Warning('Existe un error de cálculo, comuníquese con su administrador.')
            else:
                raise exceptions.ValidationError('''Los importes de crédito fiscal declarados y los de los asientos no coinciden:
Crédito en asientos: %s
Crédito declarado: %s
Comuníquese con el administrador del sistema.''' % (report_move_credit_amount, report_declared_credit_amount))
        return record

    def reset_expense_report(self):
        record = super().reset_expense_report()
        for expense in self.expense_line_ids:
            if expense.lcv_line_id:
                expense.lcv_line_id.sudo().unlink()
        return record

    def reverse_report_move(self):
        record = super().reverse_report_move()
        for expense in self.expense_line_ids:
            expense.write({
                'sin_number': False,
                'authorization_number': False,
                'control_code': False
            })
            if expense.lcv_line_id:
                expense.lcv_line_id.sudo().unlink()
        return record

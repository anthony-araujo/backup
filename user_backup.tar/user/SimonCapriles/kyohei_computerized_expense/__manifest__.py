# -*- coding: utf-8 -*-
{
    'name': "Gastos computarizada / Kyohei Ltda.",

    'summary': """
        El módulo integra gastos con los libros de compras y ventas de impuestos nacionales
        """,

    'description': """
Obtenga las funciones para integrar los gastos con los reportes para impuestos nacionales
======================================================================================================

Con la instalación del módulo usted obtendrá:
    * La incorporación de los gastos al LCV
    * La adición de datos de impuestos nacionales en los gastos
    * La incorporación del QR para llenar los datos de los gastos
    
    """,
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Invoicing Management',
    'version': '13.0.0.1',
    'depends': ['kyohei_billing_base', 'kyohei_expense'],
    'license': 'OPL-1',
    'auto_install': True,
    'data': [
        'data/server_action_data.xml',
        'security/security_groups.xml',
        'views/expense_view.xml',
        'views/expense_report_view.xml',
        'views/lcv_line_view.xml',
        'wizard/account_move_from_qr_wizard_view.xml',
        'wizard/lcv_correction_wizard_view.xml'
    ],
}

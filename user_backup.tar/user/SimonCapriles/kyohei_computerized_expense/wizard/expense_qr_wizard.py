# -*- coding: utf-8 -*-

from datetime import datetime
from odoo import models, fields, exceptions


class KyoheiComputerizedExpenseCreateFromQrWizard(models.TransientModel):
    _inherit = 'purchase.from.qr.wizard'

    expense_id = fields.Many2one('account.expense', default=False)
    document_type = fields.Selection(
        [('invoice', 'Factura'),
         ('expense', 'Gasto')],
        string='Tipo de documento'
    )

    def create_from_qr(self):
        content_list, company_id, partner_id = self.check_qr_data()
        invoice_date = datetime.strptime(content_list[3], '%d/%m/%Y').date()
        if self.invoice_id:
            record_id = self.invoice_id
            company_id = self.invoice_id.company_id.id
            view_id = self.env.ref('account.view_move_form').id
            if self.invoice_id.company_id.id != company_id:
                raise exceptions.ValidationError('''Esta factura no corresponde a esta compañía.
Asegúrese de estar trabajando en la compañía correcta.''')
            record_id.write({
                'company_id': company_id,
                'partner_id': partner_id,
                'purchase_type': '1',
                'partner_billing_number': content_list[0],
                'sin_number': content_list[1],
                'authorization_number': content_list[2],
                'invoice_date': invoice_date,
                'date': invoice_date,
                'invoice_payment_term_id': invoice_date,
                'control_code': content_list[6],
                'sin_state': 'V',
            })
            return {
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'account.move',
                'res_id': record_id.id,
                'view_id': view_id,
                'type': 'ir.actions.act_window',
                'target': 'current',
            }

        elif self.expense_id:
            record_id = self.expense_id
            company_id = self.expense_id.company_id.id
            view_id = self.env.ref('kyohei_computerized_expense.kyohei_account_computerized_expense_form').id
            if self.expense_id.company_id.id != company_id:
                raise exceptions.ValidationError('''Este gasto no corresponde a esta compañía.
Asegúrese de estar trabajando en la compañía correcta.''')
            record_id.write({
                'company_id': company_id,
                'partner_id': partner_id,
                'expense_type': 'invoice',
                'purchase_type': '1',
                'partner_billing_number': content_list[0],
                'sin_number': content_list[1],
                'authorization_number': content_list[2],
                'date': invoice_date,
                'control_code': content_list[6],
                'sin_state': 'V',
            })
            return {
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'account.expense',
                'res_id': record_id.id,
                'view_id': view_id,
                'type': 'ir.actions.act_window',
                'target': 'current',
            }

        else:
            if self.document_type == 'invoice':
                return {
                    'context': {
                        'default_company_id': company_id,
                        'default_state': 'draft',
                        'default_type': 'in_invoice',
                        'default_partner_id': partner_id,
                        'purchase_type': '1',
                        'default_sin_number': content_list[1],
                        'default_authorization_number': content_list[2],
                        'invoice_date': invoice_date,
                        'date': invoice_date,
                        'invoice_payment_term_id': invoice_date,
                        'default_control_code': content_list[6],
                    },
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'account.move',
                    'view_id':  self.env.ref('account.view_move_form').id,
                    'type': 'ir.actions.act_window',
                    'target': 'current',
                }
            elif self.document_type == 'expense':
                return {
                    'context': {
                        'default_company_id': company_id,
                        'default_state': 'draft',
                        'default_expense_type': 'invoice',
                        'default_partner_id': partner_id,
                        'purchase_type': '1',
                        'default_sin_number': content_list[1],
                        'default_authorization_number': content_list[2],
                        'date': invoice_date,
                        'default_control_code': content_list[6],
                    },
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'account.expense',
                    'view_id': self.env.ref('kyohei_computerized_expense.kyohei_account_computerized_expense_form').id,
                    'type': 'ir.actions.act_window',
                    'target': 'current',
                }

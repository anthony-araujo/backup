# -*- coding: utf-8 -*-

from odoo import models, fields, exceptions


class KyoheiLcvReportWizard(models.TransientModel):
    _name = 'lcv.correct.wizard'
    _description = 'Asistente corrector de Libro de Compras y Ventas'

    lcv_line_id = fields.Many2one('lcv.line')
    currency_id = fields.Many2one(related='lcv_line_id.currency_id')
    lcv_specification = fields.Selection(
        [
            ('1', 'Estándar (Compras)'),
            ('2', 'Notas de crédito y débito (Compras)'),
            ('3', 'Estándar (Ventas)'),
            ('4', 'Estación de servicio'),
            ('5', 'Agrupadas'),
            ('6', 'Reintergro'),
            ('7', 'Notas de crédito y débito (Ventas)')
        ], related='lcv_line_id.lcv_specification'
    )
    date = fields.Date(string='Fecha', default=False)
    billing_name = fields.Char(string='Razón social', default='s/n')
    billing_number = fields.Char(string='NIT', default=0)
    invoice_number = fields.Char(string='Número factura', default=False)
    authorization_number = fields.Char(string='Autorización', default=0)
    control_code = fields.Char(string='Código de control', default=False)
    purchase_type = fields.Selection(
        [
            ('1', 'Mercado interno'),
            ('2', 'Mercado interno No gravadas'),
            ('3', 'Sujetas a proporcionalidad'),
            ('4', 'Destino exportaciones'),
            ('5', 'Interno y exportaciones')
        ],
        string='Tipo de compra'
    )
    sin_state = fields.Selection(
        [
            ('V', 'Válida'),
            ('A', 'Anulada'),
            ('E', 'Extraviada'),
            ('N', 'No utilizado'),
            ('C', 'Contingencia'),
            ('L', 'Libre consignación')
        ],
        string='Estado')

    def change_lcv_line(self):
        self.lcv_line_id.sudo().write({
            'date': self.date,
            'billing_name': self.billing_name,
            'billing_number': self.billing_number,
            'invoice_number': self.invoice_number,
            'authorization_number': self.authorization_number,
            'control_code': self.control_code,
            'purchase_type': self.purchase_type,
            'sin_state': self.sin_state
        })
        self.lcv_line_id.expense_id.sudo().write({
            'date': self.date,
            'partner_billing_name': self.billing_name,
            'partner_billing_number': self.billing_number,
            'sin_number': self.invoice_number,
            'authorization_number': self.authorization_number,
            'control_code': self.control_code,
            'purchase_type': self.purchase_type,
            'sin_state': self.sin_state
        })
        return {
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'lcv.line',
            'res_id': self.lcv_line_id.id,
            'view_id': self.env.ref('kyohei_billing_base.lcv_purchase_line_form').id,
            'type': 'ir.actions.act_window',
            'target': 'current',
        }

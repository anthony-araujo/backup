# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiBillingBaseSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    # Default billing mode
    billing_mode = fields.Selection(related='company_id.billing_mode', string='Modalidad por defecto', readonly=False)
    # Billing modules
    module_kyohei_computerized_billing = fields.Boolean(string='Computarizada')
    module_kyohei_electronic_billing = fields.Boolean(string='Electrónica')
    # Extra modules
    module_kyohei_billing_branches = fields.Boolean(string='Sucursales')
    module_point_of_sale = fields.Boolean(string='Punto de venta')
    module_kyohei_expense = fields.Boolean(string='Gastos')
    # Tax groups
    credit_debit_tax_group_id = fields.Many2one(related='company_id.credit_debit_tax_group_id', string='Con I.V.A.', readonly=False)
    no_credit_debit_tax_group = fields.Many2one(related='company_id.no_credit_debit_tax_group', string='Sin I.V.A.', readonly=False)
    other_no_credit_debit_tax_group_id = fields.Many2one(related='company_id.other_no_credit_debit_tax_group_id', string='Otros sin I.V.A.', readonly=False)
    specific_fee_tax_group_id = fields.Many2one(related='company_id.specific_fee_tax_group_id', string='I.C.E.', readonly=False)
    retention_tax_group_id = fields.Many2one(related='company_id.retention_tax_group_id', string='Retenciones I.U.E.', readonly=False)
    # Taxes
    policy_credit_tax_id = fields.Many2one(related='company_id.policy_credit_tax_id', string='I.V.A. Pólizas', domain='["&", ["tax_group_id","=",credit_debit_tax_group_id], ["type_tax_use","=","purchase"]]', readonly=False)
    special_hydrocarbon_tax_id = fields.Many2one(related='company_id.special_hydrocarbon_tax_id', string='I.E.H.D.', domain='[["tax_group_id","=",no_credit_debit_tax_group]]', readonly=False)
    game_participation_tax_id = fields.Many2one(related='company_id.game_participation_tax_id', string='I.P.J.', domain='[["tax_group_id","=",no_credit_debit_tax_group]]', readonly=False)
    rate_tax_id = fields.Many2one(related='company_id.rate_tax_id', string='Tasas', domain='[["tax_group_id","=",no_credit_debit_tax_group]]', readonly=False)
    zero_rate_tax_ids = fields.Many2many(related='company_id.zero_rate_tax_ids', string='Tasa cero', domain='[["tax_group_id","=",no_credit_debit_tax_group]]', readonly=False)

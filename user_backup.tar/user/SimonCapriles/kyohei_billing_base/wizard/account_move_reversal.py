# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiAccountMoveReversal(models.TransientModel):
    _inherit = 'account.move.reversal'

    with_credit_debit_note = fields.Boolean(
        string='Nota:Crédito/Débito',
        default=False
    )

    def _prepare_default_reversal(self, move):
        record = super()._prepare_default_reversal(move)
        if not self.with_credit_debit_note:
            record.update({
                'is_nullifying': True,
                'billing_mode': False
            })
        return record

    def reverse_moves(self):
        self.ensure_one()
        moves = self.env['account.move'].browse(self.env.context['active_ids']) if self.env.context.get('active_model') == 'account.move' else self.move_id
        for move in moves:
            if move.company_id.tax_lock_date and move.move_id.invoice_date <= move.company_id.tax_lock_date:
                raise exceptions.ValidationError('No puede anular facturas que fueron declaradas.')
            if self.refund_method == 'modify' or self.refund_method == 'cancel' and not self.with_credit_debit_note:
                if self.move_type == 'out_invoice':
                    move.write({'sin_state': 'A'})
                    if move.lcv_line_id:
                        move.lcv_line_id.sudo().write({'sin_state': 'A'})
                elif self.move_type == 'in_invoice' and move.lcv_line_id:
                    move.lcv_line_id.sudo().unlink()
        return super().reverse_moves()

# -*- coding: utf-8 -*-

from datetime import datetime
from odoo import models, fields, exceptions


class KyoheiLcvReportWizard(models.TransientModel):
    _name = 'lcv.report.wizard'
    _description = 'Asistente de Libro de Compras y Ventas'

    report_period = fields.Selection(
        [
            ('1', 'Enero'),
            ('2', 'Febrero'),
            ('3', 'Marzo'),
            ('4', 'Abril'),
            ('5', 'Mayo'),
            ('6', 'Junio'),
            ('7', 'Julio'),
            ('8', 'Agosto'),
            ('9', 'Septiembre'),
            ('10', 'Octubre'),
            ('11', 'Noviembre'),
            ('12', 'Diciembre')
         ],
        string='Periodo',
        default=str(datetime.today().month)
    )
    report_year = fields.Char(string='Año', default=datetime.today().year)
    company_id = fields.Many2one(
        'res.company',
        domain='["&",["vat","!=",False],["branch_code","=",False]]',
        required=True,
        # default=lambda self: self.env.company
    )
    report_type = fields.Selection(
        [
            ('purchase', 'Libro de Compras: Estándar'),
            ('sale', 'Libro de Ventas: Estándar'),
            ('purchase_refund', 'Libro de Compras: Notas de crédito/débito'),
            ('sale_refund', 'Libro de Ventas: Notas de crédito/débito'),
        ],
        default='purchase'
    )

    def generate_lcv_report(self):
        report_type = self.report_type
        if report_type == 'sale':
            type_string = 'Libro de Ventas: Estándar'
            report_view_id = self.env.ref('kyohei_billing_base.lcv_report_standard_sale_form').id
        elif report_type == 'purchase':
            type_string = 'Libro de Compras: Estándar'
            report_view_id = self.env.ref('kyohei_billing_base.lcv_report_standard_purchase_form').id
        elif report_type == 'sale_refund':
            type_string = 'Libro de Ventas: Notas de Crédito - Débito'
            report_view_id = self.env.ref('kyohei_billing_base.lcv_report_sale_refund_form').id
        elif report_type == 'purchase_refund':
            type_string = 'Libro de Compras: Notas de Crédito - Débito'
            report_view_id = self.env.ref('kyohei_billing_base.lcv_report_purchase_refund_form').id
        else:
            raise exceptions.ValidationError('Tiene que seleccionar un tipo de reporte')
        company_id = self.company_id.id
        lcv_report_record = self.env['lcv.report']
        if self.report_period:
            search_period = self.report_period
        else:
            search_period = str(datetime.today().month)
        if self.report_year:
            search_year = self.report_year
        else:
            search_year = str(datetime.today().year)
        lcv_report_registry = lcv_report_record.search([
            '&', '&', '&',
            ['report_period', '=', search_period],
            ['report_year', '=', search_year],
            ['report_type', '=', report_type],
            ['company_id', '=', company_id]
        ])
        if not lcv_report_registry:
            if int(search_period) < 12:
                lcv_line_ids = self.env['lcv.line'].search(
                    ["&", "&", "&", "&",
                     ["date", ">=", '%s-%s-01' % (search_year, search_period)],
                     ["date", "<", '%s-%s-01' % (search_year, str(int(search_period)+1))],
                     ["lcv_report_id", "=", False],
                     ["line_type", "=", report_type],
                     ['parent_company_id', '=', company_id]]
                )
            else:
                lcv_line_ids = self.env['lcv.line'].search(
                    ["&", "&", "&", "&",
                     ["date", ">=", '%s-%s-01' % (search_year, search_period)],
                     ["date", "<", '%s-%s-01' % (str(int(search_year) + 1), 1)],
                     ["lcv_report_id", "=", False],
                     ["line_type", "=", report_type],
                     ['parent_company_id', '=', company_id]]
                )
            if not lcv_line_ids:
                raise exceptions.ValidationError('No existen registros del periodo seleccionado')
            else:
                lcv_report_record.sudo().create({
                    'name': '%s / %s / %s' % (type_string, search_period, datetime.today().year),
                    'report_period': search_period,
                    'report_year': search_year,
                    'state': 'draft',
                    'report_type': report_type,
                    'company_id': company_id,
                    'lcv_line_ids': lcv_line_ids,
                })
        else:
            pass
        lcv_report_registry = lcv_report_record.search([
            '&', '&', '&',
            ['report_period', '=', search_period],
            ['report_year', '=', search_year],
            ['report_type', '=', report_type],
            ['company_id', '=', company_id]
        ])
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'lcv.report',
            'view_id': report_view_id,
            'res_id': lcv_report_registry.id,
            'target': 'current'
        }

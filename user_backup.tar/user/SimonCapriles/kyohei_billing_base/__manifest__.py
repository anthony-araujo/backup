# -*- coding: utf-8 -*-
{
    'name': "Facturación Bolivia / Kyohei Ltda.",

    'summary': """
    El módulo permite facturar desde Odoo bajo normativa de Impuestos Nacinales
    """,

    'description': """
Obtenga las funciones básicas para facturar desde Odoo bajo la modalidad computarizada o electrónica
======================================================================================================

Con la instalación del módulo usted obtendrá:
    * Las Actividades económicas y leyendas vigentes
    * Los tipos de unidad de medida, códigos de divisas y países normados
    * La posibilidad de registrar la razón social y número de facturación de sus clientes
    * La posibilidad de registrar los datos de su compañía solicitados por el SIN
    * La posibilidad de instalar la facturación computarizada de Kyohei Ltda.
    * La posibilidad da instalar la facturación electrónica de Kyohei Ltda.
    
    """,
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Invoicing Management',
    'version': '13.4.0.1',
    'depends': ['account', 'kyohei_invoice_discount'],
    'external_dependencies': {'python': ['num2words', 'qrcode', 'zeep', 'arc4']},
    'license': 'OPL-1',
    'installable': True,
    'application': True,
    'data': [
        'security/ir.model.access.csv',
        'security/security_groups.xml',
        'views/qr_scanner_assets.xml',
        'views/root_view.xml',
        'settings/settings_view.xml',
        'views/disable_quick_create.xml',
        'views/billing_characteristic_view.xml',
        'views/uom_view.xml',
        'views/partner_view.xml',
        'views/economic_sector_view.xml',
        'views/economic_activity_view.xml',
        'views/currency_view.xml',
        'views/country_view.xml',
        'views/company_view.xml',
        'views/billing_legend_view.xml',
        'views/account_move_view.xml',
        'views/sin_billing_system_view.xml',
        'views/lcv_line_view.xml',
        'views/lcv_report_view.xml',
        'wizard/account_move_from_qr_wizard_view.xml',
        'wizard/lcv_report_wizard_view.xml',
        'reports/lcv_report_template.xml',
        'reports/receipt_template.xml',
        'data/paper_format_data.xml',
        'data/billing_characteristic_data.xml',
        'data/country_data.xml',
        'data/currency_data.xml',
        'data/economic_sector_data.xml',
        'data/economic_activity_data.xml',
        'data/billing_legend_data.xml',
        'data/uom_data.xml',
        'data/lcv_line_sequence_data.xml',
        'data/lcv_server_action_data.xml'
    ]
}

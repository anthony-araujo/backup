$(document).ready(function(){

    function decodeQR(codeReader, selectedDeviceId) {
        codeReader.decodeFromInputVideoDevice(selectedDeviceId, 'video').then((result) => {
        	console.log(result)
        	$('input[name="qr_content"]').val(result.text);
	  		$('input[name="qr_content"]').change();
	  		showPageContent(false)
            document.getElementById('js_id_qr_scanner_result').textContent = result.text;
        }).catch((err) => {
          console.error(err)
        })
    }
    function showPageContent (show) {
            if (show === true) {
                //Show video and reset button
                $('#js_id_qr_scanner_vid_div').show();
                $("#js_id_qr_scanner_reset_btn").show();
                $("#js_id_qr_scanner_stop_btn").show();
                //Hide field and start button
                $("#js_id_qr_scanner_start_fields").hide();
            }else{
                //Reset reader
                codeReader.reset();
                //Show video and reset button
                $('#js_id_qr_scanner_vid_div').hide();
                $("#js_id_qr_scanner_reset_btn").hide();
                $("#js_id_qr_scanner_stop_btn").hide();
                //Hide field and start button
                $("#js_id_qr_scanner_start_fields").show();
            }
        }
	//Hide reset and stop button
	$("#js_id_qr_scanner_reset_btn").hide();
	$("#js_id_qr_scanner_stop_btn").hide();
    let selectedDeviceId;
    const codeReader = new ZXing.BrowserMultiFormatReader()
    console.log('ZXing initialized');
    codeReader.getVideoInputDevices()
    //then method start
    .then(function(result) {
    	const sourceSelect = document.getElementById('js_id_qr_scanner_camera_select');
    	$('input[name="qr_content"]').val('');
		$('input[name="qr_content"]').change();
        _.each(result, function(item) {
            const sourceOption = document.createElement('option')
            sourceOption.text = item.label
            sourceOption.value = item.deviceId
            sourceSelect.appendChild(sourceOption)
        });

        //Event handler
        //Camera select
    	$(document).on('change', '#js_id_qr_scanner_camera_select', function() {
    		  // Does some stuff and logs the event to the console
    		selectedDeviceId = sourceSelect.value;

    	});
        //Start button
        $(document).on("click","#js_id_qr_scanner_start_btn", function(event) {
            $('input[name="qr_content"]').val('');
    		$('input[name="qr_content"]').change();
            showPageContent(true)
			decodeQR(codeReader, selectedDeviceId);
        });
        //Reset button
        $(document).on("click","#js_id_qr_scanner_reset_btn", function(event) {
            $('input[name="qr_content"]').val('');
    		$('input[name="qr_content"]').change();
            showPageContent(true)
			decodeQR(codeReader, selectedDeviceId);
        });
        //Stop button
        $(document).on("click","#js_id_qr_scanner_stop_btn",function() {
            console.log('STOP CAMERA');
            document.getElementById('js_id_qr_scanner_result').textContent = '';
            $('input[name="qr_content"]').val('');
    		$('input[name="qr_content"]').change();
            showPageContent(false)
        });
        //Event handler end
    //then method end
    }).catch(function (reason) {

  	  console.log("Error ==>" + reason);
  });

});
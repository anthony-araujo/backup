odoo.define('disable_quick_create', function(require) {
    "use strict";

    var relational_fields = require('web.relational_fields');
    var models = [];

    relational_fields.FieldMany2One.include({
        init: function() {
            this._super.apply(this, arguments);

            this.nodeOptions.no_quick_create = true;

            if (models.includes(this.field.relation)){
                this.nodeOptions.no_create_edit = true;
            }
        },
    });
});

# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiBillingBaseLegend(models.Model):
    _name = 'billing.legend'
    _description = 'Leyenda de facturación'
    _rec_name = 'legend'

    active = fields.Boolean(string='Activo', related='economic_sector_id.active')
    economic_sector_id = fields.Many2one('economic.sector', string='Sector')
    legend = fields.Text(string='Leyenda', required='True')

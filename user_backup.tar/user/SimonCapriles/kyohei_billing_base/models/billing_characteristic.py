# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiBillingCharacteristic(models.Model):
    _name = 'billing.characteristic'
    _description = 'Característica de facturación'

    name = fields.Text(string='Característica')
    description = fields.Text(string='Descripción')
    requires_debit_tax = fields.Boolean(string='Con I.V.A.', default=True)
    zero_rate_sale = fields.Boolean(string='Con Tasa Cero', default=False)

# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiBillingBaseCountry(models.Model):
    _inherit = 'res.country'

    in_code = fields.Char(string='Código impuestos')

# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiSinBillingSystem(models.Model):
    _name = 'sin.billing.system'
    _description = 'Sistema de facturación'

    active = fields.Boolean(string='Activo', default=True)
    sequence = fields.Integer(string='Secuencia', default=1)
    name = fields.Char(string='Nombre de sistema')
    company_id = fields.Many2one(
        'res.company',
        domain="['|',('branch_code', '=', False),('vat','!=','')]",
        default=lambda self: self.env.company,
        string='Empresa'
    )
    billing_mode = fields.Selection([], string='Modalidad')

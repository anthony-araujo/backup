# -*- coding: utf-8 -*-

from base64 import b64encode
from io import BytesIO
from qrcode import QRCode, constants
from num2words import num2words
from odoo import models, fields, api, exceptions


class KyoheiBillingBaseAccountMove(models.Model):
    _inherit = 'account.move'

    billing_mode = fields.Selection(
        [('no_invoice', 'Sin factura'),
         ('manual', 'Registro manual')],
        string='Modalidad',
        default='no_invoice',
        copy=False,
        readonly=True,
        states={'draft': [('readonly', False)]}
    )

    @api.onchange('company_id')
    def _set_billing_mode(self):
        if self.company_id:
            self.billing_mode = self.company_id.billing_mode

    # Foreign invoices
    is_foreign = fields.Boolean(
        string='Internacional',
        default=False,
        readonly=True,
        states={'draft': [('readonly', False)]}
    )
    is_policy = fields.Boolean(
        string='Es póliza',
        default=False,
        readonly=True,
        states={'draft': [('readonly', False)]}
    )
    policy_number = fields.Char(
        string='N° póliza',
        readonly=True,
        states={'draft': [('readonly', False)]}
    )
    # SIN related data
    authorization_number = fields.Char(
        string='N° autorización',
        readonly=True,
        states={'draft': [('readonly', False)]},
        copy=False
    )
    sin_number = fields.Char(
        string='N° factura',
        readonly=True,
        states={'draft': [('readonly', False)]},
        copy=False
    )
    sin_state = fields.Selection(
        [
            ('V', 'Válida'),
            ('A', 'Anulada'),
            ('E', 'Extraviada'),
            ('N', 'No utilizado'),
            ('C', 'Contingencia'),
            ('L', 'Libre consignación')
        ],
        string='Estado SIN',
        readonly=True,
        states={'draft': [('readonly', False)]},
        copy=False
    )
    lcv_specification = fields.Selection(
        [
            ('1', 'Compras estándar'),
            ('2', 'Ventas estándar'),
            # ('3', 'Ventas de combustible'),
            # ('4', 'Ventas prevaloradas'),
            # ('5', 'Ventas prevaloradas telecomunicaciones'),
            # ('6', 'Reintergro')
        ],
        string='Especificación',
        default=False
    )

    @api.onchange('type', 'billing_mode')
    def set_default_specification(self):
        if self.billing_mode and self.billing_mode != 'no_invoice':
            if self.type == 'in_invoice':
                self.lcv_specification = '1'
            elif self.type == 'out_invoice':
                self.lcv_specification = '2'
        else:
            self.lcv_specification = False

    control_code = fields.Char(
        string='Código de control',
        default='0',
        readonly=True,
        states={'draft': [('readonly', False)]},
        copy=False
    )
    # Refund data
    is_nullifying = fields.Boolean(string='Anulación', readonly=True, copy=False)
    is_refund = fields.Boolean(string='Devolución', default=False)
    original_sin_number = fields.Char(
        string='Número de factura original',
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=False,
        copy=False
    )
    original_invoice_date = fields.Date(
        string='Fecha factura original',
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=False,
        copy=False
    )
    original_authorization_number = fields.Char(
        string='N° de autorización factura original',
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=False,
        copy=False
    )
    original_total_amount = fields.Float(
        string='Importe total factura original',
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=0.0,
        copy=False
    )
    # Contact data
    partner_document_type = fields.Selection(
        [('1', 'Carnet de identidad'),
         ('2', 'Carnet de identidad de extranjero'),
         ('3', 'Pasaporte'),
         ('4', 'Otro documento de identidad'),
         ('5', 'Número de identificación tributaria (NIT)')],
        readonly=True,
        states={'draft': [('readonly', False)]},
        string='Tipo Documento',
        default='5'
    )
    partner_billing_name = fields.Char(
        string='Razón social',
        readonly=True,
        states={'draft': [('readonly', False)]},
        copy=False
    )
    partner_billing_number = fields.Char(
        string='N° documento',
        readonly=True,
        states={'draft': [('readonly', False)]},
        copy=False
    )
    partner_billing_number_complement = fields.Char(
        string='Complemento',
        readonly=True,
        states={'draft': [('readonly', False)]},
        copy=False
    )

    @api.onchange('partner_id', 'partner_document_type')
    def _onchange_billing_information(self):
        if self.partner_id:
            self.partner_billing_name = self.partner_id.billing_name
            if self.partner_document_type != '1':
                self.partner_billing_number_complement = False
            else:
                self.partner_billing_number_complement = self.partner_id.complement_number
            if self.partner_document_type == '':
                self.partner_billing_number = False
            elif self.partner_document_type == '5':
                self.partner_billing_number = self.partner_id.vat
            else:
                self.partner_billing_number = self.partner_id.document_number

    # Company branch data
    legend = fields.Text(
        string='Leyenda',
        readonly=True,
        copy=False,
    )
    # Tax groups
    specific_fee_tax_group_id = fields.Many2one(related='company_id.specific_fee_tax_group_id')
    credit_debit_tax_group_id = fields.Many2one(related='company_id.credit_debit_tax_group_id')
    other_no_credit_debit_tax_group_id = fields.Many2one(related='company_id.other_no_credit_debit_tax_group_id')
    retention_tax_group_id = fields.Many2one(related='company_id.retention_tax_group_id')
    # Taxes
    policy_credit_tax_id = fields.Many2one(related='company_id.policy_credit_tax_id')
    special_hydrocarbon_tax_id = fields.Many2one(related='company_id.special_hydrocarbon_tax_id')
    game_participation_tax_id = fields.Many2one(related='company_id.game_participation_tax_id')
    rate_tax_id = fields.Many2one(related='company_id.rate_tax_id')
    zero_rate_tax_ids = fields.Many2many(related='company_id.zero_rate_tax_ids')

    total_amount_text = fields.Char(default=0.0, readonly=True)
    # Sale Invoice fields
    billing_characteristic_ids = fields.Many2many(
        'billing.characteristic',
        string='Características',
        copy=False
    )
    # Purchase Invoice fields
    purchase_type = fields.Selection(
        [
            ('1', 'Mercado interno'),
            ('2', 'Mercado interno No gravadas'),
            ('3', 'Sujetas a proporcionalidad'),
            ('4', 'Destino exportaciones'),
            ('5', 'Interno y exportaciones')
        ],
        string='Tipo de compra',
        readonly=True,
        states={'draft': [('readonly', False)]}
    )
    lcv_line_id = fields.Many2one('lcv.line', string='Línea de reporte', copy=False)

    @api.model
    def create(self, vals):
        if vals.get('partner_id'):
            try:
                partner_id = self.env['res.partner'].search([('id', '=', vals.get('partner_id'))])[0]
                if partner_id.billing_name:
                    vals['partner_billing_name'] = partner_id.billing_name
                if partner_id.document_type:
                    vals['partner_document_type'] = partner_id.document_type
                    if partner_id.document_type != '1':
                        vals['partner_billing_number_complement'] = False
                    else:
                        if partner_id.complement_number:
                            vals['partner_billing_number_complement'] = partner_id.complement_number
                else:
                    if self.partner_id.vat:
                        vals['partner_billing_number'] = self.partner_id.vat
            except IndexError:
                pass
        return super(KyoheiBillingBaseAccountMove, self).create(vals)

    def compute_amount_string(self, convert_amount):
        amount = convert_amount
        amount_list = str(amount).split('.')
        if 999 < int(amount_list[0]) < 2000:
            amount_first_part = 'Un ' + num2words(int(amount_list[0].replace(',', '')), lang='es').title() + ' '
        else:
            amount_first_part = num2words(int(amount_list[0].replace(',', '')), lang='es').title() + ' '
        try:
            amount_second_part = amount_list[1]
        except IndexError:
            amount_second_part = []
        if len(amount_second_part) == 0:
            amount_text = amount_first_part + '00/100'
        elif len(amount_second_part) < 2:
            amount_text = amount_first_part + amount_second_part + '0/100'
        else:
            amount_text = amount_first_part + amount_second_part[:2] + '/100'
        return amount_text

    def construct_qr(self, input_string):
        qr = QRCode(
            version=1,
            error_correction=constants.ERROR_CORRECT_L,
            box_size=4,
            border=1,
        )
        qr.add_data(input_string)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        bytes_buffer = BytesIO()
        img.save(bytes_buffer, format="PNG")
        qr_image = b64encode(bytes_buffer.getvalue())
        return qr_image

    def compute_current_invoice_rate(self, invoice_currency_id, company_currency_id, invoice_date):
        current_rate = 1
        if invoice_currency_id != company_currency_id:
            rate_date_records = self.env['res.currency.rate'].search(['&', ['currency_id', '=', invoice_currency_id], ['name', '<=', invoice_date]])
            rate_date_list = []
            for rate_date in rate_date_records:
                rate_date_list.append(rate_date.name)
            if rate_date_list:
                current_rate = self.env['res.currency.rate'].search(['&', ['currency_id', '=', invoice_currency_id], ['name', '=', max(d for d in rate_date_list)]])[0].rate
        return current_rate

    def scan_invoice_qr_code(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Llenar desde QR',
            'res_model': 'purchase.from.qr.wizard',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': self.env.ref('kyohei_billing_base.purchase_from_qr_wizard_form').id,
            'target': 'new',
            'context': {
                'default_invoice_id': self.id,
            }
        }

    def sale_cost_repost(self):
        for move in self:
            move.button_draft()
            move.post()

    def button_draft(self):
        record = super().button_draft()
        for move in self:
            # move marked to_check is for sale_cost_repost
            if move.lcv_line_id and not move.to_check:
                move.lcv_line_id.sudo().unlink()
        return record

    def post(self):
        record = super().post()
        self.action_kyohei_billing_post()
        return record

    def _check_characteristics(self):
        require_debit_tax = True
        allow_zero_rate = False
        if self.billing_mode in ['manual'] and self.billing_characteristic_ids:
            for characteristic in self.billing_characteristic_ids:
                require_debit_tax = False if not characteristic.requires_debit_tax else True
                allow_zero_rate = True if characteristic.zero_rate_sale else False
        return require_debit_tax, allow_zero_rate

    def action_kyohei_billing_post(self):
        for move in self:
            # move marked to_check is for sale_cost_repost
            if not move.to_check:
                if move.type == 'in_receipt':
                    for line in move.line_ids:
                        if line.tax_line_id.id and line.tax_line_id.tax_group_id.id == move.credit_debit_tax_group_id.id:
                            raise exceptions.ValidationError('No puede seleccionar impuestos con Crédito o Débito fiscal en recibos, sólo Retenciones.')
                if move.type in ['in_invoice', 'in_refund', 'out_invoice', 'out_refund'] and move.billing_mode not in ['no_invoice', False] and not move.is_nullifying and not move.is_foreign:
                    if move.billing_mode in ['manual']:
                        if not move.sin_state and move.type in ['out_invoice']:
                            raise exceptions.ValidationError('El "Estado" de la factura no es válida.')
                        if not move.is_policy and (not move.sin_number or move.sin_number == '0'):
                            raise exceptions.ValidationError('El "Número" de la factura no es válida.')
                    # LCV line data
                    purchase_type = False
                    line_type = False
                    # Check basic required data
                    if not move.billing_mode:
                        raise exceptions.ValidationError('Tiene que definir una modalidad de facturación en la pestaña "Impuestos Nacionales".')
                    if not move.partner_billing_number:
                        raise exceptions.ValidationError('''El "Número de facturación" del Contacto no se encuentra definido.
Detalle el número de facturación en los Datos de facturación del Contacto.''')
                    if not move.partner_billing_name:
                        raise exceptions.ValidationError('''La "Razón Social" del Contacto no se encuentra definido.
Detalle la razón social en los Datos de facturación del Contacto.''')
                    if move.company_id.currency_id.id != move.env.ref('base.BOB').id:
                        raise exceptions.ValidationError('''La divisa de la compañía tiene que ser Bolivianos (BOB)''')
                    # Bolivian amount calculation
                    # (
                    #     specific_fee_amount,
                    #     total_discount,
                    #     total_exempt_amount,
                    #     total_zero_rate_amount,
                    #     subtotal_amount,
                    #     no_credit_tax_amount,
                    #     credit_debit_base_amount,
                    #     credit_debit_amount,
                    #     true_total_amount
                    # ) = move.compute_bolivian_tax_amounts()
                    (
                        true_total_amount,
                        total_specific_tax_amount,
                        total_special_hydrocarbon_tax_amount,
                        total_game_participation_tax_amount,
                        total_rate_tax_amount,
                        total_other_no_credit_tax_amount,
                        total_exempt_amount,
                        total_zero_rate_amount,
                        subtotal_amount,
                        total_discount,
                        total_gift_card_amount,
                        credit_debit_base_amount,
                        credit_debit_amount
                    ) = move.compute_bolivian_tax_amounts()
                    if move.type == 'out_invoice':
                        if move.partner_billing_number == '0' and move.amount_total / move.currency_id.rate >= 1000:
                            raise exceptions.ValidationError('''La factura supera los 1000 Bs. y no puede ser facturada Sin Datos de cliente.
Esta factura debe ser registrada por lo menos con el CI y Apellido del cliente.''')
                        # LCV line
                        line_type = 'sale'
                        # Check if there is credit/debit or zero rate taxes in the invoice
                        credit_debit_tax_found = False
                        zero_rate_tax_found = False
                        for line in move.invoice_line_ids:
                            for tax in line.tax_ids:
                                if tax.tax_group_id.id == move.credit_debit_tax_group_id.id and not credit_debit_tax_found:
                                    credit_debit_tax_found = True
                                if tax.id in move.zero_rate_tax_ids.ids and not zero_rate_tax_found:
                                    zero_rate_tax_found = True
                        # Throw errors if not allowed
                        require_debit_tax, allow_zero_rate = self._check_characteristics()
                        if not credit_debit_tax_found and require_debit_tax is True:
                            raise exceptions.ValidationError('''Esta factura debería tener por lo menos un producto que genere crédito fiscal.
Revise las líneas de la factura o seleccione una dosificación que no genere crédito fiscal.''')
                        if zero_rate_tax_found and not allow_zero_rate:
                            raise exceptions.ValidationError('''No puede validar ventas Tasa Cero con esta dosificación.
Revise las líneas de la factura o seleccione una dosificación que le permita realizar ventas con Tasa Cero.''')
                    elif move.type == 'in_invoice':
                        if move.partner_billing_number == '0':
                            raise exceptions.ValidationError('El NIT del Proveedor no puede ser 0.')
                        if not move.purchase_type:
                            raise exceptions.ValidationError('Falta el "Tipo de compra".')
                        elif not move.authorization_number:
                            raise exceptions.ValidationError('Falta el "Número de autorización".')
                        else:
                            if not move.is_policy:
                                if move.authorization_number == '0':
                                    raise exceptions.ValidationError('El "Número de autorización" no puede ser 0.')
                                if move.sin_number == '0':
                                    raise exceptions.ValidationError('El "Número" de la factura no puede ser 0.')
                                if not move.control_code:
                                    raise exceptions.ValidationError('El "Código de control" no es válido.')
                            else:
                                if move.authorization_number != '3':
                                    raise exceptions.ValidationError('En las pólizas de importación el "Número de autorización" debe ser 3.')
                                if not move.policy_number or move.policy_number == 0:
                                    raise exceptions.ValidationError('El "Número de póliza" no es válido.')
                                if move.sin_number != '0':
                                    raise exceptions.ValidationError('En las pólizas de importación el "Número de factura" debe ser 0.')
                                if move.control_code != '0':
                                    raise exceptions.ValidationError('En las pólizas de importación el "Código de control" debe ser 0.')
                            # LCV line
                            line_type = 'purchase'
                            purchase_type = str(move.purchase_type)
                    elif move.type == 'out_refund':
                        # LCV line
                        line_type = 'sale_refund'
                    elif move.type == 'in_refund':
                        # LCV line
                        line_type = 'purchase_refund'
                        purchase_type = str(move.purchase_type)

                    move.action_create_lcv_record(
                        company_id=move.company_id.id,
                        invoice_id=move.id,
                        line_type=line_type,
                        sin_state=move.sin_state,
                        date=move.invoice_date,
                        billing_number=move.partner_billing_number,
                        billing_number_complement=move.partner_billing_number_complement,
                        billing_name=move.partner_billing_name,
                        invoice_number=move.sin_number,
                        policy_number=move.policy_number,
                        authorization_number=move.authorization_number,
                        total_amount=true_total_amount,
                        specific_tax_amount=total_specific_tax_amount,
                        special_hydrocarbon_tax_amount=total_special_hydrocarbon_tax_amount,
                        game_participation_tax_amount=total_game_participation_tax_amount,
                        rate_tax_amount=total_rate_tax_amount,
                        other_no_credit_tax_amount=total_other_no_credit_tax_amount,
                        exempt_amount=total_exempt_amount,
                        zero_rate_amount=total_zero_rate_amount,
                        subtotal_amount=subtotal_amount,
                        discount_amount=total_discount,
                        gift_card_amount=total_gift_card_amount,
                        credit_debit_base_amount=credit_debit_base_amount,
                        credit_debit_amount=credit_debit_amount,
                        control_code=move.control_code,
                        purchase_type=purchase_type,
                        specification=move.lcv_specification,
                        original_invoice_number=move.original_sin_number,
                        original_date=move.original_invoice_date,
                        original_authorization_number=move.original_authorization_number,
                        original_total_amount=move.original_total_amount,
                        branch_code=move.company_id.branch_code
                    )
                    move.write({'lcv_line_id': move.env['lcv.line'].search([['invoice_id', '=', move.id]])[0].id})

    def action_create_lcv_record(
            self,
            company_id,
            invoice_id,
            line_type,
            sin_state,
            date,
            billing_number,
            billing_number_complement,
            billing_name,
            invoice_number,
            authorization_number,
            total_amount,
            specific_tax_amount,
            special_hydrocarbon_tax_amount,
            game_participation_tax_amount,
            rate_tax_amount,
            other_no_credit_tax_amount,
            exempt_amount,
            zero_rate_amount,
            subtotal_amount,
            discount_amount,
            gift_card_amount,
            credit_debit_base_amount,
            credit_debit_amount,
            control_code,
            purchase_type,
            specification,
            branch_code=0,
            policy_number='0',
            original_invoice_number=False,
            original_date=False,
            original_authorization_number=False,
            original_total_amount=False
    ):
        lcv_line_record = self.env['lcv.line']
        lcv_line_record.sudo().create({
            'company_id': company_id,
            'invoice_id': invoice_id,
            'line_type': line_type,
            'sin_state': sin_state,
            'date': date,
            'billing_number': billing_number,
            'billing_number_complement': billing_number_complement,
            'billing_name': billing_name,
            'invoice_number': invoice_number,
            'policy_number': policy_number,
            'authorization_number': authorization_number,
            'total_amount': total_amount,
            'specific_fee_amount': specific_tax_amount,
            'special_hydrocarbon_amount': special_hydrocarbon_tax_amount,
            'game_participation_amount': game_participation_tax_amount,
            'rates_amount': rate_tax_amount,
            'no_credit_tax_amount': other_no_credit_tax_amount,
            'exempt_amount': exempt_amount,
            'zero_rate_amount': zero_rate_amount,
            'subtotal_amount': subtotal_amount,
            'discount_amount': discount_amount,
            'gift_card_amount': gift_card_amount,
            'credit_debit_base_amount': credit_debit_base_amount,
            'credit_debit_amount': credit_debit_amount,
            'control_code': control_code,
            'purchase_type': purchase_type,
            'lcv_specification': specification,
            'original_invoice_number': original_invoice_number,
            'original_date': original_date,
            'original_authorization_number': original_authorization_number,
            'original_total_amount': original_total_amount,
            'branch_code': branch_code
        })

    def compute_bolivian_tax_amounts(self):
        # No credit debit taxes amount calculation
        total_specific_tax_amount = 0.0
        total_special_hydrocarbon_tax_amount = 0.0
        total_game_participation_tax_amount = 0.0
        total_rate_tax_amount = 0.0
        total_other_no_credit_tax_amount = 0.0
        actual_credit_debit_amount = 0.0
        for line in self.line_ids:
            if line.tax_line_id:
                if self.specific_fee_tax_group_id and line.tax_line_id.tax_group_id == self.specific_fee_tax_group_id:
                    total_specific_tax_amount = total_specific_tax_amount + abs(line.balance)
                if self.special_hydrocarbon_tax_id and line.tax_line_id == self.special_hydrocarbon_tax_id:
                    total_special_hydrocarbon_tax_amount = total_special_hydrocarbon_tax_amount + abs(line.balance)
                if self.game_participation_tax_id and line.tax_line_id == self.game_participation_tax_id:
                    total_game_participation_tax_amount = total_game_participation_tax_amount + abs(line.balance)
                if self.rate_tax_id and line.tax_line_id == self.rate_tax_id:
                    total_rate_tax_amount = total_rate_tax_amount + abs(line.balance)
                if self.credit_debit_tax_group_id and line.tax_line_id.tax_group_id == self.credit_debit_tax_group_id:
                    # actual_credit_debit_amount = actual_credit_debit_amount + float(line.credit) if line.credit != 0 else actual_credit_debit_amount + float(line.debit)
                    actual_credit_debit_amount = actual_credit_debit_amount + abs(line.balance)
                if self.other_no_credit_debit_tax_group_id and line.tax_line_id.tax_group_id == self.other_no_credit_debit_tax_group_id:
                    total_other_no_credit_tax_amount = total_other_no_credit_tax_amount + abs(line.balance)
        # Gift card, Discount, Exempt and Zero rate amounts
        total_discount = 0.0
        total_exempt_amount = 0.0
        total_zero_rate_amount = 0.0
        total_gift_card_amount = 0.0
        for line in self.invoice_line_ids:
            # Gift card
            if line.product_id and line.product_id.type == 'gift':
                total_gift_card_amount = total_gift_card_amount + line.price_subtotal
            # Discounts
            if line.discount_type == 'fixed':
                total_discount = total_discount + line.discount
            elif line.discount_type == 'percent':
                total_discount = total_discount + (line.discount / 100) * line.price_unit * line.quantity
            else:
                raise exceptions.ValidationError('El descuento debe ser fijo o porcentual.')
            # Exempt
            if not line.tax_ids:
                total_exempt_amount = total_exempt_amount + line.price_subtotal
            # Zero rate amount
            else:
                for tax in line.tax_ids:
                    if tax.id in self.zero_rate_tax_ids.ids:
                        total_zero_rate_amount = total_zero_rate_amount + line.price_subtotal
        # Currency convert
        company_currency = self.company_id.currency_id
        convert_date = self.invoice_date
        company = self.company_id
        total_discount = self.currency_id._convert(total_discount, company_currency, company, convert_date)
        total_exempt_amount = self.currency_id._convert(total_exempt_amount, company_currency, company, convert_date)
        total_zero_rate_amount = self.currency_id._convert(total_zero_rate_amount, company_currency, company, convert_date)
        total_gift_card_amount = self.currency_id._convert(total_gift_card_amount, company_currency, company, convert_date)
        no_credit_tax_amount = (
                total_specific_tax_amount +
                total_special_hydrocarbon_tax_amount +
                total_game_participation_tax_amount +
                total_rate_tax_amount +
                total_other_no_credit_tax_amount +
                total_exempt_amount +
                total_zero_rate_amount
        )
        # If policy, check for policy tax and compute amount
        if self.is_policy:
            tax_control = 0
            for line in self.invoice_line_ids:
                for tax in line.tax_ids:
                    if tax.tax_group_id.id == self.credit_debit_tax_group_id.id and line.tax_ids.filtered(lambda line_tax: line_tax.tax_group_id.id == self.credit_debit_tax_group_id.id) != self.policy_credit_tax_id:
                        raise exceptions.ValidationError('''El impuesto que calcula el crédito fiscal de esta Póliza de importación no es el adecuado.
Debería utilizarse el impuesto: "%s"''' % self.policy_credit_tax_id.name)
                    tax_control += 1
            if tax_control == 0:
                raise exceptions.ValidationError('Por lo menos una línea de la Póliza debe tener el impuesto: "%s"' % self.policy_credit_tax_id.name)
            credit_debit_amount = actual_credit_debit_amount
            credit_debit_base_amount = (credit_debit_amount * 100) / 13
            true_total_amount = self.currency_id._convert(credit_debit_base_amount + total_zero_rate_amount, company_currency, company, convert_date) + no_credit_tax_amount + total_discount
            subtotal_amount = true_total_amount - no_credit_tax_amount
        else:
            true_total_amount = self.currency_id._convert(self.amount_total, company_currency, company, convert_date) + total_discount
            subtotal_amount = true_total_amount - no_credit_tax_amount
            credit_debit_base_amount = subtotal_amount - total_discount - total_gift_card_amount
            credit_debit_amount = round(credit_debit_base_amount * 0.13, self.currency_id.decimal_places)
            if credit_debit_amount != actual_credit_debit_amount:
                credit_debit_difference = credit_debit_amount - actual_credit_debit_amount
                if abs(credit_debit_difference) <= 0.05:
                    credit_debit_amount = credit_debit_amount - credit_debit_difference
                    if abs(credit_debit_amount - actual_credit_debit_amount) != 0:
                        raise Warning('Existe un error de cálculo, comuníquese con su administrador.')
                else:
                    raise exceptions.ValidationError(
                        '''El importe I.V.A. de la factura no coincide con lo que declarará en los Libros de Compra y Venta:
- I.V.A. Factura: %s
- I.V.A. Libro Compra/Venta: %s
Recuerde que Odoo calcula los importes de la siguiente forma:
- Importe total: Total consignado de factura (A) = %s
- I.C.E.: Montos de impuestos del grupo "I.C.E." (B) = %s
- I.E.H.D.: Montos del impuesto "I.E.H.D." (C) = %s
- I.P.J.: Montos de impuesto "I.P.J." (D) = %s
- Tasas: Montos de impuesto "Tasas" (E) = %s
- Otros no sujetos a crédito fiscal: Montos de impuestos del grupo "O.N.S.C.F." (F) = %s
- Exentos: Suma de las líneas sin impuestos (G) = %s
- Tasa cero: Montos de impuestos del grupo "Tasa cero" (H) = %s
- Subtotal (I): A-B-C-D-E-F-G-H = %s
- Descuentos: Suma de los descuentos fijos y porcentuales de todas las líneas (J) = %s
- Gift card: (K) = %s
- Crédito o Débito fiscal IVA.: Montos de impuestos del grupo "Crédito/Débito fiscal" = %s
Para Impuestos Nacionales el Crédito o Débito se calcula de la siguiente forma:
(I-J-K) * 0.13
Es posible que exista un error en la selección de los impuestos, o que los mismos se encuentren mal configurados.
Revíselos antes de tratar de validar nuevamente.''' % (
                            actual_credit_debit_amount,
                            credit_debit_amount,
                            self.amount_total,
                            total_specific_tax_amount,
                            total_special_hydrocarbon_tax_amount,
                            total_game_participation_tax_amount,
                            total_rate_tax_amount,
                            total_other_no_credit_tax_amount,
                            total_exempt_amount,
                            total_zero_rate_amount,
                            subtotal_amount,
                            total_discount,
                            total_gift_card_amount,
                            actual_credit_debit_amount
                        )
                    )
        # return (
        #     total_specific_tax_amount,
        #     total_discount,
        #     total_exempt_amount,
        #     total_zero_rate_amount,
        #     subtotal_amount,
        #     no_credit_tax_amount,
        #     credit_debit_base_amount,
        #     credit_debit_amount,
        #     true_total_amount,
        # )
        # TODO: Replace function return
        return (
            true_total_amount,
            total_specific_tax_amount,
            total_special_hydrocarbon_tax_amount,
            total_game_participation_tax_amount,
            total_rate_tax_amount,
            total_other_no_credit_tax_amount,
            total_exempt_amount,
            total_zero_rate_amount,
            subtotal_amount,
            total_discount,
            total_gift_card_amount,
            credit_debit_base_amount,
            credit_debit_amount
        )

    def check_addresses(self):
        # Check Company data
        if not self.company_id.street:
            raise exceptions.ValidationError('''La "Dirección" de la Sucursal no se encuentra definida.
Detalle la dirección completa de la sucursal en Ajustes/Usuarios y compañías/Compañías.''')
        if not self.company_id.district:
            raise exceptions.ValidationError('''La "Zona" de la Sucursal no se encuentra definida.
Detalle la zona de la sucursal en Ajustes/Usuarios y compañías/Compañías.''')
        if not self.company_id.state_id:
            raise exceptions.ValidationError('''La "Ciudad" de la Sucursal no se encuentra definida.
Detalle la ciudad de la sucursal en Ajustes/Usuarios y compañías/Compañías.''')
        if not self.company_id.country_id:
            raise exceptions.ValidationError('''El "País" de la Sucursal no se encuentra definida.
Detalle el país de la sucursal en Ajustes/Usuarios y compañías/Compañías.''')
        if not self.company_id.vat:
            raise exceptions.ValidationError('''El "NIT" de la sucursal no se encuetra definida.
Primero llene el NIT de la sucursal en Ajustes/Usuarios y compañías/Compañías''')
        # Check Parent Company data
        if self.company_id.branch_code != 0:
            if self.company_id.parent_id:
                if not self.company_id.parent_id.street:
                    raise exceptions.ValidationError('''La "Dirección" de la Casa matriz no se encuentra definida.
Detalle la dirección completa de la casa matriz en Ajustes/Usuarios y compañías/Compañías.''')
                elif not self.company_id.parent_id.district:
                    raise exceptions.ValidationError('''La "Zona" de la Casa matriz no se encuentra definida.
Detalle la zona de la casa matriz en Ajustes/Usuarios y compañías/Compañías.''')
                elif not self.company_id.parent_id.state_id:
                    raise exceptions.ValidationError('''La "Ciudad" de la Casa matriz no se encuentra definida.
Detalle la ciudad de la casa matriz en Ajustes/Usuarios y compañías/Compañías.''')
                elif not self.company_id.parent_id.country_id:
                    raise exceptions.ValidationError('''El "País" de la Casa matriz no se encuentra definida.
Detalle el país de la casa matriz en Ajustes/Usuarios y compañías/Compañías.''')
            else:
                raise exceptions.ValidationError('''La sucursal de la cual desea emitir no tiene una la casa matriz asignada.
Asigne la casa matriz en Ajustes/Usuarios y compañías/Compañías.''')

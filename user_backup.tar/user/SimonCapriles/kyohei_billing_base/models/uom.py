# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiBillingBaseUom(models.Model):
    _inherit = 'uom.uom'

    code = fields.Char(string='Código impuestos', size=2)


class KyoheiUomCategory(models.Model):
    _inherit = 'uom.category'

    measure_type = fields.Selection(selection_add=[('area', 'Area'), ('power_consumption', 'Consumo de energía')],
                                    string='Tipo de medida')

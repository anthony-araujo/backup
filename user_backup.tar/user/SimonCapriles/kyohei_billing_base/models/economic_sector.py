# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiBillingBaseIndustry(models.Model):
    _name = 'economic.sector'
    _description = 'Sector ecónomico'
    _order = 'sequence'

    active = fields.Boolean(string='Activo')
    name = fields.Char(string='Sector')
    sequence = fields.Integer(string='Secuencia')
    legend_ids = fields.One2many('billing.legend', 'economic_sector_id', string='Actividades económicas')
    company_ids = fields.One2many('res.company', 'economic_sector_id', string='Sucursales')

# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiBillingBaseCurrency(models.Model):
    _inherit = 'res.currency'

    code = fields.Char(string='Código impuestos')
    exchange_rate = fields.Float(compute='_compute_exchange_rate', store=True, string='Tipo de cambio')

    @api.depends('rate')
    def _compute_exchange_rate(self):
        for currency in self:
            rate = currency.rate
            exchange_rate = round(1 / rate, 4)
            currency.write({'exchange_rate': exchange_rate})

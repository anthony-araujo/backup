# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiBillingBasePartner(models.Model):
    _inherit = 'res.partner'

    district = fields.Char(string='Zona')
    billing_name = fields.Char('Razón social', size=200)
    document_type = fields.Selection(
        [('1', 'Carnet de identidad'),
         ('2', 'Carnet de identidad de extranjero'),
         ('3', 'Pasaporte'),
         ('4', 'Otro documento de identidad')],
        string='Tipo documento identidad',
        index=True,
        default=False
    )
    document_number = fields.Char(string='Número de documento', index=True)
    complement_number = fields.Char(string='complemento')

    @api.onchange('name')
    def _onchange_partner_name(self):
        self.billing_name = self.name

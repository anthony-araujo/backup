# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiLcvLine(models.Model):
    _name = 'lcv.line'
    _description = 'Línea Libro de Compras y Ventas'
    _rec_name = 'sequence_id'
    _order = 'date, invoice_number'

    lcv_specification = fields.Selection(
        [
            ('1', 'Compras estándar'),
            ('2', 'Ventas estándar'),
            # ('3', 'Ventas de combustible'),
            # ('4', 'Ventas prevaloradas'),
            # ('5', 'Ventas prevaloradas telecomunicaciones'),
            # ('6', 'Reintergro')
        ],
        string='Especificación'
    )
    sequence_id = fields.Char(string='Línea LCV', readonly=True)
    state = fields.Selection(
        [
            ('draft', 'Borrador'),
            ('declared', 'Declarado')
        ],
        default='draft'
    )
    company_id = fields.Many2one('res.company', string='Sucursal')
    currency_id = fields.Many2one(related='company_id.currency_id')
    branch_code = fields.Integer(string='Código Sucursal')
    invoice_id = fields.Many2one('account.move', string='Factura')
    parent_company_id = fields.Many2one(
        'res.company',
        string='Casa matriz',
        compute='_compute_parent_company_id',
        store=True,
        default=False
    )

    @api.depends('invoice_id')
    def _compute_parent_company_id(self):
        for record in self:
            if not record.company_id:
                raise exceptions.ValidationError('Falta detallar la compañía que generó la línea.')
            else:
                if record.company_id.branch_code != 0:
                    record.parent_company_id = record.company_id.parent_id.id
                else:
                    record.parent_company_id = record.company_id.id

    line_type = fields.Selection(
        [
            ('purchase', 'Compra'),
            ('sale', 'Venta'),
            ('purchase_refund', 'Nota crédito/débito (Compra)'),
            ('sale_refund', 'Nota crédito/débito (Venta)')
        ],
        string='Tipo'
    )
    date = fields.Date(string='Fecha de factura', default=False)
    invoice_number = fields.Char(string='Número factura', default=False)
    billing_number = fields.Char(string='NIT', default=0)
    billing_number_complement = fields.Char(string='Complemento', default=False)
    billing_name = fields.Char(string='Razón social', default='s/n')
    authorization_number = fields.Char(string='Autorización', default=0)
    control_code = fields.Char(string='Código de control', default=False)
    sin_state = fields.Selection(
        [
            ('V', 'Válida'),
            ('A', 'Anulada'),
            ('E', 'Extraviada'),
            ('N', 'No utilizado'),
            ('C', 'Contingencia'),
            ('L', 'Libre consignación')
        ],
        string='Estado')
    policy_number = fields.Char(string='Número de póliza', default=0)
    purchase_type = fields.Selection(
        [
            ('1', 'Mercado interno'),
            ('2', 'Mercado interno No gravadas'),
            ('3', 'Sujetas a proporcionalidad'),
            ('4', 'Destino exportaciones'),
            ('5', 'Interno y exportaciones')
        ],
        string='Tipo de compra'
    )
    sale_type = fields.Selection(
        [('0', 'Otros'),
         ('1', 'Gift card')],
        string='Tipo de venta',
        default='0'
    )
    lcv_report_id = fields.Many2one('lcv.report')
    # Refund data
    original_invoice_number = fields.Char(string='Número original')
    original_date = fields.Date(string='Fecha original')
    original_authorization_number = fields.Char(string='Autorización original')
    original_total_amount = fields.Monetary(string='Total original')
    # Amounts
    total_amount = fields.Monetary(string='Importe total')
    specific_fee_amount = fields.Monetary(string='I.C.E.', default=0.0)
    special_hydrocarbon_amount = fields.Monetary(string='I.E.H.D.')
    game_participation_amount = fields.Monetary(string='I.P.J.', default=0.0)
    rates_amount = fields.Monetary(string='Tasas')
    no_credit_tax_amount = fields.Monetary(string='Otros no sujeto a Crédito fiscal', default=0.0)
    exempt_amount = fields.Monetary(string='Monto exento', default=0.0)
    zero_rate_amount = fields.Monetary(string='Importe tasa cero', default=0.0)
    subtotal_amount = fields.Monetary(string='Subtotal')
    discount_amount = fields.Monetary(string='Descuento')
    gift_card_amount = fields.Monetary(string='Importe gift card')
    credit_debit_base_amount = fields.Monetary(string='Importe base crédito/débito fiscal')
    credit_debit_amount = fields.Monetary(string='Crédito/Débito fiscal')

    @api.model
    def create(self, vals):
        seq = self.env['ir.sequence'].next_by_code('lcv.line.sequence') or '/'
        vals['sequence_id'] = seq
        return super(KyoheiLcvLine, self).create(vals)

    def open_document(self):
        if self.invoice_id:
            return {
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'account.move',
                'res_id': self.invoice_id.id,
                'target': 'current',
                'context': {}
            }

    def remove_lcv_line(self):
        self.sudo().write({'lcv_report_id': False})

# -*- coding: utf-8 -*-

import base64
import datetime
import io
import xlsxwriter

from odoo import models, fields, api, exceptions


class KyoheiLcvReport(models.Model):
    _name = 'lcv.report'
    _description = 'Reporte Libro de Compras y Ventas'

    name = fields.Char(string='Reporte')
    company_id = fields.Many2one('res.company', string='Casa matriz')
    currency_id = fields.Many2one(related='company_id.currency_id')
    report_date = fields.Date(string='Fecha declarada')
    report_period = fields.Selection(
        [
            ('1', 'Enero'),
            ('2', 'Febrero'),
            ('3', 'Marzo'),
            ('4', 'Abril'),
            ('5', 'Mayo'),
            ('6', 'Junio'),
            ('7', 'Julio'),
            ('8', 'Agosto'),
            ('9', 'Septiembre'),
            ('10', 'Octubre'),
            ('11', 'Noviembre'),
            ('12', 'Diciembre')
        ],
        string='Mes',
    )
    report_year = fields.Char(string='Año')
    state = fields.Selection([
        ('draft', 'Borrador'),
        ('declared', 'Declarado')
    ],
        string='Estado'
    )
    report_type = fields.Selection(
        [
            ('purchase', 'Libro de Compras: Estándar'),
            ('sale', 'Libro de Ventas: Estándar'),
            ('purchase_refund', 'Libro de Compras: Notas de Crédito y Débito'),
            ('sale_refund', 'Libro de Ventas: Notas de Crédito y Débito'),
        ],
        string='Tipo de reporte'
    )
    lcv_line_ids = fields.One2many('lcv.line', 'lcv_report_id')
    report_binary = fields.Binary(string='txt', readonly=True)
    report_name = fields.Char(string='Archivo')
    # Valid Amounts
    v_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    v_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Nullified Amounts
    a_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    a_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Lost Amounts
    e_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    e_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Not used Amounts
    n_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    n_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Contingency Amounts
    c_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    c_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Free consignment Amounts
    l_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    l_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Internal market Amounts
    in_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Internal untaxed market Amounts
    un_tx_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    un_tx_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Internal untaxed market Amounts
    pp_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    pp_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Internal untaxed market Amounts
    ex_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    ex_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Internal untaxed market Amounts
    in_ex_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_specific_fee_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_special_hydrocarbon_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_game_participation_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_rates_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_zero_rate_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_exempt_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_no_credit_tax_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_subtotal_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_discount_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_gift_card_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_credit_debit_base_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    in_ex_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    # Refund amounts
    refund_total_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)
    refund_credit_debit_amount = fields.Monetary(compute='_compute_report_amounts', store=True, default=0.0)

    @api.depends('lcv_line_ids', 'state')
    def _compute_report_amounts(self):
        write_dictionary = {}
        amount_list = [
            'total_amount',
            'specific_fee_amount',
            'special_hydrocarbon_amount',
            'game_participation_amount',
            'rates_amount',
            'zero_rate_amount',
            'exempt_amount',
            'no_credit_tax_amount',
            'subtotal_amount',
            'discount_amount',
            'gift_card_amount',
            'credit_debit_base_amount',
            'credit_debit_amount'
        ]
        search_string = ''
        prefix_list = ['v_', 'a_', 'e_', 'n_', 'c_', 'l_', 'in_', 'un_tx_', 'pp_', 'ex_', 'in_ex_']
        field_tar_list = []
        field_tar_dictionary = {'refund_total_amount': 0.0, 'refund_credit_debit_amount': 0.0}
        for record in self:
            for prefix in prefix_list:
                for field in amount_list:
                    field_tar_list.append(prefix + field)
            for field in field_tar_list:
                field_tar_dictionary.setdefault(field, 0.0)
            record.write(field_tar_dictionary)
            if record.report_type == 'sale' or record.report_type == 'purchase_refund':
                for line in record.lcv_line_ids:
                    if line.sin_state == 'V':
                        search_string = 'v_'
                    elif line.sin_state == 'A':
                        search_string = 'a_'
                    elif line.sin_state == 'E':
                        search_string = 'e_'
                    elif line.sin_state == 'N':
                        search_string = 'n_'
                    elif line.sin_state == 'C':
                        search_string = 'c_'
                    elif line.sin_state == 'L':
                        search_string = 'l_'
                    i = 0
                    for field in amount_list:
                        write_dictionary.setdefault(search_string + field, 0.0)
                        write_dictionary[search_string + field] = write_dictionary[search_string + field] + getattr(
                            line, amount_list[i])
                        i = i + 1
            elif record.report_type == 'purchase':
                for line in record.lcv_line_ids:
                    if line.purchase_type == '1':
                        search_string = 'in_'
                    elif line.purchase_type == '2':
                        search_string = 'un_tx_'
                    elif line.purchase_type == '3':
                        search_string = 'pp_'
                    elif line.purchase_type == '4':
                        search_string = 'ex_'
                    elif line.purchase_type == '5':
                        search_string = 'in_ex_'
                    i = 0
                    for field in amount_list:
                        write_dictionary.setdefault(search_string + field, 0.0)
                        write_dictionary[search_string + field] = write_dictionary[search_string + field] + getattr(line, amount_list[i])
                        i = i + 1
            elif record.report_type == 'sale_refund':
                amount_list = ['total_amount', 'credit_debit_amount']
                search_string = 'refund_'
                for line in record.lcv_line_ids:
                    i = 0
                    for field in amount_list:
                        write_dictionary.setdefault(search_string + field, 0.0)
                        write_dictionary[search_string + field] = write_dictionary[search_string + field] + getattr(line, amount_list[i])
                        i = i + 1
            return record.write(write_dictionary)

    def generate_lcv_txt(self):
        if not self.lcv_line_ids:
            raise exceptions.ValidationError('No tiene líneas para generar el archivo.')
        else:
            n = 1
            file_name = ''
            file_content_list = []
            if self.report_type == 'purchase':
                file_name = 'LibroCompras:Estándar/%s/%s.txt' % (self.report_period, self.report_year)
                for line in self.lcv_line_ids:
                    field_list = [
                        'lcv_specification', '|',
                        n, '|',
                        'date', '|',
                        'billing_number', '|',
                        'billing_name', '|',
                        'invoice_number', '|',
                        'policy_number', '|',
                        'authorization_number', '|',
                        'total_amount', '|',
                        'no_credit_tax_amount', '|',
                        'subtotal_amount', '|',
                        'discount_amount', '|',
                        'credit_debit_base_amount', '|',
                        'credit_debit_amount', '|',
                        'control_code', '|',
                        'purchase_type'
                    ]
                    line_string = self.return_line_string(field_list, n, len(self.lcv_line_ids), line.id)
                    file_content_list.append(line_string)
                    n = n + 1
            elif self.report_type == 'sale':
                file_name = 'LibroVentas:Estándar/%s/%s.txt' % (self.report_period, self.report_year)
                for line in self.lcv_line_ids:
                    if line.sin_state == 'A':
                        field_list = [
                            'lcv_specification', '|',
                            n, '|',
                            'date', '|',
                            'invoice_number', '|',
                            'authorization_number', '|',
                            'sin_state', '|',
                            'billing_number', '|',
                            'billing_name', '|',
                            'total_amount', '|',
                            'specific_fee_amount', '|',
                            'exempt_amount', '|',
                            'zero_rate_amount', '|',
                            'subtotal_amount', '|',
                            'discount_amount', '|',
                            'credit_debit_base_amount', '|',
                            'credit_debit_amount', '|',
                            'control_code'
                            ]
                    else:
                        field_list = [
                            'lcv_specification', '|',
                            n, '|',
                            'date', '|',
                            'invoice_number', '|',
                            'authorization_number', '|',
                            'sin_state', '|',
                            'billing_number', '|',
                            'billing_name', '|',
                            'total_amount', '|',
                            'specific_fee_amount', '|',
                            'exempt_amount', '|',
                            'zero_rate_amount', '|',
                            'subtotal_amount', '|',
                            'discount_amount', '|',
                            'credit_debit_base_amount', '|',
                            'credit_debit_amount', '|',
                            'control_code'
                        ]
                    line_string = self.return_line_string(field_list, n, len(self.lcv_line_ids), line.id)
                    file_content_list.append(line_string)
                    n = n + 1
            elif self.report_type == 'purchase_refund':
                file_name = 'LibroCompras:NotasCréditoDébito/%s/%s.txt' % (self.report_period, self.report_year)
                for line in self.lcv_line_ids:
                    field_list = [
                        'lcv_specification', '|',
                        n, '|',
                        'date', '|',
                        'invoice_number', '|',
                        'authorization_number', '|',
                        'sin_state', '|',
                        'billing_number', '|',
                        'billing_name', '|',
                        'total_amount', '|',
                        'credit_debit_amount', '|',
                        'control_code', '|',
                        'original_date', '|',
                        'original_invoice_number', '|',
                        'original_authorization_number', '|',
                        'total_amount'
                    ]
                    line_string = self.return_line_string(field_list, n, len(self.lcv_line_ids), line.id)
                    file_content_list.append(line_string)
                    n = n + 1
            elif self.report_type == 'sale_refund':
                file_name = 'LibroVentas:NotasCréditoDébito/%s/%s.txt' % (self.report_period, self.report_year)
                for line in self.lcv_line_ids:
                    field_list = [
                        'lcv_specification', '|',
                        n, '|',
                        'date', '|',
                        'invoice_number', '|',
                        'authorization_number', '|',
                        'billing_number', '|',
                        'billing_name', '|',
                        'total_amount', '|',
                        'credit_debit_amount', '|',
                        'control_code', '|',
                        'original_date', '|',
                        'original_invoice_number', '|',
                        'original_authorization_number', '|',
                        'total_amount'
                    ]
                    line_string = self.return_line_string(field_list, n, len(self.lcv_line_ids), line.id)
                    file_content_list.append(line_string)
                    n = n + 1
            else:
                pass
            file_content = ''.join(str(line) for line in file_content_list)

            return self.sudo().write({
                'report_name': file_name,
                'report_binary': base64.b64encode(bytes(file_content, 'utf-8'))
            })

    def return_line_string(self, field_list, n, report_size, line_id):
        line_string = ''
        line_registry = self.env['lcv.line'].browse([line_id])
        if n < report_size:
            field_list.append('\n')
        else:
            pass
        for field in field_list:
            if isinstance(field, str):
                if field == '\n' or field == '|':
                    line_string = line_string + field
                else:
                    line_string = line_string + str(getattr(line_registry, field))
            else:
                line_string = line_string + str(field)
        return line_string

    def write_xlsx(self, header_list, field_list):
        fp = io.BytesIO()
        # workbook = xlsxwriter.Workbook(file_name, {'in_memory': True})
        workbook = xlsxwriter.Workbook(fp)
        worksheet = workbook.add_worksheet()
        row = col = 0
        # Write header row
        for header in header_list:
            worksheet.write(row, col, header)
            col += 1
        row += 1
        # Write value rows
        n = 1
        for line in self.lcv_line_ids:
            line_registry = self.env['lcv.line'].browse([line.id])
            worksheet.write(row, 0, n)
            col = 1
            for field in field_list:
                field_value = getattr(line_registry, field)
                if isinstance(field_value, float):
                    value = str(round(getattr(line_registry, field), 2))
                elif isinstance(field_value, datetime.date) or isinstance(field_value, datetime.datetime):
                    value = datetime.datetime.strftime(field_value, '%d/%m/%Y')
                else:
                    value = field_value if field_value else ''
                worksheet.write(row, col, value)
                col += 1
            n += 1
            row += 1
        workbook.close()
        file_base64 = base64.b64encode(fp.getvalue())
        return file_base64

    def generate_xlsx_file(self):
        if not self.lcv_line_ids:
            raise exceptions.ValidationError('No tiene líneas para generar el archivo.')
        else:
            file_name = ''
            header_list = []
            field_list = []
            if self.report_type == 'purchase':
                file_name = 'Registro de Compras %s/%s' % (self.report_period, self.report_year)
                header_list = [
                    'N°',
                    'ESPECIFICACION',
                    'NIT PROVEEDOR',
                    'RAZON SOCIAL PROVEEDOR',
                    'CODIGO DE AUTORIZACION',
                    'NUMERO DE FACTURA',
                    'NUMERO DUI/DIM',
                    'FECHA DE FACTURA/DUI/DIM',
                    'IMPORTE TOTAL COMPRA',
                    'IMPORTE ICE',
                    'IMPORTE IEHD',
                    'IMPORTE IPJ',
                    'TASAS',
                    'OTRO NO SUJETO A CREDITO FISCAL',
                    'IMPORTES EXENTOS',
                    'IMPORTE COMPRAS GRAVADAS A TASA CERO',
                    'SUBTOTAL',
                    'DESCUENTOS/BONIFICACIONES/REBAJAS SUJETAS A IVA',
                    'IMPORTE GIFT CARD',
                    'IMPORTE BASE CF',
                    'CREDITO FISCAL',
                    'TIPO COMPRA',
                    'CODIGO DE CONTROL'
                ]
                field_list = [
                    'lcv_specification',
                    'billing_number',
                    'billing_name',
                    'authorization_number',
                    'invoice_number',
                    'policy_number',
                    'date',
                    'total_amount',
                    'specific_fee_amount',
                    'special_hydrocarbon_amount',
                    'game_participation_amount',
                    'rates_amount',
                    'zero_rate_amount',
                    'exempt_amount',
                    'no_credit_tax_amount',
                    'subtotal_amount',
                    'discount_amount',
                    'gift_card_amount',
                    'credit_debit_base_amount',
                    'credit_debit_amount',
                    'purchase_type',
                    'control_code'
                ]
            elif self.report_type == 'sale':
                file_name = 'Registro de Ventas %s/%s' % (self.report_period, self.report_year)
                header_list = [
                    'N°',
                    'ESPECIFICACION',
                    'FECHA DE LA FACTURA',
                    'N° DE LA FACTURA',
                    'COD. DE AUTORIZACION',
                    'NIT/CI CLIENTE',
                    'COMPLEMENT0',
                    'NOMBRE O RAZON SOCIAL',
                    'IMPORTE TOTAL DE LA VENTA',
                    'IMPORTE ICE',
                    'IMPORTE IEHD',
                    'IMPORTE IPJ',
                    'TASAS',
                    'OTROS NO SUJETOS A IVA',
                    'EXPORTACIONES Y OPERACIONES EXENTAS',
                    'VENTAS GRAVADAS A TASA CERO',
                    'SUB TOTAL',
                    'DESCUENTOS, BONIFICACIONES Y REBAJAS SUJETAS AL IVA',
                    'IMPORTE GIFT CARD',
                    'IMPORTE BASE PARA DEBITO FISCAL',
                    'DEBITO FISCAL',
                    'ESTADO',
                    'CODIGO DE CONTROL',
                    'TIPO DE VENTA'
                ]
                field_list = [
                    'lcv_specification',
                    'date',
                    'invoice_number',
                    'authorization_number',
                    'billing_number',
                    'billing_number_complement',
                    'billing_name',
                    'total_amount',
                    'specific_fee_amount',
                    'special_hydrocarbon_amount',
                    'game_participation_amount',
                    'rates_amount',
                    'no_credit_tax_amount',
                    'exempt_amount',
                    'zero_rate_amount',
                    'subtotal_amount',
                    'discount_amount',
                    'gift_card_amount',
                    'credit_debit_base_amount',
                    'credit_debit_amount',
                    'sin_state',
                    'control_code',
                    'sale_type'
                ]

            return self.sudo().write({
                'report_name': file_name + '.xlsx',
                'report_binary': self.write_xlsx(header_list, field_list)
            })

    def button_update_report(self):
        start_date = '%s-%s-01' % (self.report_year, self.report_period)
        next_period = int(self.report_period) + 1 if int(self.report_period) < 12 else 1
        year = self.report_year if int(self.report_period) < 12 else int(self.report_year) + 1
        end_date = '%s-%s-01' % (year, str(next_period))
        lcv_line_ids = self.env['lcv.line'].search(
            ["&", "&", "&",
             ["date", ">=", start_date],
             ["date", "<", end_date],
             ["line_type", "=", self.report_type],
             ['parent_company_id', '=', self.company_id.id]
             ]
        )
        self.sudo().write({'lcv_line_ids': lcv_line_ids})

    def button_declare_report(self):
        self.generate_xlsx_file()
        for line in self.lcv_line_ids:
            line.sudo().write({'state': 'declared'})
        self.sudo().write({'state': 'declared'})

    def button_draft(self):
        for line in self.lcv_line_ids:
            line.sudo().write({'state': 'draft'})
        self.sudo().write({
            'state': 'draft',
            'report_binary': False,
            'report_name': False
        })

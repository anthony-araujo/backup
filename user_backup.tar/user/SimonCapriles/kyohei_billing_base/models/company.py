# -*- coding: utf-8 -*-

from odoo import models, fields, api
import re


class KyoheiBillingBaseCompany(models.Model):
    _inherit = 'res.company'

    district = fields.Char(string='Zona')
    economic_activity_ids = fields.Many2many(
        'economic.activity',
        'company_activity_rel',
        'economic_activity_ids',
        'company_ids',
        string='Actividades económicas'
    )
    branch_code = fields.Integer(string='Código sucursal')
    economic_sector_id = fields.Many2one('economic.sector', string='Sector económico')
    legend_ids = fields.One2many(string='Leyendas', related='economic_sector_id.legend_ids')
    billing_mode = fields.Selection(
        [('no_invoice', 'Sin factura'),
         ('manual', 'Registro manual')],
        string='Modalidad'
    )
    # Tax groups
    # zero_rate_group_id = fields.Many2one('account.tax.group', string='Tasa cero')
    credit_debit_tax_group_id = fields.Many2one('account.tax.group', string='Crédito/Débito fiscal')
    no_credit_debit_tax_group = fields.Many2one('account.tax.group', string='Sin I.V.A.')
    other_no_credit_debit_tax_group_id = fields.Many2one('account.tax.group', string='Otros no sujetos a I.V.A.')
    specific_fee_tax_group_id = fields.Many2one('account.tax.group', string='I.C.E.')
    retention_tax_group_id = fields.Many2one('account.tax.group', string='Retenciones I.U.E.')
    # Taxes
    policy_credit_tax_id = fields.Many2one('account.tax', string='I.V.A. Pólizas', domain='["&", ["tax_group_id","=",credit_debit_tax_group_id], ["type_tax_use","=","purchase"]]')
    special_hydrocarbon_tax_id = fields.Many2one('account.tax', string='I.E.H.D.', domain='[["tax_group_id","=",no_credit_debit_tax_group]]')
    game_participation_tax_id = fields.Many2one('account.tax', string='I.P.J.', domain='[["tax_group_id","=",no_credit_debit_tax_group]]')
    rate_tax_id = fields.Many2one('account.tax', string='Tasas', domain='[["tax_group_id","=",no_credit_debit_tax_group]]')
    zero_rate_tax_ids = fields.Many2many('account.tax', string='Tasa cero', domain='[["tax_group_id","=",no_credit_debit_tax_group]]')

    system_ids = fields.One2many(
        'sin.billing.system',
        'company_id',
        string='Sistema de facturación'
    )
    # TODO: Check if useful
    complete_address = fields.Char(string='Domicilio Fiscal', readonly=True)

    @api.onchange('street', 'street2', 'city', 'state_id', 'country_id')
    def _compute_complete_address(self):
        for record in self:
            if not record.street2:
                address = 'Calle: %s, Zona: %s, %s - %s' % (
                    record.street,
                    record.city,
                    record.state_id.name,
                    record.country_id.name
                )
            else:
                address = 'Calle: %s, %s, Zona: %s, %s - %s' % (
                    record.street,
                    record.street2,
                    record.city,
                    record.state_id.name,
                    record.country_id.name
                )
            record.complete_address = address

    def camel_case_split(self, identifier):
        matches = re.finditer('.+?(?:(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|$)', identifier)
        return [m.group(0) for m in matches]

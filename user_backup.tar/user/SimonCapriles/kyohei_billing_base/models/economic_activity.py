# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiBillingBaseEconomicActivityGroup(models.Model):
    _name = 'economic.activity.group'
    _description = 'Grupo de actividades económicas'
    _parent_store = True

    name = fields.Char(string='Sector', required='True')
    complete_name = fields.Char('Nombre completo', compute='_compute_complete_name', store=True)

    @api.depends('name', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for group in self:
            if group.parent_id:
                group.complete_name = '%s / %s' % (group.parent_id.complete_name, group.name)
            else:
                group.complete_name = group.name

    parent_id = fields.Many2one('economic.activity.group', string='Padre', ondelete='restrict', index=True)
    parent_path = fields.Char(index=True)
    child_ids = fields.One2many('economic.activity.group', 'parent_id', string='Hijo')
    parent_left = fields.Integer(index=True)
    parent_right = fields.Integer(index=True)

    @api.constrains('parent_id')
    def _check_hierarchy(self):
        if not self._check_recursion():
            raise models.ValidationError('Error! No puede crear actividades recursivas.')


class KyoheiBillingBaseEconomicActivity(models.Model):
    _name = 'economic.activity'
    _description = 'Actividades económicas'
    _rec_name = 'code'

    name = fields.Char(string='Actividad económica', required='True')
    code = fields.Char(string='Código')
    group_parent_id = fields.Many2one(string='Grupo', related='group_id.parent_id', store=True, readonly=True)
    group_id = fields.Many2one('economic.activity.group', string='Sub Grupo')
    company_ids = fields.Many2many(
        'res.company',
        'company_activity_rel',
        'company_ids',
        'economic_activity_ids',
        string='Sucursales'
    )
    complete_name = fields.Char('Nombre completo', compute='_compute_complete_name', store=True)

    @api.depends('name', 'group_id.complete_name')
    def _compute_complete_name(self):
        for record in self:
            if record.group_id:
                record.complete_name = '%s / %s' % (record.group_id.complete_name, record.name)
            else:
                record.complete_name = record.name

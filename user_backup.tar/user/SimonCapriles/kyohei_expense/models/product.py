# -*- coding: utf-8 -*-

from odoo import api, fields, models


class KyoheiExpenseProductTemplate(models.Model):
    _inherit = "product.template"

    can_be_expensed = fields.Boolean(
        string="Es gasto",
        help="Especifique si el producto puede ser seleccionado como gasto."
    )

    @api.onchange('type')
    def _onchange_type_for_expense(self):
        if self.type not in ['consu', 'service']:
            self.can_be_expensed = False

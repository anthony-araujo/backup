# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiExpenseCompany(models.Model):
    _inherit = 'res.company'

    expense_journal_id = fields.Many2one('account.journal', string='Diario de rendición de gastos')
    expense_account_id = fields.Many2one('account.account', string='Cuenta de rendición de gastos')

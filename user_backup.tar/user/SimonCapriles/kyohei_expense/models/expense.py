# -*- coding: utf-8 -*-

import re
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from odoo.tools import email_split, float_is_zero


class KyoheiAccountExpense(models.Model):
    _name = 'account.expense'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Gasto de empleado'
    _check_company_auto = True

    @api.model
    def _default_product_uom_id(self):
        return self.env['uom.uom'].search([], limit=1, order='id')

    state = fields.Selection(
        [('draft', 'Borrador'),
         ('reported', 'Reportado'),
         ('approved', 'Aprobado'),
         ('done', 'Pagado'),
         ('refused', 'Rechazado'),
         ('nullified', 'Anulado')],
        string='Estado',
        compute='_compute_state',
        store=True,
        copy=False,
        index=True,
        readonly=True,
        default='draft'
    )
    name = fields.Char(
        string='Descripción',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)], 'reported': [('readonly', False)], 'refused': [('readonly', False)]}
    )
    date = fields.Date(
        string='Fecha',
        readonly=True,
        states={'draft': [('readonly', False)], 'reported': [('readonly', False)], 'refused': [('readonly', False)]},
        default=fields.Date.context_today
    )

    employee_id = fields.Many2one(
        'hr.employee',
        string='Empleado',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)], 'reported': [('readonly', False)], 'refused': [('readonly', False)]},
        check_company=True
    )

    petty_account_id = fields.Many2one(related='expense_report_id.petty_account_id')
    product_id = fields.Many2one(
        'product.product',
        string='Producto',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)], 'reported': [('readonly', False)], 'refused': [('readonly', False)]},
        domain="[('can_be_expensed', '=', True), '|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        ondelete='restrict'
    )
    product_uom_id = fields.Many2one(
        'uom.uom',
        string='Unit of Measure',
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
        default=_default_product_uom_id,
        domain="[('category_id', '=', product_uom_category_id)]"
    )
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', readonly=True)
    unit_price = fields.Float(
        string='Precio unitario',
        readonly=True,
        required=True,
        states={'draft': [('readonly', False)], 'reported': [('readonly', False)], 'refused': [('readonly', False)]},
        digits='Product Price'
    )
    quantity = fields.Float(
        string='Cantidad',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)], 'reported': [('readonly', False)], 'refused': [('readonly', False)]},
        digits='Product Unit of Measure',
        default=1
    )
    discount_type = fields.Selection(
        [
            ('fixed', 'Fijo'),
            ('percent', 'Porcentual')
        ],
        string='Tipo descuento',
        default='fixed',
        states={'approved': [('readonly', True)]},
    )
    discount = fields.Float(
        string='Descuento',
        default=0.0,
        states={'approved': [('readonly', True)]},
    )
    discount_amount = fields.Float(
        string='Descuento total',
        copy=False,
        compute='_compute_amount',
        store=True,
        default=0.0
    )
    specific_fee_amount = fields.Float(
        string='I.C.E.',
        copy=False,
        readonly=True,
        default=0.0,
        states={'draft': [('readonly', False)]},
    )
    special_hydrocarbon_amount = fields.Float(
        string='I.E.H.D.',
        copy=False,
        readonly=True,
        default=0.0,
        states={'draft': [('readonly', False)]},
    )
    game_participation_amount = fields.Float(
        string='I.P.J.',
        copy=False,
        readonly=True,
        default=0.0,
        states={'draft': [('readonly', False)]},
    )
    rates_amount = fields.Float(
        string='Tasas',
        copy=False,
        readonly=True,
        default=0.0,
        states={'draft': [('readonly', False)]},
    )
    no_credit_tax_amount = fields.Float(
        string='O.N.S.C.F.',
        copy=False,
        readonly=True,
        default=0.0,
        states={'draft': [('readonly', False)]},
    )
    exempt_amount = fields.Float(
        string='Exento',
        copy=False,
        readonly=True,
        default=0.0,
        states={'draft': [('readonly', False)]},
    )
    zero_rate_amount = fields.Float(
        string='Tasa cero',
        copy=False,
        readonly=True,
        default=0.0,
        states={'draft': [('readonly', False)]},
    )
    gift_card_amount = fields.Float(
        string='Gift Card',
        copy=False,
        readonly=True,
        default=0.0,
        states={'draft': [('readonly', False)]},
    )
    tax_ids = fields.Many2many(
        'account.tax',
        'expense_tax',
        'expense_id',
        'tax_id',
        domain="[('company_id', '=', company_id), ('type_tax_use', '=', 'purchase')]",
        string='Impuestos'
    )
    untaxed_amount = fields.Monetary(
        string='Subtotal sin impuesto',
        store=True,
        compute='_compute_amount',
        digits='Account'
    )
    total_amount = fields.Monetary(
        string="Total",
        compute='_compute_amount',
        store=True,
        currency_field='currency_id'
    )
    company_currency_id = fields.Many2one(
        'res.currency',
        string="Divisa de compañía",
        related='expense_report_id.currency_id',
        store=True,
        readonly=False
    )
    total_amount_company = fields.Monetary(
        string="Total (Divisa de compañía)",
        compute='_compute_total_amount_company',
        store=True,
        currency_field='company_currency_id'
    )
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
        default=lambda self: self.env.company
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Divisa',
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
        default=lambda self: self.env.company.currency_id
    )
    analytic_account_id = fields.Many2one(
        'account.analytic.account',
        string='Cuenta analítica',
        check_company=True
    )
    analytic_tag_ids = fields.Many2many(
        'account.analytic.tag',
        string='Etiquetas analíticas',
        states={'post': [('readonly', True)], 'done': [('readonly', True)]},
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]"
    )
    account_id = fields.Many2one(
        'account.account',
        string='Cuenta de gasto',
        default=False,
        domain="[('internal_type', '=', 'other'), ('company_id', '=', company_id)]",
        help="An expense account is expected"
    )
    description = fields.Text(
        string='Notas...',
        readonly=True,
        states={'draft': [('readonly', False)], 'reported': [('readonly', False)], 'refused': [('readonly', False)]}
    )
    reference = fields.Char(
        string="Ref. Gasto"
    )

    expense_report_id = fields.Many2one(
        'account.expense.report',
        string='Reporte de gastos',
        copy=False
    )

    @api.depends('expense_report_id', 'expense_report_id.account_move_id', 'expense_report_id.state')
    def _compute_state(self):
        for expense in self:
            if not expense.expense_report_id or expense.expense_report_id.state == 'draft':
                expense.state = "draft"
            elif expense.expense_report_id.state == "refused":
                expense.state = "refused"
            elif expense.expense_report_id.state == "approve" or expense.expense_report_id.state == "post":
                expense.state = "approved"
            elif not expense.expense_report_id.account_move_id:
                expense.state = "reported"
            elif expense.expense_report_id.state == "nullified":
                expense.state = "nullified"
            else:
                expense.state = "done"

    @api.depends('unit_price', 'quantity', 'tax_ids', 'currency_id', 'discount_type', 'discount',
                 'specific_fee_amount', 'special_hydrocarbon_amount', 'game_participation_amount', 'rates_amount',
                 'no_credit_tax_amount', 'exempt_amount', 'zero_rate_amount', 'gift_card_amount')
    def _compute_amount(self):
        for record in self:
            taxes = record.tax_ids.compute_all(
                record.unit_price,
                record.currency_id,
                record.quantity,
                record.product_id,
                record.employee_id.user_id.partner_id
            )
            expense_total = taxes.get('total_included')
            # Computing discount
            if record.discount_type == 'fixed':
                price_unit_wo_discount = record.unit_price * record.quantity - record.discount
                expense_total -= record.discount
                record.discount_amount = record.discount
            elif record.discount_type == 'percent':
                price_unit_wo_discount = record.unit_price * record.quantity * (1 - (record.discount / 100))
                expense_total = expense_total * (1 - (record.discount / 100))
                record.discount_amount = record.unit_price * record.quantity * (record.discount / 100)
            else:
                raise ValidationError('Debe escoger un tipo de descuento.')
            record.untaxed_amount = price_unit_wo_discount
            # Adding exempt calculation
            if record.specific_fee_amount:
                expense_total += record.specific_fee_amount
            if record.special_hydrocarbon_amount:
                expense_total += record.special_hydrocarbon_amount
            if record.game_participation_amount:
                expense_total += record.game_participation_amount
            if record.rates_amount:
                expense_total += record.rates_amount
            if record.no_credit_tax_amount:
                expense_total += record.no_credit_tax_amount
            if record.exempt_amount:
                expense_total += record.exempt_amount
            if record.zero_rate_amount:
                expense_total += record.zero_rate_amount
            if record.gift_card_amount:
                expense_total += record.gift_card_amount
            record.total_amount = expense_total

    @api.depends('date', 'total_amount', 'company_currency_id')
    def _compute_total_amount_company(self):
        for expense in self:
            amount = 0
            if expense.company_currency_id:
                date_expense = expense.date
                amount = expense.currency_id._convert(
                    expense.total_amount, expense.company_currency_id,
                    expense.company_id, date_expense or fields.Date.today())
            expense.total_amount_company = amount

    @api.onchange('product_id', 'company_id')
    def _onchange_product_id(self):
        if self.product_id:
            if not self.name:
                self.name = self.product_id.display_name or ''
            self.unit_price = self.product_id.price_compute('standard_price')[self.product_id.id]
            self.product_uom_id = self.product_id.uom_id
            self.tax_ids = self.product_id.supplier_taxes_id.filtered(
                lambda tax: tax.company_id == self.company_id)  # taxes only from the same company
            account = self.product_id.product_tmpl_id._get_product_accounts()['expense']
            self.account_id = account

    @api.onchange('company_id')
    def _onchange_expense_company_id(self):
        self.employee_id = self.env['hr.employee'].search(
            [('user_id', '=', self.env.uid), ('company_id', '=', self.company_id.id)])

    @api.onchange('product_uom_id')
    def _onchange_product_uom_id(self):
        if self.product_id and self.product_uom_id.category_id != self.product_id.uom_id.category_id:
            raise UserError(
                'La unidad de medida seleccionada no corresponde a la misma categoría de unidad de medida del producto seleccionado.'
            )

    # ----------------------------------------
    # ORM Overrides
    # ----------------------------------------

    def unlink(self):
        for expense in self:
            if expense.state in ['done', 'approved']:
                raise UserError('No puede eliminar gastos confirmados o aprobados.')
        return super(KyoheiAccountExpense, self).unlink()

    # ----------------------------------------
    # Actions
    # ----------------------------------------

    def action_view_sheet(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'account.expense.report',
            'target': 'current',
            'res_id': self.expense_report_id.id
        }

    def _create_sheet_from_expenses(self):
        if any(expense.state != 'draft' or expense.expense_report_id for expense in self):
            raise UserError("No puede reportar dos veces el mismo gasto.")
        if len(self.mapped('employee_id')) != 1:
            raise UserError("No puede adjuntar gastos de diferentes empleados en el mismo reporte.")
        if any(not expense.product_id for expense in self):
            raise UserError("No puede crear un reporte sin un producto de gasto.")

        todo = self.env['account.expense'].search(
            ["&", ["expense_report_id", "=", False], ["employee_id", "=", self.employee_id.id]]
        )
        sheet = self.env['account.expense.report'].create({
            'company_id': self.company_id.id,
            'employee_id': self[0].employee_id.id,
            'name': todo[0].name if len(todo) == 1 else '',
            'expense_line_ids': [(6, 0, todo.ids)],
            'report_type': 'fund'
        })
        sheet._onchange_employee_id()
        return sheet

    def action_submit_expenses(self):
        sheet = self._create_sheet_from_expenses()
        return {
            'name': 'Nuevo reporte de gastos',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'account.expense.report',
            'target': 'current',
            'res_id': sheet.id
        }

    # ----------------------------------------
    # Business
    # ----------------------------------------

    def _prepare_move_values(self):
        """
        This function prepares move values related to an expense
        """
        self.ensure_one()
        journal = self.expense_report_id.journal_id
        account_date = self.expense_report_id.accounting_date or self.date
        move_values = {
            'journal_id': journal.id,
            'company_id': self.expense_report_id.company_id.id,
            'date': account_date,
            'ref': self.expense_report_id.name,
            # force the name to the default value, to avoid an eventual 'default_name' in the context
            # to set it to '' which cause no number to be given to the account.move when posted.
            'name': '/',
        }
        return move_values

    def _get_account_move_by_sheet(self):
        """ Return a mapping between the expense sheet of current expense and its account move
            :returns dict where key is a sheet id, and value is an account move record
        """
        move_grouped_by_sheet = {}
        for expense in self:
            # create the move that will contain the accounting entries
            if expense.expense_report_id.id not in move_grouped_by_sheet:
                move_vals = expense._prepare_move_values()
                move = self.env['account.move'].with_context(default_journal_id=move_vals['journal_id']).create(
                    move_vals)
                move_grouped_by_sheet[expense.expense_report_id.id] = move
            else:
                move = move_grouped_by_sheet[expense.expense_report_id.id]
        return move_grouped_by_sheet

    def _get_expense_account_source(self):
        self.ensure_one()
        if self.account_id:
            account = self.account_id
        elif self.product_id:
            account = self.product_id.product_tmpl_id.with_context(force_company=self.company_id.id)._get_product_accounts()['expense']
            if not account:
                raise UserError("No tiene una cuenta de gasto configurada para el producto %s (o su categoría), configure una primero." % self.product_id.name)
        else:
            account = self.env['ir.property'].with_context(force_company=self.company_id.id).get(
                'property_account_expense_categ_id', 'product.category')
            if not account:
                raise UserError('Por favor configure una cuenta de gasto por defecto para el producto de gasto:.')
        return account

    # Selecciona cuenta de fondos a rendir o caja chica
    def _get_expense_account_destination(self):
        self.ensure_one()
        if not self.company_id.expense_account_id and not self.petty_account_id:
            raise UserError("""No tiene una cuenta de "Fondos a rendir" definida, revise en la pestaña "Otra información" o en las configuraciones del módulo.""")
        if not self.company_id.expense_account_id and self.expense_report_id.report_type == 'fund':
            raise UserError("No tiene una Cuenta de Fondos a rendir definida en las configuraciones, primero debe configurar alguna.")
        account_dest = self.petty_account_id.id
        return account_dest

    def _get_no_credit_tax_move_lines(self, amount, partner_id):
        account_date = self.expense_report_id.accounting_date or self.date or fields.Date.context_today(self)
        amount_currency = self.currency_id._convert(amount, self.company_id.currency_id, self.company_id, account_date)
        return {
            'quantity': 1,
            'debit': amount if amount > 0 else 0,
            'credit': -amount if amount < 0 else 0,
            'amount_currency': amount_currency if self.currency_id.id != self.company_id.currency_id.id else 0.0,
            'analytic_account_id': self.analytic_account_id.id,
            'analytic_tag_ids': [(6, 0, self.analytic_tag_ids.ids)],
            'expense_id': self.id,
            'currency_id': self.currency_id.id if self.currency_id.id != self.company_id.currency_id.id else False,
            'partner_id': partner_id
        }

    def _update_total_amounts(self, move_line, total_amount, total_amount_currency):
        total_amount += -move_line['debit'] or move_line['credit']
        total_amount_currency += -move_line['amount_currency'] if move_line['currency_id'] else (-move_line['debit'] or move_line['credit'])
        return total_amount, total_amount_currency

    def _get_account_move_line_values(self):
        move_line_values_by_expense = {}
        for expense in self:
            move_line_name = expense.name
            account_src = expense._get_expense_account_source()
            account_dst = expense._get_expense_account_destination()
            account_date = expense.expense_report_id.accounting_date or expense.date or fields.Date.context_today(expense)

            company_currency = expense.company_id.currency_id
            different_currency = expense.currency_id and expense.currency_id != company_currency

            move_line_values = []
            # Discount
            unit_discount = expense.discount_amount / expense.quantity
            unit_price_with_discount = expense.unit_price - unit_discount
            # Changed first parameter in compute_all method to take discount in consideration
            taxes = expense.tax_ids.with_context(round=True).compute_all(
                unit_price_with_discount,
                expense.currency_id,
                expense.quantity,
                expense.product_id
            )
            total_amount = 0.0
            total_amount_currency = 0.0
            if not expense.employee_id.sudo().address_home_id:
                raise UserError("El empleado %s no tiene dirección, Debe asignar una." % expense.employee_id.name)
            partner_id = expense.employee_id.sudo().address_home_id.commercial_partner_id.id

            # source move line
            amount = taxes['total_excluded']
            amount_currency = False
            if different_currency:
                amount = expense.currency_id._convert(amount, company_currency, expense.company_id, account_date)
                amount_currency = taxes['total_excluded']
            move_line_src = {
                'name': move_line_name,
                'quantity': expense.quantity or 1,
                'debit': amount if amount > 0 else 0,
                'credit': -amount if amount < 0 else 0,
                'amount_currency': amount_currency if different_currency else 0.0,
                'account_id': account_src.id,
                'product_id': expense.product_id.id,
                'product_uom_id': expense.product_uom_id.id,
                'analytic_account_id': expense.analytic_account_id.id,
                'analytic_tag_ids': [(6, 0, expense.analytic_tag_ids.ids)],
                'expense_id': expense.id,
                'partner_id': partner_id,
                'tax_ids': [(6, 0, expense.tax_ids.ids)],
                'tag_ids': [(6, 0, taxes['base_tags'])],
                'currency_id': expense.currency_id.id if different_currency else False,
            }
            move_line_values.append(move_line_src)
            total_amount += -move_line_src['debit'] or move_line_src['credit']
            total_amount_currency += -move_line_src['amount_currency'] if move_line_src['currency_id'] else (-move_line_src['debit'] or move_line_src['credit'])

            # Specific fee amounts
            specific_fee_amount = expense.specific_fee_amount
            if specific_fee_amount != 0:
                specific_fee_move_line = {'name': 'I.C.E.', 'account_id': account_src.id}
                specific_fee_move_line.update(expense._get_no_credit_tax_move_lines(specific_fee_amount, partner_id))
                move_line_values.append(specific_fee_move_line)
                total_amount, total_amount_currency = self._update_total_amounts(specific_fee_move_line, total_amount, total_amount_currency)
            # Special hydrocarbon amounts
            special_hydrocarbon_amount = expense.special_hydrocarbon_amount
            if special_hydrocarbon_amount != 0:
                special_hydrocarbon_move_line = {'name': 'I.E.H.D.', 'account_id': account_src.id}
                special_hydrocarbon_move_line.update(expense._get_no_credit_tax_move_lines(special_hydrocarbon_amount, partner_id))
                move_line_values.append(special_hydrocarbon_move_line)
                total_amount, total_amount_currency = self._update_total_amounts(special_hydrocarbon_move_line, total_amount, total_amount_currency)
            # Game participation amounts
            game_participation_amount = expense.game_participation_amount
            if game_participation_amount != 0:
                game_participation_move_line = {'name': 'I.P.J.', 'account_id': account_src.id}
                game_participation_move_line.update(expense._get_no_credit_tax_move_lines(game_participation_amount, partner_id))
                move_line_values.append(game_participation_move_line)
                total_amount, total_amount_currency = self._update_total_amounts(game_participation_move_line, total_amount, total_amount_currency)
            # Rates amounts
            rates_amount = expense.rates_amount
            if rates_amount != 0:
                rates_move_line = {'name': 'Tasas', 'account_id': account_src.id}
                rates_move_line.update(expense._get_no_credit_tax_move_lines(rates_amount, partner_id))
                move_line_values.append(rates_move_line)
                total_amount, total_amount_currency = self._update_total_amounts(rates_move_line, total_amount, total_amount_currency)
            # No credit tax amounts
            no_credit_tax_amount = expense.no_credit_tax_amount
            if no_credit_tax_amount != 0:
                no_credit_tax_move_line = {'name': 'O.N.S.C.F.', 'account_id': account_src.id}
                no_credit_tax_move_line.update(expense._get_no_credit_tax_move_lines(no_credit_tax_amount, partner_id))
                move_line_values.append(no_credit_tax_move_line)
                total_amount, total_amount_currency = self._update_total_amounts(no_credit_tax_move_line, total_amount, total_amount_currency)
            # Exempt amounts
            exempt_amount = expense.exempt_amount
            if exempt_amount != 0:
                exempt_move_line = {'name': 'Exento', 'account_id': account_src.id}
                exempt_move_line.update(expense._get_no_credit_tax_move_lines(exempt_amount, partner_id))
                move_line_values.append(exempt_move_line)
                total_amount, total_amount_currency = self._update_total_amounts(exempt_move_line, total_amount, total_amount_currency)
            # Zero rate amounts
            zero_rate_amount = expense.zero_rate_amount
            if zero_rate_amount != 0:
                zero_rate_move_line = {'name': 'Tasa cero', 'account_id': account_src.id}
                zero_rate_move_line.update(expense._get_no_credit_tax_move_lines(zero_rate_amount, partner_id))
                move_line_values.append(zero_rate_move_line)
                total_amount, total_amount_currency = self._update_total_amounts(zero_rate_move_line, total_amount, total_amount_currency)
            # Gift card amounts
            gift_card_amount = expense.gift_card_amount
            if gift_card_amount != 0:
                gift_card_move_line = {'name': 'Gift card', 'account_id': account_src.id}
                gift_card_move_line.update(expense._get_no_credit_tax_move_lines(gift_card_amount, partner_id))
                move_line_values.append(gift_card_move_line)
                total_amount, total_amount_currency = self._update_total_amounts(gift_card_move_line, total_amount, total_amount_currency)

            # taxes move lines
            for tax in taxes['taxes']:
                amount = tax['amount']
                amount_currency = False
                if different_currency:
                    amount = expense.currency_id._convert(amount, company_currency, expense.company_id, account_date)
                    amount_currency = tax['amount']

                if tax['tax_repartition_line_id']:
                    rep_ln = self.env['account.tax.repartition.line'].browse(tax['tax_repartition_line_id'])
                    base_amount = self.env['account.move']._get_base_amount_to_display(tax['base'], rep_ln)
                else:
                    base_amount = None

                move_line_tax_values = {
                    'name': tax['name'],
                    'quantity': 1,
                    'debit': amount if amount > 0 else 0,
                    'credit': -amount if amount < 0 else 0,
                    'amount_currency': amount_currency if different_currency else 0.0,
                    'account_id': tax['account_id'] or move_line_src['account_id'],
                    'tax_repartition_line_id': tax['tax_repartition_line_id'],
                    'tag_ids': tax['tag_ids'],
                    'tax_base_amount': base_amount,
                    'expense_id': expense.id,
                    'partner_id': partner_id,
                    'currency_id': expense.currency_id.id if different_currency else False,
                    'analytic_account_id': expense.analytic_account_id.id if tax['analytic'] else False,
                    'analytic_tag_ids': [(6, 0, expense.analytic_tag_ids.ids)] if tax['analytic'] else False,
                }
                total_amount -= amount
                total_amount_currency -= move_line_tax_values['amount_currency'] or amount
                move_line_values.append(move_line_tax_values)

            # destination move line
            move_line_dst = {
                'name': move_line_name,
                'debit': total_amount > 0 and total_amount,
                'credit': total_amount < 0 and -total_amount,
                'account_id': account_dst,
                'date_maturity': account_date,
                'amount_currency': total_amount_currency if different_currency else 0.0,
                'currency_id': expense.currency_id.id if different_currency else False,
                'expense_id': expense.id,
                'partner_id': partner_id,
            }
            move_line_values.append(move_line_dst)

            move_line_values_by_expense[expense.id] = move_line_values
        return move_line_values_by_expense

    def action_move_create(self):
        '''
        main function that is called when trying to create the accounting entries related to an expense
        '''
        move_group_by_sheet = self._get_account_move_by_sheet()
        move_line_values_by_expense = self._get_account_move_line_values()
        move_to_keep_draft = self.env['account.move']

        for expense in self:
            # get the account move of the related sheet
            move = move_group_by_sheet[expense.expense_report_id.id]
            # get move line values
            move_line_values = move_line_values_by_expense.get(expense.id)
            # link move lines to move, and move to expense sheet
            move.write({'line_ids': [(0, 0, line) for line in move_line_values]})
            expense.expense_report_id.write({'account_move_id': move.id})

        # post the moves
        for move in move_group_by_sheet.values():
            if move in move_to_keep_draft:
                continue
            move.post()

        return move_group_by_sheet

    def refuse_expense(self, reason):
        self.expense_report_id.write({'state': 'refused'})
        self.expense_report_id.message_post_with_view(
            'kyohei_expense.account_expense_template_refuse_reason',
            values={'reason': reason, 'is_sheet': False, 'name': self.name}
        )

    # ----------------------------------------
    # Mail Thread
    # ----------------------------------------

    @api.model
    def message_new(self, msg_dict, custom_values=None):
        email_address = email_split(msg_dict.get('email_from', False))[0]

        employee = self.env['hr.employee'].search([
            '|',
            ('work_email', 'ilike', email_address),
            ('user_id.email', 'ilike', email_address)
        ], limit=1)

        expense_description = msg_dict.get('subject', '')

        if employee.user_id:
            company = employee.user_id.company_id
            currencies = company.currency_id | employee.user_id.company_ids.mapped('currency_id')
        else:
            company = employee.company_id
            currencies = company.currency_id

        if not company:  # ultimate fallback, since company_id is required on expense
            company = self.env.company

        product, price, currency_id, expense_description = self._parse_expense_subject(expense_description, currencies)
        vals = {
            'employee_id': employee.id,
            'name': expense_description,
            'unit_price': price,
            'product_id': product.id if product else None,
            'product_uom_id': product.uom_id.id,
            'tax_ids': [(4, tax.id, False) for tax in product.supplier_taxes_id],
            'quantity': 1,
            'company_id': company.id,
            'currency_id': currency_id.id
        }

        account = product.product_tmpl_id._get_product_accounts()['expense']
        if account:
            vals['account_id'] = account.id

        expense = super(KyoheiAccountExpense, self).message_new(msg_dict, dict(custom_values or {}, **vals))
        self._send_expense_success_mail(msg_dict, expense)
        return expense

    @api.model
    def _parse_product(self, expense_description):
        product_code = expense_description.split(' ')[0]
        product = self.env['product.product'].search(
            [('can_be_expensed', '=', True), ('default_code', '=ilike', product_code)], limit=1)
        if product:
            expense_description = expense_description.replace(product_code, '', 1)

        return product, expense_description

    @api.model
    def _parse_price(self, expense_description, currencies):
        symbols, symbols_pattern, float_pattern = [], '', '[+-]?(\d+[.,]?\d*)'
        price = 0.0
        for currency in currencies:
            symbols.append(re.escape(currency.symbol))
            symbols.append(re.escape(currency.name))
        symbols_pattern = '|'.join(symbols)
        price_pattern = "((%s)?\s?%s\s?(%s)?)" % (symbols_pattern, float_pattern, symbols_pattern)
        matches = re.findall(price_pattern, expense_description)
        if matches:
            match = max(matches, key=lambda match: len([group for group in match if
                                                        group]))  # get the longuest match. e.g. "2 chairs 120$" -> the price is 120$, not 2
            full_str = match[0]
            currency_str = match[1] or match[3]
            price = match[2].replace(',', '.')

            if currency_str:
                currency = currencies.filtered(lambda c: currency_str in [c.symbol, c.name])[0]
                currency = currency or currencies[0]
            expense_description = expense_description.replace(full_str, ' ')  # remove price from description
            expense_description = re.sub(' +', ' ', expense_description.strip())

        price = float(price)
        return price, currency, expense_description

    @api.model
    def _parse_expense_subject(self, expense_description, currencies):
        product, expense_description = self._parse_product(expense_description)
        price, currency_id, expense_description = self._parse_price(expense_description, currencies)

        return product, price, currency_id, expense_description

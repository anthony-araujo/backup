# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from odoo.tools import email_split, float_is_zero


class KyoheiAccountExpenseReport(models.Model):
    _name = 'account.expense.report'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Rendición de gastos'
    _check_company_auto = True

    @api.model
    def _default_journal_id(self):
        """ The journal is determining the company of the accounting entries generated from expense. We need to force journal company and expense sheet company to be the same. """
        default_company_id = self.default_get(['company_id'])['company_id']
        if self.company_id.expense_journal_id:
            journal = self.company_id.expense_journal_id
        else:
            journal = self.env['account.journal'].search([('type', '=', 'purchase'), ('company_id', '=', default_company_id)], limit=1)
        return journal.id

    state = fields.Selection(
        [('draft', 'Borrador'),
         ('submit', 'Solicitado'),
         ('approve', 'Aprobado'),
         ('post', 'Contabilizado'),
         ('done', 'Cerrado'),
         ('refused', 'Rechazado'),
         ('nullified', 'Anulado')],
        string='Estado',
        index=True,
        readonly=True,
        tracking=True,
        copy=False,
        default='draft',
        required=True
    )
    name = fields.Char(
        string='Descripción',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]}
    )
    expense_line_ids = fields.One2many(
        'account.expense',
        'expense_report_id',
        string='Gastos',
        copy=False,
        readonly=True,
        states={'draft': [('readonly', False)]}
    )
    employee_id = fields.Many2one(
        'hr.employee',
        string='Empleado',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: self.env.user.employee_id,
        check_company=True
    )
    user_id = fields.Many2one(
        'res.users',
        string='Responsable',
        readonly=True,
        copy=False,
        states={'draft': [('readonly', False)]},
        tracking=True
    )
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: self.env.company
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Divisa',
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: self.env.company.currency_id
    )
    journal_id = fields.Many2one(
        'account.journal',
        string='Diario de gastos',
        states={'done': [('readonly', True)], 'post': [('readonly', True)]},
        check_company=True,
        domain="[('type', '=', 'purchase'), ('company_id', '=', company_id)]",
        default=_default_journal_id,
        help="El diario con el cual se generará el asiento del informe de gastos."
    )
    accounting_date = fields.Date(
        string='Fecha contable',
        readonly=True,
        states={'draft': [('readonly', False)]}
    )
    account_move_id = fields.Many2one(
        'account.move',
        string='Asiento contable',
        ondelete='restrict',
        copy=False,
        readonly=True
    )
    revert_move_id = fields.Many2one(
        'account.move',
        string='Asiento de reversión',
        ondelete='restrict',
        copy=False,
        readonly=True
    )
    department_id = fields.Many2one(
        'hr.department',
        string='Departamento',
        states={'post': [('readonly', True)], 'done': [('readonly', True)]}
    )
    is_multiple_currency = fields.Boolean(
        "Para cálculo de importes con diferentes divisas",
        compute='_compute_is_multiple_currency'
    )
    # Request process
    fund_line_ids = fields.One2many(
        'account.expense.fund',
        'expense_report_id',
        string='Fondos y viáticos',
        copy=False,
        readonly=True,
        states={
            'draft': [('readonly', False)],
            'submit': [('readonly', False)],
            'approve': [('readonly', False)],
            'post': [('readonly', False)]
        }
    )
    delivered_draft_amount = fields.Monetary(
        string='Fondos en borrador',
        currency_field='currency_id',
        compute='_compute_amount',
        store=True
    )
    total_delivered_amount = fields.Float(
        string='Total fondos y viáticos',
        currency_field='currency_id',
        compute='_compute_amount',
        store=True
    )
    expense_draft_amount = fields.Monetary(
        string='Gastos en borrador',
        currency_field='currency_id',
        compute='_compute_amount',
        store=True
    )
    total_amount = fields.Monetary(
        string='Total gastos',
        currency_field='currency_id',
        compute='_compute_amount',
        store=True)
    exceeded_amount = fields.Monetary(
        string='Monto excedido',
        currency_field='currency_id',
        compute='_compute_amount',
        store=True
    )
    pending_amount = fields.Monetary(
        string='Monto pendiente',
        currency_field='currency_id',
        compute='_compute_amount',
        store=True
    )
    report_type = fields.Selection(
        [('fund', 'Fondo a rendir'),
         ('petty_cash', 'Caja chica')],
        string='Tipo',
        default=False,
        required=True
    )
    petty_account_id = fields.Many2one(
        'account.account',
        string='Cuenta caja chica',
        default=False,
        domain=[('internal_type', '=', 'liquidity'), ('deprecated', '=', False)]
    )

    @api.onchange('report_type')
    def _onchange_report_type(self):
        if self.report_type == 'fund':
            self.petty_account_id = self.company_id.expense_account_id

    # Added pending and delivered amount calculation
    @api.depends(
        'expense_line_ids', 'expense_line_ids.total_amount_company', 'expense_line_ids.state',
        'fund_line_ids', 'fund_line_ids.delivered_amount', 'fund_line_ids.state'
    )
    def _compute_amount(self):
        for sheet in self:
            delivered_amount = sum(sheet.fund_line_ids.filtered(lambda fund: fund.state == 'posted').mapped('delivered_amount_company'))
            delivered_draft_amount = sum(sheet.fund_line_ids.filtered(lambda fund: fund.state in 'draft').mapped('delivered_amount_company'))
            expense_amount = sum(sheet.expense_line_ids.filtered(lambda expense: expense.state in ('approved', 'done')).mapped('total_amount_company'))
            expense_draft_amount = sum(sheet.expense_line_ids.filtered(lambda expense: expense.state in 'draft').mapped('total_amount_company'))
            exceeded_amount = 0.0
            pending_amount = 0.0
            if delivered_amount > expense_amount:
                pending_amount = delivered_amount - expense_amount
            else:
                exceeded_amount = expense_amount - delivered_amount
            sheet.delivered_draft_amount = delivered_draft_amount
            sheet.total_delivered_amount = delivered_amount
            sheet.expense_draft_amount = expense_draft_amount
            sheet.total_amount = expense_amount
            sheet.pending_amount = pending_amount
            sheet.exceeded_amount = exceeded_amount

    @api.depends('expense_line_ids.currency_id')
    def _compute_is_multiple_currency(self):
        for sheet in self:
            sheet.is_multiple_currency = len(sheet.expense_line_ids.mapped('currency_id')) > 1

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        self.department_id = self.employee_id.department_id
        self.user_id = self.employee_id.parent_id.user_id

    @api.constrains('expense_line_ids', 'employee_id')
    def _check_employee(self):
        for sheet in self:
            employee_ids = sheet.expense_line_ids.mapped('employee_id')
            if len(employee_ids) > 1 or (len(employee_ids) == 1 and employee_ids != sheet.employee_id):
                raise ValidationError('Usted no puede agregar gastos de otro empleado.')

    @api.constrains('expense_line_ids', 'company_id')
    def _check_expense_lines_company(self):
        for sheet in self:
            if not all(expense.company_id == sheet.company_id for expense in sheet.expense_line_ids):
                raise ValidationError('Sólo se pueden asociar gastos de la misma compañía.')

    @api.model
    def create(self, vals):
        sheet = super(KyoheiAccountExpenseReport,
                      self.with_context(mail_create_nosubscribe=True, mail_auto_subscribe_no_notify=True)).create(vals)
        return sheet

    def unlink(self):
        for expense in self:
            if expense.state in ['post', 'done']:
                raise UserError('No puede eliminar un "Reporte de gasto" contabilizado o pagado.')
        super(KyoheiAccountExpenseReport, self).unlink()

    # --------------------------------------------
    # Mail Thread
    # --------------------------------------------

    def _message_auto_subscribe_followers(self, updated_values, subtype_ids):
        res = super(KyoheiAccountExpenseReport, self)._message_auto_subscribe_followers(updated_values, subtype_ids)
        if updated_values.get('employee_id'):
            employee = self.env['hr.employee'].browse(updated_values['employee_id'])
            if employee.user_id:
                res.append((employee.user_id.partner_id.id, subtype_ids, False))
        return res

    # --------------------------------------------
    # Actions
    # --------------------------------------------

    def action_report_move_create(self):
        if any(sheet.state != 'approve' for sheet in self):
            raise UserError("Sólo puede crear asientos por gastos aprobados.")

        if any(not sheet.journal_id for sheet in self):
            raise UserError("Los gastos deben tener un diario de Rendición de gastos para generar asientos.")

        expense_line_ids = self.mapped('expense_line_ids').filtered(lambda r: not float_is_zero(
            r.total_amount,
            precision_rounding=(r.currency_id or self.env.company.currency_id).rounding
        ))
        res = expense_line_ids.action_move_create()

        if not self.accounting_date:
            self.accounting_date = self.account_move_id.date

        self.write({'state': 'post'})
        return res

    # --------------------------------------------
    # Business
    # --------------------------------------------

    def set_to_paid(self):
        self.write({'state': 'done'})

    def action_submit_report(self):
        if not self.expense_line_ids:
            raise UserError('No puede confirmar una "Rendición de gasto" sin gastos asociados.')
        if self.user_has_groups('kyohei_expense.kyohei_expense_admin_group'):
            self.action_approve_report()

        else:
            self.write({'state': 'submit'})

    def action_approve_report(self):
        if not self.user_has_groups('kyohei_expense.kyohei_expense_admin_group'):
            raise UserError('Sólo un administrador de gastos puede aprobar gastos.')
        responsible_id = self.user_id.id or self.env.user.id
        self.write({
            'state': 'approve',
            'user_id': responsible_id
        })
        if self.user_has_groups('account.group_account_invoice'):
            if self.report_type == 'petty_cash':
                if not self.petty_account_id:
                    raise UserError('Si es Caja chica, tiene que detallar la cuenta de caja chica en "Otra información".')
                else:
                    self.action_report_move_create()
            elif self.report_type == 'fund':
                self.action_report_move_create()

    def action_report_close(self, payment_journal=None, payment_ref=None):
        if self.fund_line_ids:
            for fund in self.fund_line_ids:
                if fund.state not in ['approved', 'posted']:
                    raise UserError('Tiene que aprobar o contabilizar todos los Fondos y Viáticos asociados al Reporte.')
        self._compute_amount()
        if not payment_journal and self.total_amount != self.total_delivered_amount:
            return {
                'context': {
                    'default_report_id': self.id,
                    'default_company_id': self.company_id.id
                },
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'account.expense.fund.detail.wizard',
                'view_id': self.env.ref('kyohei_expense.account_expense_fund_detail_wizard_view_form').id,
                'type': 'ir.actions.act_window',
                'target': 'new',
            }
        if self.total_delivered_amount - self.total_amount != 0:
            fund_name = ''
            fund_ref = ''
            closing_amount = 0
            if self.exceeded_amount > 0:
                if payment_ref is None:
                    fund_ref = 'Devolución por gastos: %s' % self.name
                else:
                    fund_ref = 'Devolución "%s": ' % self.name + payment_ref
                closing_amount = self.exceeded_amount
                fund_name = 'Pago a %s' % self.employee_id.name
            elif self.pending_amount > 0:
                if payment_ref is None:
                    fund_ref = 'Devolución de Fondos: %s' % self.name
                else:
                    fund_ref = 'Devolución de Fondos "%s": ' % self.name + payment_ref
                closing_amount = -self.pending_amount
                fund_name = 'Cobro a %s' % self.employee_id.name
            fund_values = {
                'name': fund_name,
                'date': self.accounting_date,
                'employee_id': self.employee_id.id,
                'authorizing_user_id': self.user_id.id,
                'journal_id': payment_journal.id,
                'ref': fund_ref,
                'delivered_amount': closing_amount,
                'expense_report_id': self.id
            }
            closing_fund = self.env['account.expense.fund']
            funds = closing_fund.create(fund_values)
            if self.user_has_groups('account.group_account_invoice'):
                if self.report_type == 'petty_cash' and not self.petty_account_id:
                    raise UserError('Si es Caja chica, tiene que detallar la cuenta de caja chica en "Otra información".')
                funds.action_post_fund()

        expense_report_moves = self.account_move_id.line_ids.filtered(lambda line: line.account_id == self.company_id.expense_account_id and not line.reconciled)
        for fund in self.fund_line_ids:
            expense_report_moves += fund.account_move_id.line_ids.filtered(lambda line: line.account_id == self.company_id.expense_account_id and not line.reconciled)
        expense_report_moves.reconcile()
        self.set_to_paid()

    def refuse_report(self, reason):
        if not self.user_has_groups('kyohei_expense.kyohei_expense_admin_group'):
            raise UserError("Sólo administradores de gastos pueden rechazar 'Rendiciones de gastos'.")

        self.write({'state': 'refused'})
        for sheet in self:
            sheet.message_post_with_view(
                'kyohei_expense.account_expense_template_refuse_reason',
                values={'reason': reason, 'is_sheet': True, 'name': self.name}
            )

    def reset_expense_report(self):
        if self.account_move_id:
            self.account_move_id.button_draft()
            self.account_move_id.write({'ref': 'Cancelado por %s el %s' % (self.env.user.name, fields.Datetime.now())})
            self.account_move_id.button_cancel()
        self.mapped('expense_line_ids').write({'state': 'draft'})
        self.mapped('fund_line_ids').action_draft()
        self.write({'state': 'draft'})
        return True

    def reverse_report_move(self):
        for fund in self.fund_line_ids:
            fund.expense_report_id = False
        if self.account_move_id:
            move_reversal = self.env['account.move.reversal'].with_context(
                active_model="account.move",
                active_ids=[self.account_move_id.id]
            ).create({
                'date': fields.Date.context_today(self),
                'reason': 'Error en rendición',
                'refund_method': 'cancel',
            })
            reversal = move_reversal.reverse_moves()
            reverse_move_id = self.env['account.move'].browse(reversal['res_id']).id
            self.write({
                'state': 'nullified',
                'revert_move_id': reverse_move_id
            })
        else:
            self.write({'state': 'nullified'})

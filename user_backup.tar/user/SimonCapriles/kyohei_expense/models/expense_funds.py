# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError


class KyoheiAccountExpenseFunds(models.Model):
    _name = 'account.expense.fund'
    _description = 'Fondos y viáticos'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _check_company_auto = True

    name = fields.Char(
        string='Descripción',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]})
    ref = fields.Char(
        string='Circular',
        copy=False,
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
    )
    state = fields.Selection(
        [('draft', 'Borrador'),
         ('requested', 'solicitado'),
         ('approved', 'Aprobado'),
         ('posted', 'Validado'),
         ('refused', 'Rechazado'),
         ('nullified', 'Anulado')],
        string='Estado',
        copy=False,
        readonly=True,
        default='draft'
    )
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: self.env.company
    )
    petty_account_id = fields.Many2one(related='expense_report_id.petty_account_id')

    @api.model
    def _default_employee_id(self):
        return self.env.user.employee_id

    employee_id = fields.Many2one(
        'hr.employee',
        string='Solicitante',
        default=_default_employee_id,
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
    )
    date = fields.Date(
        string='Fecha',
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=fields.Date.context_today
    )
    expense_report_id = fields.Many2one('account.expense.report', string='Rendición')
    delivered_amount = fields.Monetary(
        string='Importe',
        currency_field='currency_id',
        copy=False,
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]}
    )
    company_currency_id = fields.Many2one(
        'res.currency',
        string="Divisa de compañía (reporte)",
        related='expense_report_id.currency_id',
        store=True,
        readonly=False
    )
    delivered_amount_company = fields.Monetary(
        string='Monto entregado (Divisa de compañía)',
        compute='_compute_delivered_amount_company',
        store=True,
        currency_field='company_currency_id'
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Divisa',
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
        default=lambda self: self.env.company.currency_id
    )
    authorizing_user_id = fields.Many2one(
        'res.users',
        string='Autorizado por',
        readonly=True,
        copy=False
    )
    journal_id = fields.Many2one(
        'account.journal',
        string='Diario',
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
        domain="[('type', 'in', ('bank', 'cash')), ('company_id', '=', company_id)]"
    )
    account_move_id = fields.Many2one(
        'account.move',
        string='Asiento contable',
        ondelete='restrict',
        copy=False,
        readonly=True
    )
    revert_move_id = fields.Many2one(
        'account.move',
        string='Asiento de reversión',
        ondelete='restrict',
        copy=False,
        readonly=True
    )

    @api.depends('date', 'delivered_amount', 'company_currency_id')
    def _compute_delivered_amount_company(self):
        for fund in self:
            amount = 0
            if fund.company_currency_id:
                date_expense = fund.date
                amount = fund.currency_id._convert(
                    fund.delivered_amount, fund.company_currency_id,
                    fund.company_id, date_expense or fields.Date.today())
            fund.delivered_amount_company = amount

    def action_submit_fund(self):
        self.write({'state': 'requested'})
        if self.user_has_groups('kyohei_expense.kyohei_expense_admin_group'):
            self.action_approve_fund()

    def action_approve_fund(self):
        if not self.user_has_groups('kyohei_expense.kyohei_expense_admin_group'):
            raise UserError('Sólo administradores de gastos pueden aprobar Fondos o Viáticos')
        if self.delivered_amount == 0:
            raise UserError('El Fondo o Viático no puede tener valor 0.')
        authorizing_user_id = self.expense_report_id.user_id.id or self.env.user.id
        self.write({
            'state': 'approved',
            'authorizing_user_id': authorizing_user_id
        })
        if self.user_has_groups('account.group_account_invoice'):
            self.action_post_fund()

    def action_post_fund(self):
        if not self.user_has_groups('account.group_account_invoice'):
            raise UserError('Sólo los usuarios de contabilidad pueden generar asientos.')
        if not self.journal_id:
            raise UserError('Tiene que definir un diario para poder contabilizar el Fondo o Viático.')
        self.write({
            'state': 'posted',
            'account_move_id': self.fund_move_create()[0].id
        })
        self.account_move_id.post()

    def fund_move_create(self):
        for fund in self:
            if not fund.authorizing_user_id:
                raise UserError('No puede crear asientos de un "Fondos o viáticos" sin un usuario responsable.')
            if not fund.company_id.expense_account_id:
                raise ValidationError('No tiene una cuenta de Rendición de gastos, configure una primero.')
            if fund.delivered_amount == 0:
                raise ValidationError('No puede crear asientos de "Fondos o viáticos" con valor 0.')
            destination_account_id = self.petty_account_id
            move_partner = fund.employee_id.sudo().address_home_id.commercial_partner_id.id
            counterpart_amount = fund.delivered_amount
            if fund.delivered_amount > 0:
                liquidity_line_account = fund.journal_id.default_debit_account_id
                move_line_name = 'Entrega de Fondos/Viáticos a %s' % fund.employee_id.name
            else:
                liquidity_line_account = fund.journal_id.default_credit_account_id
                move_line_name = 'Devolución de Fondos/Viáticos entregados a %s' % fund.employee_id.name
            # Check fund currency
            company_currency = fund.company_id.currency_id
            if fund.currency_id == company_currency:
                # Single-currency.
                balance = counterpart_amount
                counterpart_amount = 0.0
                currency_id = False
            else:
                # Multi-currencies.
                balance = fund.currency_id._convert(counterpart_amount, company_currency, fund.company_id, fund.date)
                currency_id = fund.currency_id.id

            # Check journal currency
            if fund.journal_id.currency_id and fund.currency_id != fund.journal_id.currency_id:
                # Custom currency on journal.
                if fund.journal_id.currency_id == company_currency:
                    # Single-currency
                    liquidity_line_currency_id = False
                else:
                    liquidity_line_currency_id = fund.journal_id.currency_id.id
                liquidity_amount = company_currency._convert(
                    balance, fund.journal_id.currency_id, fund.company_id, fund.date)
            else:
                # Use the payment currency.
                liquidity_line_currency_id = currency_id
                liquidity_amount = counterpart_amount

            move_values = {
                'date': fund.date,
                'ref': fund.ref,
                'journal_id': fund.journal_id.id,
                'currency_id': fund.journal_id.currency_id.id or fund.company_id.currency_id.id,
                'partner_id': move_partner,
                'line_ids': [
                    (0, 0, {
                        'name': move_line_name,
                        'amount_currency': counterpart_amount if currency_id else 0.0,
                        'currency_id': currency_id,
                        'debit': balance > 0.0 and balance or 0.0,
                        'credit': balance < 0.0 and -balance or 0.0,
                        'date_maturity': fund.date,
                        'partner_id': move_partner,
                        'account_id': destination_account_id.id,
                    }),
                    # Liquidity line.
                    (0, 0, {
                        'name': fund.name,
                        'amount_currency': -liquidity_amount if liquidity_line_currency_id else 0.0,
                        'currency_id': liquidity_line_currency_id,
                        'debit': balance < 0.0 and -balance or 0.0,
                        'credit': balance > 0.0 and balance or 0.0,
                        'date_maturity': fund.date,
                        'partner_id': move_partner,
                        'account_id': liquidity_line_account.id,
                    }),
                ],
            }
            account_move = self.env['account.move'].with_context(default_type='entry')
            moves = account_move.create(move_values)
        return moves

    def action_reverse_fund(self):
        reverse_move_id = False
        if self.account_move_id:
            move_reversal = self.env['account.move.reversal'].with_context(
                active_model="account.move",
                active_ids=[self.account_move_id.id]
            ).create({
                'date': fields.Date.context_today(self),
                'reason': 'Devolución de fondos',
                'refund_method': 'cancel',
            })
            reversal = move_reversal.reverse_moves()
            reverse_move_id = self.env['account.move'].browse(reversal['res_id']).id
        self.write({
            'state': 'nullified',
            'revert_move_id': reverse_move_id,
            'expense_report_id': False
        })

    def action_draft(self):
        self.state = 'draft'
        if self.account_move_id:
            self.account_move_id.button_draft()
            self.account_move_id.write({'ref': 'Cancelado por %s el %s' % (self.env.user.name, fields.Datetime.now())})
            self.account_move_id.button_cancel()

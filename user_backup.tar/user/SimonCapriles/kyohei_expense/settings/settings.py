# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiExpenseSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    expense_journal_id = fields.Many2one(
        'account.journal',
        string='Diario de gastos',
        related='company_id.expense_journal_id',
        readonly=False,
        domain="[('type', '=', 'purchase'), ('company_id', '=', company_id)]",
        context="{'default_type': 'purchase'}"
    )
    expense_account_id = fields.Many2one(
        'account.account',
        string='Cuenta de rendición de gastos',
        related='company_id.expense_account_id',
        readonly=False,
        domain="[('internal_type', '=', 'receivable'), ('deprecated', '=', False)]"
    )

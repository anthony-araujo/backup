# -*- coding: utf-8 -*-
{
    'name': "Rendición de gastos / Kyohei Ltda.",

    'summary': """
        El módulo permite registrar gastos de los empleados en Odoo
        """,

    'description': """
    Obtenga las funciones básicas para registrar y rendir gastos de los empleados
======================================================================================================

Con la instalación del módulo usted obtendrá:
    * Las Actividades económicas y leyendas vigentes
    * Los tipos de unidad de medida, códigos de divisas y países normados
    
    """,
    'author': "Kyohei Ltda.",
    'website': "http://www.kyohei.com.bo",
    'category': 'Invoicing Management',
    'version': '13.0.0.1',
    'depends': ['hr', 'account'],
    'license': 'OPL-1',
    'installable': True,
    'application': True,
    'data': [
        'data/mail_data.xml',
        'wizard/expense_refuse_reason.xml',
        'wizard/fund_detail_view.xml',
        'security/security_groups.xml',
        'security/ir.model.access.csv',
        'views/root_view.xml',
        'settings/settings_view.xml',
        'views/expense_view.xml',
        'views/expense_funds_view.xml',
        'views/expense_report_view.xml',
        'views/product_view.xml',
    ]
}

# -*- coding: utf-8 -*-

from odoo import api, fields, models


class AccountExpenseRefuseWizard(models.TransientModel):
    """This wizard can be launched from an account.expense
    or from an account.expense.report
    'expense_refuse_model' must be passed in the context to differentiate
    the right model to use.
    """

    _name = "account.expense.refuse.wizard"
    _description = "Wizard de razón de rechazo"

    reason = fields.Char(string='Razón', required=True)
    expense_ids = fields.Many2many('account.expense')
    expense_report_id = fields.Many2one('account.expense.report')

    @api.model
    def default_get(self, fields):
        res = super(AccountExpenseRefuseWizard, self).default_get(fields)
        active_ids = self.env.context.get('active_ids', [])
        refuse_model = self.env.context.get('expense_refuse_model')
        if refuse_model == 'account.expense':
            res.update({
                'expense_ids': active_ids,
                'expense_report_id': False,
            })
        elif refuse_model == 'account.expense.report':
            res.update({
                'expense_report_id': active_ids[0] if active_ids else False,
                'expense_ids': [],
            })
        return res

    def expense_refuse_reason(self):
        self.ensure_one()
        if self.expense_ids:
            self.expense_ids.refuse_expense(self.reason)
        if self.expense_report_id:
            self.expense_report_id.refuse_report(self.reason)

        return {'type': 'ir.actions.act_window_close'}

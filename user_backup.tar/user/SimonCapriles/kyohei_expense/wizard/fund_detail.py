# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import UserError


class AccountExpenseRefuseWizard(models.TransientModel):
    _name = "account.expense.fund.detail.wizard"
    _description = "Wizard para detallar entrega de fondos"

    company_id = fields.Many2one('res.company')
    report_id = fields.Many2one('account.expense.report')
    journal_id = fields.Many2one(
        'account.journal',
        string='Método de pago',
        domain="[('type', 'in', ('bank', 'cash')), ('company_id', '=', company_id)]"
    )
    ref = fields.Char(string='Circular')

    def confirm_fund_detail(self):
        if not self.report_id:
            raise UserError('Solo puede crear Fondos / Viáticos / Caja chica desde una rendición de gasto.')
        self.report_id.action_report_close(payment_journal=self.journal_id, payment_ref=self.ref)

# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError


class KyoheiExpenseBranches(models.Model):
    _inherit = 'account.expense'

    branch_id = fields.Many2one(
        'res.company.branch',
        string='Sucursal',
        domain="[['company_id','=',company_id]]",
        copy=False,
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
    )

    def action_move_create(self):
        record = super().action_move_create()
        for expense in self:
            if not expense.branch_id:
                raise UserError('''El gasto "%s" no tiene una Sucursal asignada.
Asigne una antes de solicitar nuevamente.''' % expense.name)
            if expense.branch_id != expense.expense_report_id.branch_id:
                raise UserError('''El gasto "%s" no tiene la misma Sucursal del Reporte de gasto.
No puede confirmar gastos que no sean de la misma sucursal.''' % expense.name)
        return record

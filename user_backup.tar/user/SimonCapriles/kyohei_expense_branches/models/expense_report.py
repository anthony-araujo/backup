# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError


class KyoheiExpenseReportBranches(models.Model):
    _inherit = 'account.expense.report'

    branch_id = fields.Many2one(
        'res.company.branch',
        string='Sucursal',
        domain="[['company_id','=',company_id]]",
        copy=False,
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
    )

    def action_submit_report(self):
        record = super().action_submit_report()
        if not self.branch_id:
            raise UserError('''El Reporte de gasto no tiene una Sucursal asignada.
Asigne antes de tratar de validar nuevamente.''')
        return record

    def action_report_close(self):
        if self.total_delivered_amount - self.total_amount != 0:
            fund_name = ''
            fund_ref = ''
            closing_amount = 0
            if self.exceeded_amount > 0:
                fund_ref = 'Pago a %s como devolución por mayores gastos del Reporte: %s' % (self.employee_id.name, self.name)
                closing_amount = self.exceeded_amount
                fund_name = 'Pago a %s' % self.employee_id.name
            elif self.pending_amount > 0:
                fund_ref = 'Cobro a %s como devolución de Fondos/Viáticos del Reporte: %s' % (self.employee_id.name, self.name)
                closing_amount = -self.pending_amount
                fund_name = 'Cobro a %s' % self.employee_id.name
            fund_values = {
                'name': fund_name,
                'date': self.accounting_date,
                'employee_id': self.employee_id.id,
                'authorizing_user_id': self.user_id.id,
                'journal_id': self.env['account.journal'].search([('type', '=', 'cash'), ('company_id', '=', self.company_id.id)], limit=1).id,
                'branch_id': self.branch_id.id,
                'ref': fund_ref,
                'delivered_amount': closing_amount,
                'expense_report_id': self.id
            }
            closing_fund = self.env['account.expense.fund']
            funds = closing_fund.create(fund_values)
            if self.user_has_groups('account.group_account_invoice'):
                funds.action_post_fund()

        self.set_to_paid()

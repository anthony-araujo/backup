# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError


class KyoheiExpenseFundBranches(models.Model):
    _inherit = 'account.expense.fund'

    branch_id = fields.Many2one(
        'res.company.branch',
        string='Sucursal',
        domain="[['company_id','=',company_id]]",
        copy=False,
        readonly=True,
        states={'draft': [('readonly', False)], 'refused': [('readonly', False)]}
    )

    def action_submit_fund(self):
        record = super().action_submit_fund()
        if not self.branch_id:
            raise UserError('''El Fondo/Viático no tiene una Sucursal asignada.
Asigne una antes de solicitar nuevamente.''')
        return record

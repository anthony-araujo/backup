# -*- coding: utf-8 -*-
{
    'name': "kyohei_expense_branches",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,
    'author': "Kyohei Ltda.",
    'website': "http://www.kyohei.com.bo",
    'category': 'Invoicing Management', 'Operations'
    'version': '13.0.0.1',
    'depends': ['kyohei_expense', 'kyohei_branches_base'],
    'auto_install': True,
    'license': 'OPL-1',
    'data': [
        'security/security_rules.xml',
        'views/expense_view.xml',
        'views/expense_funds_view.xml',
        'views/expense_report_view.xml',
    ]
}

# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiAccountMoveComputerizedBranchReversal(models.TransientModel):
    _inherit = 'account.move.reversal'

    dosage_id = fields.Many2one(
        domain="['&', '&', ['company_id','=',company_id], ['document_type','=','credit_debit_note'], ['branch_id','=', branch_id]]",
        context={
            'default_document_type': 'credit_debit_note',
            'default_billing_modality': 'computerized'
        }
    )

    def _prepare_default_reversal(self, move):
        record = super()._prepare_default_reversal(move)
        record.update({'branch_id': move.branch_id.id})
        return record

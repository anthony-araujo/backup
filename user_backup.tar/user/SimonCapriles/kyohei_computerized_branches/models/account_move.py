# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiComputerizedBranchMove(models.Model):
    _inherit = 'account.move'

    dosage_id = fields.Many2one(
        domain="['&', '&', ['company_id','=',company_id], ['document_type','=','invoice'], ['branch_id','=', branch_id]]",
        context={'default_document_type': 'invoice'}
    )

    def action_virtual_computerized_post(self):
        record = super().action_virtual_computerized_post()
        for move in self:
            if move.billing_mode == 'sfv_computerized' and move.type == 'out_invoice':
                if move.dosage_id.branch_id != move.branch_id:
                    raise exceptions.ValidationError('''Las Sucursales de la Dosificación y Factura no coinciden.
Seleccione la dosificación correspondiente antes de tratar de validar nuevamente.''')
                elif move.dosage_id.branch_id not in move.invoice_user_id.branch_ids:
                    raise exceptions.ValidationError('''Las Sucursales de la Dosificación y del Usuario no coinciden.
Seleccione la dosificación correspondiente antes de tratar de validar nuevamente.''')
        return record

    def check_addresses(self):
        record = super().check_addresses()
        if not self.branch_id.street:
            raise exceptions.ValidationError('''La dirección de la Sucursal no se encuentra definida.
Complete la dirección en "Ajustes/Usuarios y compañías/Sucursales" antes de tratar de validar nuevamente.''')
        if not self.branch_id.district:
            raise exceptions.ValidationError('''La Zona de la Sucursal no se encuentra definida.
Complete la dirección en "Ajustes/Usuarios y compañías/Sucursales" antes de tratar de validar nuevamente.''')
        if not self.branch_id.state_id:
            raise exceptions.ValidationError('''El Departamento de la Sucursal no se encuentra definida.
Complete la dirección en "Ajustes/Usuarios y compañías/Sucursales" antes de tratar de validar nuevamente.''')
        if not self.branch_id.country_id:
            raise exceptions.ValidationError('''El País de la Sucursal no se encuentra definida.
Complete la dirección en "Ajustes/Usuarios y compañías/Sucursales" antes de tratar de validar nuevamente.''')
        return record

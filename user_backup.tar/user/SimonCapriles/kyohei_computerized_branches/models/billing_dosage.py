# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiBranchDosage(models.Model):
    _inherit = 'billing.dosage'

    branch_id = fields.Many2one(
        'res.company.branch',
        string='Sucursal',
        default=lambda self: self.env.user.branch_id,
        domain='([["company_id", "=", company_id]])'
    )
    company_id = fields.Many2one(string='Compañía')
    economic_activity_ids = fields.Many2many(domain="[('branch_ids', 'ilike', branch_id)]")

    @api.depends('branch_id', 'description')
    def _compute_dosage_name(self):
        for record in self:
            dosage_name = False
            if record.branch_id and record.branch_id.state_id and record.description:
                dosage_name = record.description + '/' \
                              + record.branch_id.state_id.name + '(' \
                              + str(record.branch_id.branch_code) + ')' + \
                              '/' + record.branch_id.company_id.name

            record.name = dosage_name

    @api.depends('company_id', 'branch_id')
    def _compute_parent_company(self):
        for record in self:
            env = 'res.company.branch'
            if record.branch_id.branch_code == 0:
                record.parent_company_address = self.compute_address(env=env, company_id=self.branch_id.id)
                record.company_address = '-'
            else:
                if not record.branch_id:
                    record.parent_company_address = False
                else:
                    parent_branch = self.env['res.company.branch'].search(['&', ['company_id', '=', record.company_id.id], ['branch_code', '=', 0]])[0]
                    record.parent_company_address = self.compute_address(env=env, company_id=parent_branch.id)
                    record.company_address = self.compute_address(env=env, company_id=self.branch_id.id)

# -*- coding: utf-8 -*-
{
    'name': "Sucursales Computarizada / Kyohei Ltda.",
    'summary': """
        El módulo incorpora Sucursales a la facturación computarizada
        """,
    'description': """
Emita facturas con los datos de sus Sucursales sin la creación de nuevas Compañías
===============================================================================================================
    
Con la instalación del módulo usted obtendrá:
    * La incorporación de Sucursales en los Libros de Compras y Ventas
    * Limitar el acceso de Dosificaciones por Sucursales asignadas a sus usuarios    
    """,
    'author': "Kyohei Ltda.",
    'website': "http://www.kyohei.com.bo",
    'category': 'Invoicing Management', 'Operations'
    'version': '13.0.0.4',
    'depends': ['kyohei_computerized_billing', 'kyohei_billing_branches'],
    'auto_install': True,
    'license': 'OPL-1',
    'data': [
        'security/security_rules.xml',
        'views/billing_dosage_view.xml',
        'views/account_move_view.xml',
        'reports/computerized_invoice_template.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}

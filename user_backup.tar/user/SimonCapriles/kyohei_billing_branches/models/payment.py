# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiBranchPayment(models.Model):
    _inherit = 'account.payment'

    branch_id = fields.Many2one('res.company.branch', related='journal_id.branch_id')

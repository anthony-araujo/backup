# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiBranchJournal(models.Model):
    _inherit = 'account.journal'

    branch_id = fields.Many2one(
        'res.company.branch',
        default=lambda self: self.env.user.branch_id,
        domain="[['company_id','=',company_id]]"
    )

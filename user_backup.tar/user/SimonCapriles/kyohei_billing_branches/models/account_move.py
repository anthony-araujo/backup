# -*- coding: utf-8 -*-

from odoo import models, fields, exceptions


class KyoheiBranchMove(models.Model):
    _inherit = 'account.move'

    branch_id = fields.Many2one(
        'res.company.branch',
        string='Sucursal',
        default=lambda self: self.env.user.branch_id,
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="['&', ['company_id','=',company_id], ['user_ids', 'ilike', invoice_user_id]]",
        copy=False
    )

    def action_kyohei_billing_post(self):
        record = super().action_kyohei_billing_post()
        for move in self:
            if move.type != 'entry' and not move.branch_id:
                raise exceptions.ValidationError('''La Factura no tiene una Sucursal asignada.
Asigne antes de tratar de validar nuevamente.''')
            if move.lcv_line_id:
                move.lcv_line_id.sudo().write({
                    'branch_id': move.branch_id.id,
                    'branch_code': move.branch_id.branch_code
                })
        return record

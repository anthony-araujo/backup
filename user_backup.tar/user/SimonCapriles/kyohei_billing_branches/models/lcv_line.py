# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiBranchLcvLine(models.Model):
    _inherit = 'lcv.line'

    branch_id = fields.Many2one('res.company.branch', default=lambda self: self.env.user.branch_id, string='Sucursal')
    company_id = fields.Many2one(string='Compañía')

# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiAccountMoveComputerizedBranchReversal(models.TransientModel):
    _inherit = 'account.move.reversal'

    branch_id = fields.Many2one('res.company.branch', related='move_id.branch_id')

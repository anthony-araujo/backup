# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiBranchEconomicActivity(models.Model):
    _inherit = 'economic.activity'

    branch_ids = fields.Many2many(
        'res.company.branch',
        'branch_activity_rel',
        'branch_ids',
        'economic_activity_ids',
        string='Sucursales'
    )
    company_ids = fields.Many2many(string='Compañías')

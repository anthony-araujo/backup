# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiBillingBranches(models.Model):
    _inherit = 'res.company.branch'

    name = fields.Char(compute='_compute_branch_name', store=True)

    @api.depends('company_id', 'state_id', 'branch_code')
    def _compute_branch_name(self):
        for record in self:
            branch_name = False
            if record.state_id and record.company_id:
                branch_name = record.state_id.name + '(' + str(record.branch_code) + ')' + '/' + record.company_id.name
            record.name = branch_name

    district = fields.Char(string='Zona')
    branch_code = fields.Integer(string='Código sucursal', default=1, required=True)
    economic_activity_ids = fields.Many2many(
        'economic.activity',
        'branch_activity_rel',
        'economic_activity_ids',
        'branch_ids',
        string='Actividades económicas',
        domain="[('company_ids', 'ilike', company_id)]"
    )
    journal_ids = fields.One2many('account.journal', 'branch_id', string='Diarios')

    @api.constrains('branch_code')
    def check_unique_branch_code(self):
        for record in self:
            company_branch_codes = []
            for registry in self.env['res.company.branch'].search(
                    ['&', ['company_id', '=', record.company_id.id], ['id', '!=', record.id]]).read(['branch_code']):
                company_branch_codes.append(registry['branch_code'])
            if record.branch_code in company_branch_codes:
                raise exceptions.ValidationError(
                    'Dos Sucursales de la misma Compañía no pueden tener el mismo código!'
                )
            if record.branch_code == 0:
                if record.company_id:
                    record.street = record.company_id.street
                    record.street2 = record.company_id.street2
                    record.district = record.company_id.district
                    record.city = record.company_id.city
                    record.state_id = record.company_id.state_id
                    record.phone = record.company_id.phone
                    record.email = record.company_id.email
                    record.economic_activity_ids = record.company_id.economic_activity_ids
                else:
                    raise exceptions.ValidationError(
                        'Seleccione la compañía a la cual pertenecerá la Casa matriz antes de continuar'
                    )

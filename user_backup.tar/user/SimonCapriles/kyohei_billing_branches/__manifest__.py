# -*- coding: utf-8 -*-
{
    'name': "Sucursales Facturación / Kyohei Ltda.",
    'summary': """
        El módulo incorpora Sucursales al módulo de facturación
        """,
    'description': """
Incorpore las Sucursales al sistema de facturación
==================================================================
    
Con la instalación del módulo usted obtendrá:
    * La incorporación de Sucursales en el sistema de facturación
    """,
    'author': "Kyohei Ltda.",
    'website': "http://www.kyohei.com.bo",
    'category': 'Invoicing Management', 'Operations'
    'version': '13.0.0.3',
    'depends': ['kyohei_branches_base', 'kyohei_billing_base'],
    'auto_install': True,
    'data': [
        'security/ir.model.access.csv',
        'security/security_rules.xml',
        'views/root_view.xml',
        'views/company_branch_view.xml',
        'views/company_view.xml',
        'views/account_move_view.xml',
        'views/account_move_reversal_wizard_view.xml',
        'views/account_payment_view.xml',
        'views/account_journal_view.xml',
        'views/lcv_line_view.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}

# -*- coding: utf-8 -*-
{
    'name': "Sello de agua / Kyohei Ltda.",

    'summary': """
    Al instalar este módulo obtendrá la posibilidad de definir la marca de agua en los imprimibles
    """,

    'description': """
Personalice sus impresiones con sellos de agua y adjuntos
================================================================================

Después de instalar el módulo obtendrá:
    * La posibilidad de definir su marca de agua
    * La posibilidad de agregar contenido personalizado adjunto
        
    """,
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Administration',
    'version': '13.0.0.1',
    'license': 'OPL-1',
    'installable': True,
    'application': True,
    'depends': ['base', 'base_setup'],
    'external_dependencies': {'python': ['PyPDF2']},
    'data': [
        'views/templates.xml',
        'views/res_config_view.xml',
        'views/ir_actions_report_xml.xml'
    ],
}

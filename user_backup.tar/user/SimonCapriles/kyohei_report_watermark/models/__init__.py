# -*- coding: utf-8 -*-

from . import ir_actions_report
from . import report
from . import res_company
from . import res_config_settings

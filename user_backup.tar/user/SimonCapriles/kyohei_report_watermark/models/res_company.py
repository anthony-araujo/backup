# -*- coding: utf-8 -*-

from odoo import models, fields


class ReportWatermarkDefaultSettings(models.Model):
    _inherit = 'res.company'

    pdf_watermark = fields.Binary(
        string='PDF: Marca de agua',
        help='Cargue la marca de agua de su compañía en PDF.\n\
Este PDF será utilizado como fondo en cada página impresa.')
    pdf_watermark_fname = fields.Char(string='Nombre: Marca de agua')
    pdf_last_page = fields.Binary(
        string='PDF: Adjuntos',
        help='Cargue las páginas adjuntas en PDF con cualquier contenido específico.\n\
Este documento será adjuntado en la impresión del reporte.')
    pdf_last_page_fname = fields.Char(string='Nombre: Adjuntos')

# -*- coding: utf-8 -*-

from odoo import fields, models


class WatermarkIrActionsReportXml(models.Model):
    _inherit = 'ir.actions.report'

    pdf_watermark = fields.Binary(
        string='PDF: Marca de agua',
        help='Cargue el PDF del sello de agua que ser[a utilizado como fondo de cada página impresa.\n\
La marca de agua cargada aquí reemplazará a la cargada en la compañía de las configuraciones generales.'
    )
    pdf_watermark_fname = fields.Char(string='Nombre: Marca de agua')
    pdf_last_page = fields.Binary(
        string='PDF: Adjuntos',
        help='Cargue un archivo PDF con contenido específico como contenido promocional, publicidad, etc.\n\
Este documento será adjuntado en la impresión del reporte.\n\
Las páginas cargadas aquí reemplazarán a las cargadas en la compañía de las configuraciones generales.'
    )
    pdf_last_page_fname = fields.Char(string='Nombre: Adjuntos')

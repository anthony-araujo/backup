# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiInternationalValuationLayer(models.Model):
    _inherit = 'stock.valuation.layer'

    policy_number = fields.Char(
        related='stock_landed_cost_id.policy_number',
        string='N° Póliza',
        store=True
    )
    delivery_partner = fields.Many2one(
        string='Dirección destino',
        related='stock_move_id.partner_id'
    )

# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiInternationalLandedCost(models.Model):
    _inherit = 'stock.landed.cost'

    policy_number = fields.Char(
        string='N° Póliza',
        related='vendor_bill_id.policy_number',
        store=True
    )

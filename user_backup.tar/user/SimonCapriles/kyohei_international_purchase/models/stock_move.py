# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiInternationalStockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    picking_partner_id = fields.Many2one(related='move_id.picking_partner_id', string='Contacto')

# -*- coding: utf-8 -*-
{
    'name': "Importaciones / Kyohei Ltda.",

    'summary': """
        El módulo instala los datos necesarios para crear compras internacionales""",

    'description': """
Cree pedidos de importación con la localización boliviana
===================================================================

Con la instalación del módulo usted obtendrá:
    * Diferenciación de las compras locales e internacionales
    * Permisos de acceso diferenciados
    
    """,

    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.bo",
    'category': 'Operations/Purchase',
    'version': '13.1.0.4',
    'depends': ['stock_landed_costs', 'kyohei_billing_base'],
    'license': 'OPL-1',
    'installable': True,
    'application': True,
    'data': [
        'data/import_order_sequence_data.xml',
        'data/fiscal_position_data.xml',
        'data/server_action_data.xml',
        'security/security_groups.xml',
        'views/import_order_view.xml',
        'views/stock_landed_cost_view.xml',
        'views/stock_move_view.xml',
        'views/stock_valuation_layer_view.xml',
        'views/root_view.xml',
    ],
}

# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiAccountMoveReversal(models.TransientModel):
    _inherit = 'account.move.reversal'

    company_id = fields.Many2one(
        'res.company',
        default=lambda self: self.env.user.company_id
    )
    dosage_id = fields.Many2one(
        'billing.dosage',
        string='Dosificación',
        domain="['&',['company_id','=',company_id],['document_type','=','credit_debit_note']]",
        context={'default_document_type': 'credit_debit_note'}
    )
    credit_debit_number = fields.Integer(string='N° Nota de Crédito Débito', default=0)
    authorization_number = fields.Char(string='Número de autorización', default=False)
    control_code = fields.Char(string='Código de control', default=False)

    def _prepare_default_reversal(self, move):
        record = super()._prepare_default_reversal(move)
        if self.with_credit_debit_note:
            if self.refund_method == 'modify':
                raise exceptions.ValidationError(
                    'Si se genera una "Nota de Crédito o Débito", no se tiene que crear una factura correctiva.')
            dosage_id = False
            control_code = False
            authorization_number = False
            invoice_number = 0
            original_total_amount = 0.0
            if move.type == 'out_invoice' and move.lcv_line_id:
                if not self.dosage_id.id:
                    raise exceptions.ValidationError('''Debe seleccionar una dosificación para poder realizar la devolución.
    Si no existe una dosificación, hable con el responsable de facturación.''')
                elif self.dosage_id.company_id != move.company_id:
                    raise exceptions.ValidationError('''La dosificación no corresponde a la sucursal de la factura.
    Seleccione otra dosificación, que corresponda a la sucursal de la factura.''')
                dosage_id = self.dosage_id.id
                current_dosage = self.env['billing.dosage'].browse([dosage_id])
                invoice_number = self.dosage_id.next_number
                current_dosage.write({'next_number': invoice_number + 1})
                authorization_number = self.dosage_id.order_number
                control_code = self.env['account.move'].generate_control_code(
                    invoice_number,
                    move.partner_id.vat,
                    move.lcv_line_id.credit_debit_base_amount,
                    move.invoice_date,
                    self.dosage_id.order_number,
                    self.dosage_id.dosage_key
                )
                original_total_amount = move.lcv_line_id.total_amount
            elif move.type == 'in_invoice' and move.lcv_line_id:
                if not self.credit_debit_number:
                    raise exceptions.ValidationError(
                        'El número de la nota de crédito-débito por devolución de compra no puede ser 0.')
                if not self.authorization_number:
                    raise exceptions.ValidationError(
                        'Falta detallar el número de autorización de la nota de crédito-débito por devolución de compra.')
                if not self.control_code:
                    raise exceptions.ValidationError(
                        'Falta detallar el código de control de la nota de crédito-débito por devolución de comptra.')
                authorization_number = self.authorization_number
                control_code = self.control_code
                invoice_number = self.credit_debit_number
                original_total_amount = move.lcv_line_id.total_amount
            record.update({
                'dosage_id': dosage_id,
                'control_code': control_code,
                'authorization_number': authorization_number,
                'sin_number': str(invoice_number),
                'sin_state': 'V',
                'legend': False,
                'sin_qr_code': False,
                'original_sin_number': move.sin_number,
                'original_invoice_date': move.invoice_date,
                'original_authorization_number': move.authorization_number,
                'original_total_amount': original_total_amount,
                'partner_billing_name': move.partner_billing_name,
                'partner_billing_number': move.partner_billing_number
            })
        return record

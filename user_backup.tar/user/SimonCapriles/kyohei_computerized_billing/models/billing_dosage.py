# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiComputerizedDosage(models.Model):
    _name = 'billing.dosage'
    _description = 'Dosificación'
    _check_company_auto = True

    # Dosage basic data
    name = fields.Char(string='Dosificación', compute='_compute_dosage_name', store=True)
    description = fields.Char(string='Descripción', required=True)

    @api.depends('company_id', 'description')
    def _compute_dosage_name(self):
        for record in self:
            dosage_name = False
            if record.company_id and record.company_id.state_id and record.description:
                dosage_name = record.description + '/'\
                              + record.company_id.state_id.name + '('\
                              + str(record.company_id.branch_code) + ')' +\
                              '/' + record.company_id.name

            record.name = dosage_name

    active = fields.Boolean(string='Activa', default=True)
    order_number = fields.Char(string='Número de orden')
    last_invoice_date = fields.Date(string='Fecha última factura')
    # Branch and pos related data
    company_id = fields.Many2one(
        'res.company',
        string='Sucursal',
        default=lambda self: self.env.company
    )
    company_vat = fields.Char(related='company_id.vat', string='NIT')
    economic_activity_ids = fields.Many2many(
        'economic.activity',
        'dosage_activity_rel',
        'economic_activity_ids',
        'dosage_ids',
        domain="[('company_ids', 'ilike', company_id)]"
    )
    parent_company_address = fields.Text(
        string='Dirección Casa Matriz',
        compute='_compute_parent_company',
        store=True,
        default=False,
        copy=False
    )
    company_address = fields.Text(
        string='Dirección Sucursal',
        compute='_compute_parent_company',
        store=True,
        default=False,
        copy=False
    )

    @api.depends('company_id')
    def _compute_parent_company(self):
        for record in self:
            env = 'res.company'
            if record.company_id.branch_code == 0:
                record.parent_company_address = self.compute_address(env=env, company_id=self.company_id.id)
                record.company_address = '-'
            else:
                if not record.company_id.parent_id:
                    record.parent_company_address = False
                else:
                    record.parent_company_address = self.compute_address(env=env, company_id=self.company_id.parent_id.id)
                    record.company_address = self.compute_address(env=env, company_id=self.company_id.id)

    # Invoice related data
    document_type = fields.Selection(
        [('invoice', 'Factura'),
         ('credit_debit_note', 'Nota de crédito/débito')],
        required=True
    )
    lcv_specification = fields.Selection(
        [
            ('2', 'Ventas estándar'),
            # ('3', 'Ventas de combustible'),
            # ('4', 'Ventas prevaloradas'),
            # ('5', 'Ventas prevaloradas telecomunicaciones'),
            # ('6', 'Reintergro')
        ],
        string='Especificación'
    )
    start_date = fields.Date(string='Válida desde', copy=False)
    end_date = fields.Date(string='Válida hasta', required=True)
    start_number = fields.Integer(string='Numera desde', copy=False)
    end_number = fields.Integer(string='Numera hasta', required=True)
    next_number = fields.Integer(string='Siguiente número', copy=False)
    dosage_key = fields.Char(string='Llave de dosificación', copy=False)
    billing_characteristic_ids = fields.Many2many('billing.characteristic', string='Características', copy=False)
    invoice_legend = fields.Many2one('billing.legend', string='Leyenda de facturación')

    def compute_address(self, env, company_id):
        computed_address = '-'
        if company_id:
            address_environment = self.env[env]
            address = address_environment.search([['id', '=', company_id]])[0]
            if not getattr(address, 'street2'):
                if not getattr(address, 'phone'):
                    computed_address = '%s, Zona: %s, %s-%s' % (
                        getattr(address, 'street'),
                        getattr(address, 'district'),
                        getattr(address, 'state_id').name,
                        getattr(address, 'country_id').name
                    )
                else:
                    computed_address = '%s, Zona: %s, Teléfono: %s, %s-%s' % (
                        getattr(address, 'street'),
                        getattr(address, 'district'),
                        getattr(address, 'phone'),
                        getattr(address, 'state_id').name,
                        getattr(address, 'country_id').name
                    )
            else:
                if not getattr(address, 'phone'):
                    computed_address = '%s, %s, Zona: %s, %s-%s' % (
                        getattr(address, 'street'),
                        getattr(address, 'street2'),
                        getattr(address, 'district'),
                        getattr(address, 'state_id').name,
                        getattr(address, 'country_id').name
                    )
                else:
                    computed_address = '%s, %s, Zona: %s, Teléfono: %s, %s-%s' % (
                        getattr(address, 'street'),
                        getattr(address, 'street2'),
                        getattr(address, 'district'),
                        getattr(address, 'phone'),
                        getattr(address, 'state_id').name,
                        getattr(address, 'country_id').name
                    )
        return computed_address

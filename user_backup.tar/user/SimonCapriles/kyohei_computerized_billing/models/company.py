# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiComputerizedCompany(models.Model):
    _inherit = 'res.company'

    dosage_id = fields.One2many('billing.dosage', 'company_id', string='Dosificación')
    billing_mode = fields.Selection(selection_add=[('sfv_computerized', 'Computarizada SFV')])

# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


class KyoheiElectronicBillingSystem(models.Model):
    _inherit = 'sin.billing.system'

    billing_mode = fields.Selection(selection_add=[('sfv_computerized', 'Computarizada virtual')])
    certification_id = fields.Many2one('sfc.certification.registry')

# -*- coding: utf-8 -*-

from arc4 import ARC4
from datetime import datetime
from odoo import models, fields, api, exceptions

verhoeff_chart_d = (
    (0, 1, 2, 3, 4, 5, 6, 7, 8, 9),
    (1, 2, 3, 4, 0, 6, 7, 8, 9, 5),
    (2, 3, 4, 0, 1, 7, 8, 9, 5, 6),
    (3, 4, 0, 1, 2, 8, 9, 5, 6, 7),
    (4, 0, 1, 2, 3, 9, 5, 6, 7, 8),
    (5, 9, 8, 7, 6, 0, 4, 3, 2, 1),
    (6, 5, 9, 8, 7, 1, 0, 4, 3, 2),
    (7, 6, 5, 9, 8, 2, 1, 0, 4, 3),
    (8, 7, 6, 5, 9, 3, 2, 1, 0, 4),
    (9, 8, 7, 6, 5, 4, 3, 2, 1, 0))

verhoeff_chart_p = (
    (0, 1, 2, 3, 4, 5, 6, 7, 8, 9),
    (1, 5, 7, 6, 2, 8, 3, 0, 9, 4),
    (5, 8, 0, 3, 7, 9, 6, 1, 4, 2),
    (8, 9, 1, 6, 0, 4, 3, 5, 2, 7),
    (9, 4, 5, 3, 1, 2, 6, 8, 7, 0),
    (4, 2, 8, 6, 5, 7, 3, 9, 0, 1),
    (2, 7, 9, 3, 8, 0, 6, 4, 1, 5),
    (7, 0, 4, 6, 9, 1, 3, 2, 5, 8))

verhoeff_chart_inv = (0, 4, 3, 2, 1, 5, 6, 7, 8, 9)


def obtain_verhoeff_calcsum(number):
    c = 0
    for i, item in enumerate(reversed(str(number))):
        c = verhoeff_chart_d[c][verhoeff_chart_p[(i + 1) % 8][int(item)]]
    return verhoeff_chart_inv[c]


def obtain_verhoeff_checksum(number):
    c = 0
    for i, item in enumerate(reversed(str(number))):
        c = verhoeff_chart_d[c][verhoeff_chart_p[i % 8][int(item)]]
    return c


def obtain_verhoeff(number):
    return "%s%s" % (number, obtain_verhoeff_calcsum(number))


# ASCII
def sum_ascii(str_sum, start, interval):
    sum_tot = 0
    index = start - 1
    while index < len(str_sum):
        char_i = str_sum[index:index + 1]
        sum_tot = sum_tot + ord(char_i)
        index = index + interval
    return sum_tot


# BASE64
base64_dict = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/'


def base64_encode(number):
    word = ''
    coc = 1
    while coc > 0:
        coc = int(number / 64)
        rest = base64_mod64(number, 64)
        word = base64_dict[rest] + word
        number = coc

    return word


def base64_mod64(div_d, div_s):
    coc = int(div_d / div_s)
    result = div_d - (div_s * coc)
    return result


class KyoheiComputerizedMove(models.Model):
    _inherit = 'account.move'

    billing_mode = fields.Selection(selection_add=[('sfv_computerized', 'Computarizada SFV')])
    # Local transaction fields
    issue_deadline = fields.Date(string='Fecha límite de emisión', readonly=True, copy=False)
    dosage_id = fields.Many2one(
        'billing.dosage',
        string='Dosificación',
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="['&',['company_id','=',company_id],['document_type','=','invoice']]",
        context={'default_document_type': 'invoice'},
        copy=False
    )
    dosage_key = fields.Char(related='dosage_id.dosage_key', copy=False)
    sin_qr_code = fields.Binary(string='Código QR', readonly=True, copy=False)
    qr_code_string = fields.Char(string='QR', readonly=True, copy=False)

    def button_draft(self):
        record = super().button_draft()
        for move in self:
            # move marked to_check is for sale_cost_repost
            if move.type in ['out_invoice', 'out_refund'] and move.billing_mode in ['sfv_computerized'] and not move.to_check:
                if int(move.sin_number) == move.dosage_id.next_number - 1:
                    move.dosage_id.sudo().write({'next_number': int(move.sin_number)})
                    move.write({
                        'sin_state': False,
                        'sin_number': False,
                        'control_code': False,
                        'authorization_number': False,
                        'legend': False,
                        'issue_deadline': False
                    })
                else:
                    raise exceptions.ValidationError('''Esta factura ya no puede volver a estado borrador.
Si cometió un error, debe anular esta factura y crear una nueva.''')
        return record

    def action_kyohei_billing_post(self):
        record = super().action_kyohei_billing_post()
        self.action_virtual_computerized_post()
        return record

    def _check_characteristics(self):
        require_debit_tax, allow_zero_rate = super()._check_characteristics()
        if self.billing_mode in ['sfv_computerized'] and self.dosage_id.billing_characteristic_ids:
            for characteristic in self.dosage_id.billing_characteristic_ids:
                require_debit_tax = False if not characteristic.requires_debit_tax else True
                allow_zero_rate = True if characteristic.zero_rate_sale else False
        return require_debit_tax, allow_zero_rate

    def action_virtual_computerized_post(self):
        for move in self:
            # move marked to_check is for sale_cost_repost
            if not move.to_check:
                if move.type in ['in_invoice', 'in_refund', 'out_invoice', 'out_refund'] and move.billing_mode == 'sfv_computerized' and not move.is_nullifying and not move.is_foreign:
                    if move.type == 'out_invoice':
                        move.check_addresses()
                        # Check dosage data
                        if move.billing_mode == "sfv_computerized":
                            if not move.dosage_id.id:
                                raise exceptions.ValidationError('''La "Dosificación" de esta factura no se encuentra definida.
Primero tiene que seleccionar una dosificación antes de tratar de validar la factura.''')
                            if not move.dosage_id.order_number:
                                raise exceptions.ValidationError('''El "Número de autorización" de la Dosificación no se encuentra definida.
Revise la dosificación y complete los datos antes de tratar de validar la factura.''')
                            if not move.dosage_id.lcv_specification:
                                raise exceptions.ValidationError('''Falta detallar la especificación de compra o venta en la dosificación.''')
                            if move.dosage_id.next_number > move.dosage_id.end_number:
                                raise exceptions.ValidationError('''La "Dosificación" que está utilizando agotó su numeración.
Seleccione otra dosificación o revise los datos de la dosificación.''')
                            if move.invoice_date > move.dosage_id.end_date:
                                raise exceptions.ValidationError('''La "Dosificación" que está utilizando parece haber expirado.
Seleccione una dosificación vigente, revise los datos de la dosificación o revise la fecha de la factura.''')
                            if len(move.dosage_id.economic_activity_ids) == 0:
                                raise exceptions.ValidationError('''La "Actividad económica" de la dosificación no se encuentra definida.
Detalle las actividades económicas relacionadas en la dosificación actual.''')
                            if move.dosage_id.document_type != 'invoice':
                                raise exceptions.ValidationError('Solo puede utilizar dosificaciones para facturas.')
                            if not move.dosage_id.dosage_key:
                                raise exceptions.ValidationError('''El "Llave de la dosificación" de esta factura no se encuentra definida.
Revise la dosificación y complete los datos antes de tratar de validar la factura..''')
                            if not move.dosage_id.invoice_legend:
                                raise exceptions.ValidationError('''La "Leyenda" de la dosificación de esta factura no se encuentra definida.
Revise la dosificación y complete los datos antes de tratar de validar la factura..''')
                            if move.dosage_id.next_number == 0 or not move.dosage_id.next_number:
                                raise exceptions.ValidationError('La numeración de la factura no es válida.')
                            if move.dosage_id.last_invoice_date:
                                if move.invoice_date < move.dosage_id.last_invoice_date:
                                    raise exceptions.ValidationError('No puede emitir facturas con fechas anteriores al %s con esta Dosificación' % datetime.strftime(move.dosage_id.last_invoice_date, '%d/%m/%Y'))
                            # Issue deadline
                            issue_deadline = move.dosage_id.end_date
                            # Invoice numbering
                            invoice_number = move.dosage_id.next_number
                            move.env['billing.dosage'].browse([move.dosage_id.id]).sudo().write({
                                'next_number': invoice_number + 1,
                                'last_invoice_date': move.invoice_date
                            })
                            # Computerized Control Code
                            control_code = move.env['account.move'].generate_control_code(
                                invoice_number,
                                move.partner_billing_number,
                                move.lcv_line_id.credit_debit_base_amount,
                                move.invoice_date,
                                move.dosage_id.order_number,
                                move.dosage_id.dosage_key
                            )
                            # QR
                            qr_string = (
                                    str(move.company_id.vat) + '|'
                                    + str(invoice_number) + '|'
                                    + str(move.dosage_id.order_number) + '|'
                                    + datetime.strftime(move.invoice_date, '%d/%m/%Y') + '|'
                                    + str(move.amount_total) + '|'
                                    + str(move.lcv_line_id.credit_debit_base_amount) + '|'
                                    + str(control_code) + '|'
                                    + str(move.partner_billing_number) + '|'
                                    + str(move.lcv_line_id.specific_fee_amount) + '|'
                                    + str(move.lcv_line_id.zero_rate_amount) + '|'
                                    + str(move.lcv_line_id.no_credit_tax_amount) + '|'
                                    + str(move.lcv_line_id.discount_amount)
                            )
                            qr_code = move.construct_qr(qr_string)
                            move.write({
                                'sin_number': str(invoice_number),
                                'issue_deadline': issue_deadline,
                                'authorization_number': move.dosage_id.order_number,
                                'control_code': control_code,
                                'qr_code_string': qr_string,
                                'sin_qr_code': qr_code,
                                'sin_state': 'V',
                                'legend': move.dosage_id.invoice_legend.legend,
                                'total_amount_text': move.compute_amount_string(move.amount_total),
                                'lcv_specification': move.dosage_id.lcv_specification
                            })
                            move.lcv_line_id.sudo().write({
                                'invoice_number': invoice_number,
                                'sin_state': move.sin_state,
                                'authorization_number': move.dosage_id.order_number,
                                'control_code': control_code,
                                'lcv_specification': move.lcv_specification
                            })
                    elif move.type == 'out_refund':
                        if not move.dosage_id.id:
                            raise exceptions.ValidationError('''La "Dosificación" de esta factura no se encuentra definida.
Primero tiene que seleccionar una dosificación antes de tratar de validar la factura.''')
                        elif move.dosage_id.next_number > move.dosage_id.end_number:
                            raise exceptions.ValidationError('''La "Dosificación" que está utilizando agotó su numeración.
Seleccione otra dosificación o revise los datos de la dosificación.''')
                        elif move.dosage_id.document_type != 'credit_debit_note':
                            raise exceptions.ValidationError('No puede utilizar una dosificación para facturas.')
                        elif move.invoice_date > move.dosage_id.end_date:
                            raise exceptions.ValidationError('''La "Dosificación" que está utilizando parece haber expirado.
Seleccione una dosificación vigente, revise los datos de la dosificación o revise la fecha de la factura.''')
                        # Invoice numbering
                        move.env['billing.dosage'].browse([move.dosage_id.id]).write({'next_number': move.dosage_id.next_number + 1})

    def generate_control_code(self, invoice_number, customer_vat, total_amount, date_invoice, authorization_number, dosage_key):
        invoice_date = datetime.strftime(date_invoice, '%Y%m%d')
        total_amount = int(round(total_amount, 0))
        dosage_key = dosage_key.strip()
        if not dosage_key:
            raise exceptions.ValidationError('Error!, falta la llave de dosificación')
        if not customer_vat and customer_vat != 0:
            raise exceptions.ValidationError('Error! Falta detallar NIT')
        elif len(str(customer_vat)) > 12:
            raise exceptions.ValidationError('Error!, El NIT debe ser menor a 12 dígitos de longitud')
        if any(c.isalpha() for c in customer_vat):
            raise exceptions.ValidationError('''No se puede facturar a "Números de facturación" con letras.
Para facturar usted puede:
-Facturar al NIT del cliente (Recomendado)
-Facturar al CI sin complemento
-Si es un cliente extranjero, registre sólo los números del pasaporte''')
        try:
            # Step 1
            invoice_number_verhoeff = obtain_verhoeff(obtain_verhoeff(invoice_number))
            customer_vat_verhoeff = obtain_verhoeff(obtain_verhoeff(customer_vat))
            invoice_date_verhoeff = obtain_verhoeff(obtain_verhoeff(invoice_date))
            total_amount_verhoeff = obtain_verhoeff(obtain_verhoeff(total_amount))

            verhoeff_sum = (
                    int(invoice_number_verhoeff) +
                    int(customer_vat_verhoeff) +
                    int(invoice_date_verhoeff) +
                    int(total_amount_verhoeff)
            )

            verhoeff_list = []
            verhoeff_5 = ''
            for i in range(5):
                verhoeff_number = obtain_verhoeff_calcsum(verhoeff_sum)
                verhoeff_5 = "%s%s" % (verhoeff_5, verhoeff_number)
                verhoeff_sum = "%s%s" % (verhoeff_sum, verhoeff_number)
                verhoeff_list.append(verhoeff_number + 1)

            # Step 2
            key_data_list = []
            verhoeff_data_list = [str(authorization_number),
                                  str(invoice_number_verhoeff),
                                  str(customer_vat_verhoeff),
                                  str(invoice_date_verhoeff),
                                  str(total_amount_verhoeff)]
            index = 0
            full_key = ''
            for i in range(5):
                sub_key = str(dosage_key)[index:verhoeff_list[i] + index]
                index = index + verhoeff_list[i]
                key_data_list.append(verhoeff_data_list[i] + sub_key)
                full_key = full_key + key_data_list[i]

            # Step 3
            cipher_key = dosage_key + verhoeff_5
            arc4 = ARC4(cipher_key)
            string_arc4 = (arc4.encrypt(full_key)).hex().upper()

            # Step 4
            ascii_sum_list = []
            total_ascii_sum = sum_ascii(string_arc4, 1, 1)
            ascii_sum_list.append(sum_ascii(string_arc4, 1, 5))
            ascii_sum_list.append(sum_ascii(string_arc4, 2, 5))
            ascii_sum_list.append(sum_ascii(string_arc4, 3, 5))
            ascii_sum_list.append(sum_ascii(string_arc4, 4, 5))
            ascii_sum_list.append(sum_ascii(string_arc4, 5, 5))

            # Step 5
            base64_sum = 0
            for i in range(5):
                base64_sum = base64_sum + int(total_ascii_sum * ascii_sum_list[i] / verhoeff_list[i])
            base64_string = base64_encode(base64_sum)

            # Step 6
            control_code = ''
            arc4 = ARC4(cipher_key)
            arc64_control_code = (arc4.encrypt(base64_string)).hex().upper()
            for i in (range(len(arc64_control_code))):
                if (i + 1) % 2 or i + 1 == len(arc64_control_code):
                    control_code = control_code + str(arc64_control_code[i])
                else:
                    control_code = control_code + str(arc64_control_code[i]) + '-'
            result = control_code

            return result

        except Exception as e:
            if len(str(dosage_key)) < 3:
                raise exceptions.ValidationError('La llave de dosificación no es válida')
            else:
                raise exceptions.ValidationError(e)

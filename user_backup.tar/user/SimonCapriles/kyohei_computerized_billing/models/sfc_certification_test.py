# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiComputerizedSystemCertificationTest(models.Model):
    _name = 'sfc.certification.test'
    _description = 'Prueba de certificación SFC'
    _rec_name = 'sequence_id'

    sequence_id = fields.Char(string='Prueba', readonly=True)
    authorization_number = fields.Char(string='N° autorización')
    sin_number = fields.Char(string='N° Factura')
    customer_vat = fields.Char(string='NIT cliente')
    invoice_date = fields.Date(string='Fecha')
    total_amount = fields.Float(string='Monto')
    dosage_key = fields.Char(string='Llave dosificación')
    control_code = fields.Char(string='Código de control')
    certification_registry_id = fields.Many2one('sfc.certification.registry', string='Certifiación')

    @api.model
    def create(self, vals):
        seq = self.env['ir.sequence'].next_by_code('sfc.certification.test.sequence') or '/'
        vals['sequence_id'] = seq
        return super(KyoheiComputerizedSystemCertificationTest, self).create(vals)

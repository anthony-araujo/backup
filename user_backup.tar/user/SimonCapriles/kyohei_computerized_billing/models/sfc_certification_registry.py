# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiComputerizedSystemCertificationRegistry(models.Model):
    _name = 'sfc.certification.registry'
    _description = 'Registro de certificación SFC'
    _rec_name = 'sequence_id'

    sequence_id = fields.Char(string='Certificado', readonly=True)
    certification_date = fields.Date(string='Fecha de certificación')
    state = fields.Selection(
        [('approved', 'Aprobado'),
         ('failed', 'Fallido')],
        string='Estado',
        default='failed'
    )
    certification_test_ids = fields.One2many(
        'sfc.certification.test', 'certification_registry_id',
        string='Pruebas de certificación'
    )
    transaction_number = fields.Char(string='N° trámite')
    certification_code = fields.Char(string='Código')
    billing_system_id = fields.Many2one('sin.billing.system', string='Nombre de sistema')

    @api.model
    def create(self, vals):
        seq = self.env['ir.sequence'].next_by_code('sfc.certification.registry.sequence') or '/'
        vals['sequence_id'] = seq
        return super(KyoheiComputerizedSystemCertificationRegistry, self).create(vals)

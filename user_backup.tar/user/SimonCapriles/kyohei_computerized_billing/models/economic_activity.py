# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiComputerizedBillingEconomicActivity(models.Model):
    _inherit = 'economic.activity'

    dosage_ids = fields.Many2many(
        'billing.dosage',
        'dosage_activity_rel',
        'dosage_ids',
        'economic_activity_ids',
        string='Dosificaciones'
    )

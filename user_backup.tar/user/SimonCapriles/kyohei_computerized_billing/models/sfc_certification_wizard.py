# -*- coding: utf-8 -*-

from odoo import models, fields, exceptions
from datetime import datetime
import pytz

missing_authorization_number_message = '''Error en el campo "N° autorización".
Debe detallar el número de autorización.'''
zero_sin_number_message = '''Error en el campo "N° Factura".
El número de la factura debe ser distinto a cero.'''
missing_partner_vat_message = '''Error en el campo "NIT cliente".
Debe detallar el número de NIT del cliente.'''
missing_due_date_message = '''Error en el campo "Fecha".
Debe detallar una fecha de factura.'''
zero_amount_message = '''Error en el campo "Monto".
Debe detallar un monto distinto a cero.'''
missing_dosage_key_message = '''Error en el campo "Llave dosificación".
Debe detallar una llave de dosificación.'''
missing_control_code_message = '''Error en el campo "Código de control".
Tiene que generar un código de control para proceder con la siguiente prueba.'''


class KyoheiComputerizedSystemCertificationWizard(models.TransientModel):
    _name = 'sfc.certification.wizard'
    _description = 'Asistente de certificación'

    # Test fields
    authorization_number = fields.Char(string='N° autorización')
    sin_number = fields.Char(string='N° Factura')
    customer_vat = fields.Char(string='NIT cliente')
    invoice_date = fields.Date(string='Fecha')
    total_amount = fields.Float(string='Monto')
    dosage_key = fields.Char(string='Llave dosificación')
    control_code = fields.Char(string='Código de control', readonly=True)
    # Certificate fields
    billing_system_id = fields.Many2one('sin.billing.system', string='Sistema de facturación', required=True)
    certification_date = fields.Date(string='Fecha certificación')
    certification_registry_id = fields.Many2one('sfc.certification.registry', string='Registro')
    ten_test = fields.Boolean(default=False)
    transaction_number = fields.Char(string='Número de trámite')
    certification_code = fields.Char(string='Código de certificación')
    certification_state = fields.Selection([('approved', 'Aprobada'),
                                            ('failed', 'Fallida')],
                                           string='Estado')

    def start_certification(self):
        try:
            user_tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz)
            today_date = pytz.utc.localize(datetime.now()).astimezone(user_tz).date()
        except AttributeError:
            raise exceptions.ValidationError('No tiene asignada una zona horaria, por favor consulte al administrador')
        certification_record = self.env['sfc.certification.registry']
        certification_list = certification_record.search([['billing_system_id', '=', self.billing_system_id.id]])
        if not certification_list:
            certification_record.create({
                'certification_date': today_date,
                'billing_system_id': self.billing_system_id.id
            })
        certification_list = certification_record.search([['billing_system_id', '=', self.billing_system_id.id]])
        self.certification_registry_id = certification_list[-1]
        return {
            'context': {
                'default_certification_registry_id': self.certification_registry_id.id,
                'default_billing_system_id': self.billing_system_id.id
            },
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'sfc.certification.wizard',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'target': 'new',
        }

    def generate_control_code(self):
        if not self.authorization_number:
            raise exceptions.ValidationError(missing_authorization_number_message)
        elif self.sin_number == '0':
            raise exceptions.ValidationError(zero_sin_number_message)
        elif not self.customer_vat:
            raise exceptions.ValidationError(missing_partner_vat_message)
        elif not self.invoice_date:
            raise exceptions.ValidationError(missing_due_date_message)
        elif self.total_amount == 0:
            raise exceptions.ValidationError(zero_amount_message)
        elif not self.dosage_key:
            raise exceptions.ValidationError(missing_dosage_key_message)
        else:
            control_code = self.env['account.move'].generate_control_code(int(self.sin_number),
                                                                          self.customer_vat,
                                                                          self.total_amount,
                                                                          self.invoice_date,
                                                                          self.authorization_number,
                                                                          self.dosage_key)
            self.control_code = control_code
            return {
                'context': self.env.context,
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'sfc.certification.wizard',
                'res_id': self.id,
                'view_id': False,
                'type': 'ir.actions.act_window',
                'target': 'new',
            }

    def clear_wizard(self):
        return {
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'sfc.certification.wizard',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'target': 'new',
        }

    def next_test(self):
        # Create test record
        if not self.control_code:
            raise exceptions.ValidationError(missing_control_code_message)
        else:
            certification_test_record = self.env['sfc.certification.test']
            certification_test_record.create({
                'authorization_number': self.authorization_number,
                'sin_number': self.sin_number,
                'customer_vat': self.customer_vat,
                'invoice_date': self.invoice_date,
                'total_amount': self.total_amount,
                'dosage_key': self.dosage_key,
                'control_code': self.control_code,
            })
            # Count associated tests
            test_count = 0
            for _ in self.certification_registry_id.certification_test_ids:
                test_count = test_count + 1
            if test_count < 10:
                return {
                    'context': {
                        'default_certification_registry_id': self.certification_registry_id.id,
                        'default_billing_system_id': self.billing_system_id.id
                    },
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'sfc.certification.wizard',
                    'view_id': False,
                    'type': 'ir.actions.act_window',
                    'target': 'new',
                }
            else:
                return {
                    'context': {
                        'default_certification_registry_id': self.certification_registry_id.id,
                        'default_billing_system_id': self.billing_system_id.id,
                        'default_ten_test': True
                    },
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'sfc.certification.wizard',
                    'view_id': False,
                    'type': 'ir.actions.act_window',
                    'target': 'new',
                }

    def end_certification(self):
        certification_registry = self.env['sfc.certification.registry'].browse([self.certification_registry_id.id])
        certification_registry.write({
            'transaction_number': self.transaction_number,
            'certification_code': self.certification_code,
            'state': self.certification_state
        })
        self.certification_registry_id.billing_system_id.write({'certification_id': self.certification_registry_id.id})

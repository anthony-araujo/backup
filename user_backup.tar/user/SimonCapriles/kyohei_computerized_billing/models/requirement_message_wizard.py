# -*- coding: utf-8 -*-

from odoo import models, fields


class KyoheiComputerizedRequirementMessageWizard(models.TransientModel):
    _name = 'requirement.message.wizard'
    _description = 'Wizard para enviar mensaje de solicitud a impuestos nacionales'

    # Campos relacionales necesarios
    company_id = fields.Many2one('res.company')
    billing_characteristic_id = fields.Many2one('billing.characteristic')
    certificate_user_id = fields.Many2one()

    # Datos solicitados por impuestos
    company_vat = fields.Char(string='', required=True)
    characteristic_code = fields.Char(related='billing_characteristic_id.code')
#    economic_activity_code = fields.Char(related='company_id.economic_activity_ids.code')
    authorization_type = fields.Selection([('CFTT', 'Autorización para terceros'),
                                           ('CFTC', 'Autorización conjunta')],
                                          string='Tipo autorización')
    certificate_user_name = fields.Char(related='certificate_user_id.name')
    issuing_vat = fields. Char(string='')
    parallel_dosage = fields.Char()
    company_branch = fields.Char()

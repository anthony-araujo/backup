# -*- coding: utf-8 -*-
{
    'name': "Facturación computarizada",

    'summary': """
        El módulo posibilita la generación y emisión de facturas bajo la modalidad computarizada
        """,

    'description': """
Emita facturas con Odoo bajo la modalidad computarizada
==================================================================

Con la instalación del módulo usted obtendrá:
    * La generación del código de control
    * La posibilidad de certificar el sistema con el SIN
    * La posibilidad de registrar dosificaciones
    * La generación de facturas con el formato normado
    * El reporte de Libro de Compras estándar
    * El reporte de Libro de Ventas estándar
    
    """,
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Invoicing Management',
    'version': '13.6.0.1',
    'depends': ['kyohei_billing_base'],
    'license': 'OPL-1',
    'data': [
        'security/ir.model.access.csv',
        'views/root_view.xml',
        'views/account_move_view.xml',
        'views/billing_dosage_view.xml',
        'views/sfc_certification_test_view.xml',
        'views/sfc_certification_registry_view.xml',
        'views/invoice_template_assets.xml',
        'views/sin_billing_system_view.xml',
        'wizard/account_move_reversal_wizard_view.xml',
        'wizard/sfc_certification_wizard_view.xml',
        'data/sfc_certification_sequence_data.xml',
        'reports/computerized_invoice_template.xml',
        'reports/computerized_invoice_copy.xml',
        'data/paper_format_data.xml',
        'data/server_action_data.xml',
    ]
}

# -*- coding: utf-8 -*-
{
    'name': "Imprimibles Word / Kyohei Ltda.",

    'summary': """
    Obtenga la posibilidad de imprimir sus documentos del sistema en formato .docx
    """,

    'description': """
Descargue los imprimibles del sistema en formato docx compatible con MsWord
================================================================================

Después de instalar el módulo obtendrá:
    * La posibilidad de utilizar plantillas de MS Word para sus imprimibles
    * Descargar imprimibles del sistema con MS Word
        
    """,
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Tools',
    'version': '13.1.0.2',
    'depends': ['base', 'web'],
    'external_dependencies': {'bin': ['unoconv']},
    'license': 'OPL-1',
    'installable': True,
    'application': True,
    'data': [
        'views/webclient_templates.xml',
        'views/report_view.xml'
    ],
}

# -*- coding: utf-8 -*-
{
    'name': "Sucursales ventas",

    'summary': """
    Al instalar este módulo limitará la visibilidad de los usuarios a las cotizaciones
        """,

    'description': """
Utilice el módulo de Sucursales para limitar la visibilidad de sus usuarios
================================================================================

Después de instalar el módulo obtendrá:
    * Sucursales en las cotizaciones y pedidos de venta
    * Reglas de acceso para limitar el acceso y visibilidad a las operaciones
    
    """,

    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Operations',
    'version': '13.0.0.2',
    'depends': ['sale_management', 'kyohei_branches_base'],
    'auto_install': True,
    'license': 'OPL-1',
    'data': [
        'security/security_rules.xml',
        'views/crm_team_view.xml',
        'views/sale_order_view.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}

# -*- coding: utf-8 -*-

from odoo import models, fields, api


class CrmTeamBranches(models.Model):
    _inherit = 'crm.team'

    branch_id = fields.Many2one(
        'res.company.branch',
        string='Sucursal',
        domain="[['company_id','=',company_id]]",
        copy=False
    )

    member_ids = fields.One2many(
        domain="[['branch_ids','in',branch_id]]",
    )

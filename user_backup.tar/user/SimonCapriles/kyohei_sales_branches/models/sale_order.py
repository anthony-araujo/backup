# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrderBranches(models.Model):
    _inherit = 'sale.order'

    branch_id = fields.Many2one(
        'res.company.branch',
        string='Sucursal',
        default=lambda self: self.env.user.branch_id,
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="['&', ['company_id','=',company_id], ['user_ids', 'ilike', user_id]]",
        copy=False
    )

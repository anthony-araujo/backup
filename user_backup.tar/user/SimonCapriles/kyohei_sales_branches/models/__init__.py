# -*- coding: utf-8 -*-

from . import crm_team
from . import sale_order

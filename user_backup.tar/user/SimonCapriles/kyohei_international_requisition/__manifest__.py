# -*- coding: utf-8 -*-
{
    'name': "Acuerdos internacionales / Kyohei Ltda.",

    'summary': """
    El módulo instala los datos necesarios para crear acuerdos de compras internacionales
    """,

    'description': """
Cree acuerdos de importación con la localización boliviana
===================================================================

Con la instalación del módulo usted obtendrá:
    * Creación de Ordenes de importación desde los acuerdos de compras
    
    """,
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.bo",
    'category': 'Operations/Purchase',
    'version': '13.0.0.1',
    'depends': ['kyohei_international_purchase', 'purchase_requisition'],
    'auto_install': True,
    'license': 'OPL-1',
    'data': [
        'views/purchase_requisition_view.xml',
        'views/root_view.xml',
    ]
}

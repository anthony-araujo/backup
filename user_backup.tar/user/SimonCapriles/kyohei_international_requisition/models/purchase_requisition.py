# -*- coding: utf-8 -*-

from odoo import models, fields, api


class KyoheiInternationalPurchaseRequisition(models.Model):
    _inherit = 'purchase.requisition'

    is_foreign = fields.Boolean(string='Importación', default=False)

# -*- coding: utf-8 -*-
{
    'name': "Localización Bolivia / Kyohei Ltda.",

    'summary': """
    Al instalar este módulo obtendrá información básica para iniciar operaciones contables en Bolivia
    """,

    'description': """
Utilice el módulo Contabilidad Out Of The Box
================================================================================

Después de instalar el módulo obtendrá:
    * Plan de cuentas basado en el ABC de la contabilidad, SIAT y Odoo
    * Impuestos de acuerdo a nomativa vigente
    * Los departamentos del país con sus respectivos códigos
    * Bancos que operan actualmente en el país con código SWIFT de las casas matrices
    * Impresión de asientos contables de acuerdo a normativa actual
    
Los impuestos instalados incluyen:
    * I.V.A. por compras y ventas
    * Retenciones para servicios, bienes y alquileres (con y sin Grossing UP)
    * Impuestos al consumo específico porcentuales, fijos y por cantidad
        
    """,
    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Localization',
    'version': '13.0',
    'depends': ['account', 'account_tax_python'],
    'price': 500,
    'currency': 'USD',
    'license': 'OPL-1',
    'data': [
        'data/account_chart_template_data.xml',
        'data/account_group_data.xml',
        'data/account.account.template.csv',
        'data/account_tax_group.xml',
        'data/default_account_data.xml',
        # 'data/account_tax_report_data.xml',
        'data/account_tag.xml',
        'data/account_tax_data.xml',
        'data/account_chart_template_configure_data.xml',
        'views/company_view.xml',
        'views/partner_view.xml',
        'views/account_move_view.xml',
        'report/account_move.xml',
        'data/state_data.xml',
        'data/contact_bank_data.xml',
        'data/language_data.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}

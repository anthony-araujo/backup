# -*- coding: utf-8 -*-

from odoo import models, fields


class kyoheiMoveLine(models.Model):
    _inherit = 'account.move.line'
    _order = 'credit, debit desc'

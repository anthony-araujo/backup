# -*- coding: utf-8 -*-
# from odoo import http


# class L10nBoKyohei(http.Controller):
#     @http.route('/l10n_bo_kyohei/l10n_bo_kyohei/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/l10n_bo_kyohei/l10n_bo_kyohei/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('l10n_bo_kyohei.listing', {
#             'root': '/l10n_bo_kyohei/l10n_bo_kyohei',
#             'objects': http.request.env['l10n_bo_kyohei.l10n_bo_kyohei'].search([]),
#         })

#     @http.route('/l10n_bo_kyohei/l10n_bo_kyohei/objects/<model("l10n_bo_kyohei.l10n_bo_kyohei"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('l10n_bo_kyohei.object', {
#             'object': obj
#         })

# -*- coding: utf-8 -*-
{
    'name': "LifeTechnologies Bolivia",

    'summary': """
        El módulo instala las personalizaciones de LifeTechnologies Bolivia
        """,

    'description': """
Instale las personalizaciones de LifeTechnologies en su base de datos
===============================================================================

Con la instalación del módulo usted obtendrá:
    * Impresión personalizada de órdenes de compra
    * Impresión personalizada de órdenes de venta
    * Impresión personalizada de notas de remisión
    
    """,

    'author': "Kyohei Ltda.",
    'website': "https://www.kyohei.com.bo",
    'category': 'Uncategorized',
    'version': '13.20.0.3',
    'depends': [
        'sale_management',
        'stock',
        'l10n_bo_kyohei',
        'kyohei_computerized_billing',
        'kyohei_international_purchase',
        'kyohei_branches_base',
        'kyohei_docx_template'
    ],
    'data': [
        'data/payment_term_data.xml',
        'security/ir.model.access.csv',
        'views/purchase_order_view.xml',
        'views/product_template_view.xml',
        'views/res_user_view.xml',
        'views/company_view.xml',
        'views/stock_picking_view.xml',
        'views/sales_order_view.xml',
        'data/external_layout_data.xml',
        'reports/purchase_order_template.xml',
        'reports/purchase_order_alternate.xml',
        'reports/sales_order_template.xml',
        'reports/sales_order_alternate.xml',
        'reports/remittance_note.xml',
        'reports/remittance_note_alternate.xml',
        'reports/sales_remittance_note_alternate.xml',
        'reports/stock_move_remittance_note.xml',
        'reports/move_general_voucher.xml',
        'reports/move_income_voucher.xml',
        'reports/move_outcome_voucher.xml',
        'data/paper_format_data.xml',
        'data/implelab_sales_order_report_data.xml',
        'data/labogen_sales_order_report_data.xml',
        'data/mbs_sales_order_report_data.xml',
    ],
    'external_dependencies': {
        'python': [
            'PyPDF2',
        ],
    },
}

# -*- coding: utf-8 -*-

from . import account_move
from . import company
from . import product_brand
from . import product
from . import purchase_order
from . import sale_order
from . import stock_move
from . import user

# -*- coding: utf-8 -*-

from odoo import models, fields


class LifeTechnologiesAccountMove(models.Model):
    _inherit = 'account.move'

    def compute_formal_date(self, move_date):
        month_list = [
            'Enero',
            'Febrero',
            'Marzo',
            'Abril',
            'Mayo',
            'Junio',
            'Julio',
            'Agosto',
            'Septiembre',
            'Octubre',
            'Noviembre',
            'Diciembre'
        ]
        string_month = month_list[int(move_date.strftime('%m')) - 1]
        formal_date = move_date.strftime('%d') + ' de ' + string_month + ' ' + move_date.strftime('%Y')
        return formal_date

# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions


no_related_stock_picking_message = 'Esta orden de venta no tiene albaranes asociados'


class LifeTechnologiesSaleOrder(models.Model):
    _inherit = 'sale.order'

    note = fields.Text(default='''El precio incluye "Factura Fiscal".''')
    date_order = fields.Datetime(readonly=False, copy=True)
    commitment_date = fields.Datetime(readonly=False, copy=True)
    validity_date = fields.Date(copy=True)

    def get_remittance_note_data(self, line_id):
        try:
            unit_price = self.env['sale.order.line'].search([['id', '=', line_id.id]])[0].price_unit
            product_price = self.env['sale.order.line'].search([['id', '=', line_id.id]])[0].name
            product_index = self.env['sale.order.line'].search([['id', '=', line_id.id]])[0].sequence
        except IndexError:
            raise exceptions.ValidationError(no_related_stock_picking_message)
        return [unit_price, product_price, product_index]

    def print_remittance_note(self):
        if not self.picking_ids:
            raise exceptions.ValidationError(no_related_stock_picking_message)
        else:
            pass
        return self.env.ref('kyohei_lifetechnologies_specifics.action_sales_remittance_note').report_action(self)

    def print_docx_sales_order(self):
        if self.env.company.vat in ['163734027', '192916023', '2312147018']:
            if self.env.company.vat == '163734027':
                if self.branch_id.branch_code == 0:
                    return self.env.ref('kyohei_lifetechnologies_specifics.action_implelab_docx_saleorder_0').report_action(self)
                if self.branch_id.branch_code == 1:
                    return self.env.ref('kyohei_lifetechnologies_specifics.action_implelab_docx_saleorder_1').report_action(self)
                if self.branch_id.branch_code == 2:
                    return self.env.ref('kyohei_lifetechnologies_specifics.action_implelab_docx_saleorder_2').report_action(self)
            if self.env.company.vat == '192916023':
                if self.branch_id.branch_code == 0:
                    return self.env.ref('kyohei_lifetechnologies_specifics.action_labogen_docx_saleorder_0').report_action(self)
                if self.branch_id.branch_code == 1:
                    return self.env.ref('kyohei_lifetechnologies_specifics.action_labogen_docx_saleorder_1').report_action(self)
                if self.branch_id.branch_code == 2:
                    return self.env.ref('kyohei_lifetechnologies_specifics.action_labogen_docx_saleorder_2').report_action(self)
            if self.env.company.vat == '2312147018':
                if self.branch_id.branch_code == 0:
                    return self.env.ref('kyohei_lifetechnologies_specifics.action_mbs_docx_saleorder_0').report_action(self)
                else:
                    raise exceptions.ValidationError('Existe un problema con la sucursal de esta cotización, por favor revísela.')
        else:
            raise exceptions.ValidationError('Esta compañía no cuenta con un imprimible!')

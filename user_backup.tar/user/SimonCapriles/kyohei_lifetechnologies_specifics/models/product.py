# -*- coding: utf-8 -*-

from odoo import models, fields, api


class LifeTechnologiesProduct(models.Model):
    _inherit = 'product.template'

    brand = fields.Many2one('product.brand', string='Línea')

# -*- coding: utf-8 -*-

from odoo import models, fields, api


class LifeTechnologiesUser(models.Model):
    _inherit = 'res.users'

    hand_signature = fields.Binary(string='Firma en documentos', attachment=True)

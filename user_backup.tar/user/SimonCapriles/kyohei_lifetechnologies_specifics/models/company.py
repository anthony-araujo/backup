# -*- coding: utf-8 -*-

from odoo import models, fields


class LifeTechnologiesCompany(models.Model):
    _inherit = 'res.company'

    background_image = fields.Binary(string='Imagen de fondo', attachment=True)

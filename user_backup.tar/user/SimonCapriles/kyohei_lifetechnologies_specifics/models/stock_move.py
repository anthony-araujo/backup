# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions
import pytz


not_existent_sales_order_message = 'Este albarán no se encuentra relacionado a una orden de venta'
not_related_sales_order_message = 'Este albarán no se encuentra relacionado a una orden de venta del sistema'


class LifeTechnologiesPicking(models.Model):
    _inherit = 'stock.picking'

    def get_sale_order_data(self, order_ref):
        try:
            payment_term = self.env['sale.order'].search([['name', '=', order_ref]])[0].payment_term_id.note
            client_name = self.env['sale.order'].search([['name', '=', order_ref]])[0].partner_id.name
            sale_commitment_date = self.env['sale.order'].search([['name', '=', order_ref]])[0].commitment_date
            sale_user_id = self.env['sale.order'].search([['name', '=', order_ref]])[0].user_id
            try:
                user_tz = pytz.timezone(sale_user_id.tz)
                if sale_commitment_date:
                    commitment_date = pytz.utc.localize(sale_commitment_date).astimezone(user_tz).date()
                else:
                    commitment_date = False
            except AttributeError:
                raise exceptions.ValidationError('El cotizador no tiene la zona horaria asignada.')
        except IndexError:
            raise exceptions.ValidationError(not_existent_sales_order_message)
        return [payment_term, client_name, commitment_date]

    def get_sale_order_line_data(self, line_id):
        try:
            unit_price = self.env['sale.order.line'].search([['id', '=', line_id.id]])[0].price_unit
            product_price = self.env['sale.order.line'].search([['id', '=', line_id.id]])[0].name
            product_index = self.env['sale.order.line'].search([['id', '=', line_id.id]])[0].sequence
        except IndexError:
            raise exceptions.ValidationError(not_related_sales_order_message)
        return [unit_price, product_price, product_index]

    def print_remittance_note(self):
        try:
            sale_order_id = self.env['sale.order'].search([['name', '=', self.origin]])[0]
        except IndexError:
            raise exceptions.ValidationError(not_existent_sales_order_message)
        try:
            for line in self.move_ids_without_package:
                move_line_id = self.env['sale.order.line'].search([['id', '=', line.sale_line_id.id]])[0]
        except IndexError:
            raise exceptions.ValidationError(not_related_sales_order_message)
        try:
            user_tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz)
        except AttributeError:
            raise exceptions.ValidationError('No tiene asignada una zona horaria, por favor consulte al administrador')
        return self.env.ref('kyohei_lifetechnologies_specifics.action_stock_move_remittance_note').report_action(self)

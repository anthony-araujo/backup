# -*- coding: utf-8 -*-

from odoo import models, fields, api


class LifeTechnologiesPurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    additional_info = fields.Boolean(string='Información adicional')
    subsidiary_id = fields.Many2one(
        'res.partner',
        string='Subsidiario',
        domain="[('parent_id', '=', partner_id)]"
    )
    product_specialist_id = fields.Many2one('res.partner', string='Especialista de producto')
    provider_contact_id = fields.Many2one('res.partner', string='Persona de contacto')
    forwarder_information = fields.Text(string='Forwarder information', copy=False)
    authorizing_user_id = fields.Many2one('res.users', string='Autorizado por', readonly=True, copy=False)

    def button_confirm(self):
        for order in self:
            if order.state not in ['draft', 'sent']:
                continue
            order._add_supplier_to_product()
            # Deal with double validation process
            if order.company_id.po_double_validation == 'one_step' or\
                    (order.company_id.po_double_validation == 'two_step' and
                     order.amount_total < self.env.company.currency_id._convert(
                                order.company_id.po_double_validation_amount,
                                order.currency_id,
                                order.company_id,
                                order.date_order or
                                fields.Date.today()
                            )) or order.user_has_groups('purchase.group_purchase_manager'):
                order.button_approve()
                self.write({'authorizing_user_id': self.env['res.users'].browse(self._context.get('uid')).id})
            else:
                order.write({'state': 'to approve'})
        return True

    def button_approve(self):
        record = super().button_approve()
        self.sudo().write({'authorizing_user_id': self.env['res.users'].browse(self._context.get('uid')).id})
        return record


class LifeTechnologiesPurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    product_brand = fields.Many2one(related='product_id.brand', string='Línea')
    provider_ref = fields.Char(string='Ref. cotización')
    # customer_ref = fields.Char(string='Ref. cliente')

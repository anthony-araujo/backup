# -*- coding: utf-8 -*-

from odoo import models, fields, api


class LifeTechnologiesProduct(models.Model):
    _name = 'product.brand'
    _description = 'Línea de producto'

    name = fields.Char(string='Línea', required=True)
